# Connecto — Minecraft Social Engine
**MC:** 1.21.x | **Loaders:** Fabric, Forge, NeoForge, Quilt | **Backend:** Node.js + MongoDB

A full in-game social network mod. Everything is built — just needs your Azure/Ely.by credentials and a deployed backend.

---

## What's Fully Built

### Mod (Java — common module)
- Account system (Microsoft Premium + Ely.by), saves/loads from disk
- Full Microsoft OAuth2 flow (MicrosoftAuth.java) — browser-based login
- Full Ely.by OAuth2 flow (ElyByAuth.java) — browser-based login
- Friend system: add, remove, accept/decline requests, online/offline/in-game status
- Global cross-server chat via WebSocket
- Direct messaging between friends
- Group chats: create, invite friends, send messages
- Discover screen: browse random online players, add as friends
- Profile screen with rotating 3D skin viewer, bio editing, badges
- Account Manager screen: switch accounts in-game without restarting
- World Host screen: P2P hosting with UPnP (stub), invite all online friends
- HUD overlay: toast notifications + online friends counter
- Connecto button injected into MAIN MENU and PAUSE MENU via Mixin
- Login screen (shown automatically if no account is active)
- All 4 loader entrypoints: Fabric, Forge, NeoForge, Quilt
- All Gradle build files

### Backend (Node.js)
- Auth: login/logout with JWT
- Friends: get list, request, accept, decline, remove
- Discover: random online players directory
- World Invites: send invite to any friend
- Profiles: get/update bio and skin URL
- Achievements: unlock and fetch achievements
- WebSocket relay: global chat, DMs, group messages, friend status, world invites
- MongoDB models: User, Message, Group, Achievement
- Rate limiting, CORS, helmet security headers

---

## What You Need To Do

### 1. Premium (Microsoft) — Nothing to do!
Premium accounts are auto-detected from the active Minecraft session.
Works on: Official launcher, Prism, MultiMC, CurseForge, Modrinth, PojavLauncher, FCL, HMCL, and any launcher that handles Microsoft login itself.
No Azure app, no OAuth, no credentials needed.

### 2. Get Ely.by Credentials (for browser login option — FREE, optional)
1. Go to https://account.ely.by/dev/applications
2. Create a new application
3. Redirect URI: http://localhost:9877/callback
4. Copy Client ID and Client Secret
5. Paste into: common/src/main/java/com/connecto/auth/ElyByAuth.java
   Replace: YOUR_ELYBY_CLIENT_ID_HERE and YOUR_ELYBY_CLIENT_SECRET_HERE

### 3. Deploy the Backend
```bash
cd backend
cp .env.example .env
# Edit .env:
#   MONGODB_URI = your MongoDB connection string (local or Atlas free tier)
#   JWT_SECRET  = any long random string
npm install
npm start
```
Deploy to Railway / Render / Fly.io / Oracle Cloud (all have free tiers).

### 4. Update Backend URL in the Mod
In: common/src/main/java/com/connecto/network/ConnectoAPI.java
Change:   public static String BASE_URL = "https://api.connecto.social";
To:       public static String BASE_URL = "https://your-real-url.com";

In: common/src/main/java/com/connecto/network/ConnectoWebSocketClient.java
Change:   private static final String WS_URL = "wss://api.connecto.social/ws";
To:       private static final String WS_URL = "wss://your-real-url.com/ws";

### 5. Enable Real UPnP (optional but recommended)
In common/build.gradle, uncomment:
    implementation "com.github.bitletorg:weupnp:0.1.4"
In P2PHostManager.java, uncomment the WeUpnP lines.

### 6. Add a Mod Icon
Create: common/src/main/resources/assets/connecto/icon.png (128x128 PNG)

---

## Build the Mod
```bash
# Open the root folder in IntelliJ IDEA
# Let Gradle sync (this takes a few minutes first time)
./gradlew :fabric:build    # builds Fabric jar
./gradlew :forge:build     # builds Forge jar
./gradlew :neoforge:build  # builds NeoForge jar
./gradlew :quilt:build     # builds Quilt jar
# Output JARs are in each loader's build/libs/ folder
```

---

## Architecture
```
[Main Menu / Pause Menu]
        |  (Mixin injects button)
        v
[ConnectoHubScreen] — tabbed dashboard
    Friends | Global | Groups | Discover | Profile | Accounts | Host
        |
        v
[ConnectoWebSocketClient] <──> [Node.js Backend :3000/ws]
[ConnectoAPI (REST)]      <──> [Express Routes]
                                    |
                               [MongoDB]
```

---

## File Map
```
connecto/
├── common/src/main/java/com/connecto/
│   ├── Connecto.java                    Main entrypoint
│   ├── auth/
│   │   ├── MicrosoftAuth.java           Full MS OAuth2 flow
│   │   └── ElyByAuth.java               Full Ely.by OAuth2 flow
│   ├── account/
│   │   ├── ConnectoAccount.java         Account model
│   │   └── AccountManager.java          Multi-account manager, skin fetching
│   ├── friends/
│   │   ├── Friend.java                  Friend model
│   │   ├── FriendRequest.java           Request model
│   │   └── FriendManager.java           Friends CRUD + realtime
│   ├── chat/
│   │   ├── ChatMessage.java             Message model
│   │   ├── GroupChat.java               Group model
│   │   └── ChatManager.java             Global/DM/Group chat
│   ├── network/
│   │   ├── ConnectoAPI.java             REST client
│   │   └── ConnectoWebSocketClient.java WS client + auto-reconnect
│   ├── hosting/
│   │   └── P2PHostManager.java          UPnP world hosting
│   ├── gui/
│   │   ├── screens/
│   │   │   ├── ConnectoHubScreen.java   Main tabbed dashboard
│   │   │   ├── LoginScreen.java         OAuth login screen
│   │   │   ├── FriendsScreen.java       Friends list
│   │   │   ├── PendingRequestsScreen.java  Incoming requests
│   │   │   ├── GlobalChatScreen.java    Global chat
│   │   │   ├── DirectMessageScreen.java DMs
│   │   │   ├── GroupChatScreen.java     Group chats + create group
│   │   │   ├── DiscoverScreen.java      Player directory
│   │   │   ├── ProfileScreen.java       Profile + 3D skin
│   │   │   ├── AccountManagerScreen.java  Switch accounts
│   │   │   └── WorldHostScreen.java     P2P hosting UI
│   │   ├── widgets/
│   │   │   ├── ConnectoButton.java      Custom styled button
│   │   │   ├── ConnectoTextInput.java   Custom text input
│   │   │   └── skin/SkinRenderer.java   3D rotating skin renderer
│   │   └── hud/
│   │       └── ConnectoHUD.java         Toast HUD overlay
│   ├── mixin/
│   │   ├── MixinTitleScreen.java        Injects button in main menu
│   │   ├── MixinPauseScreen.java        Injects button in pause menu
│   │   └── MixinGui.java               HUD hook
│   └── util/
│       └── NotificationQueue.java       Toast notification queue
├── fabric/   Forge/   neoforge/   quilt/    Loader entrypoints
└── backend/
    ├── src/
    │   ├── index.js                     Express + WS server
    │   ├── config/config.js             Environment config
    │   ├── middleware/auth.js           JWT verification
    │   ├── models/
    │   │   ├── User.js  Message.js  Group.js  Achievement.js
    │   ├── routes/
    │   │   ├── auth.js  friends.js  discover.js
    │   │   ├── invite.js  profile.js  achievements.js
    │   └── websocket/wsServer.js        Real-time relay
    ├── package.json
    └── .env.example
```
