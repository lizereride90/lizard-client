package com.connecto.neoforge;

import com.connecto.Connecto;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

@Mod(Connecto.MOD_ID)
public class ConnectoNeoForge {

    public ConnectoNeoForge(IEventBus modEventBus) {
        modEventBus.addListener(this::clientSetup);
    }

    private void clientSetup(FMLClientSetupEvent event) {
        Connecto.init();
    }
}
