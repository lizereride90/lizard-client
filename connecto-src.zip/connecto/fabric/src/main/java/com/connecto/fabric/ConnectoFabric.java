package com.connecto.fabric;

import com.connecto.Connecto;
import com.connecto.gui.hud.ConnectoHUD;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class ConnectoFabric implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        Connecto.init();

        // Register HUD overlay (Fabric event system)
        HudRenderCallback.EVENT.register((gfx, delta) ->
                ConnectoHUD.render(gfx, net.minecraft.client.Minecraft.getInstance(),
                        delta.getGameTimeDeltaTicks()));
    }
}
