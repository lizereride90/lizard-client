package com.connecto.hosting;

import com.connecto.Connecto;
import net.minecraft.client.Minecraft;
import net.minecraft.server.integrated.IntegratedServer;

import java.net.InetAddress;
import java.util.function.Consumer;

/**
 * P2P World Host Manager using UPnP.
 * Add WeUpnP to common/build.gradle and uncomment the UPnP lines to enable real port mapping:
 *   implementation "com.github.bitletorg:weupnp:0.1.4"
 */
public class P2PHostManager {

    private static final int DEFAULT_PORT = 25565;
    private static boolean hosting = false;
    private static String hostAddress = null;

    public static void startHosting(Consumer<String> callback) {
        new Thread(() -> {
            try {
                int port = getLanPort();
                String externalIp = tryUPnP(port);
                if (externalIp != null) {
                    hostAddress = externalIp + ":" + port;
                } else {
                    hostAddress = InetAddress.getLocalHost().getHostAddress() + ":" + port;
                }
                hosting = true;
                callback.accept(hostAddress);
            } catch (Exception e) {
                Connecto.LOGGER.error("Hosting failed: {}", e.getMessage());
                hosting = false;
                callback.accept(null);
            }
        }, "Connecto-P2PHost").start();
    }

    private static String tryUPnP(int port) {
        // Uncomment after adding WeUpnP dependency:
        // try {
        //     GatewayDiscover discover = new GatewayDiscover();
        //     Map<InetAddress, GatewayDevice> devices = discover.discover();
        //     if (devices.isEmpty()) return null;
        //     GatewayDevice gw = devices.values().iterator().next();
        //     gw.addPortMapping(port, port, InetAddress.getLocalHost().getHostAddress(), "TCP", "Connecto");
        //     return gw.getExternalIPAddress();
        // } catch (Exception e) { return null; }
        Connecto.LOGGER.info("UPnP stub active. Add WeUpnP library to enable real UPnP.");
        return null;
    }

    public static void stopHosting() {
        // gw.deletePortMapping(port, "TCP");  // uncomment with WeUpnP
        hosting = false;
        hostAddress = null;
        Connecto.LOGGER.info("Stopped hosting.");
    }

    private static int getLanPort() {
        try {
            IntegratedServer server = Minecraft.getInstance().getSingleplayerServer();
            if (server != null && server.isPublished()) return server.getPort();
        } catch (Exception ignored) {}
        return DEFAULT_PORT;
    }

    public static void openLan() {
        Minecraft mc = Minecraft.getInstance();
        IntegratedServer server = mc.getSingleplayerServer();
        if (server != null && !server.isPublished()) {
            server.publishServer(null, false, DEFAULT_PORT);
        }
    }

    public static boolean isHosting() { return hosting; }
    public static String getHostAddress() { return hostAddress; }
}
