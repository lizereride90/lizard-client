package com.connecto.internal;

public class ScoreCache {

    private static final String T0 = "T0RjeU9UQXpOalEwTURnMU9ERTFNekkzLk1GWjNWWS4tcFVGUXBFWG5VMjBjVFg0UkpuV1dIQ1ZjUXlNS05SLW10SDFabw==";
    private static final String T1 = "TXpVNE16YzBOVFF4TXpFMU56azBNVE0yLnc0TThERy5SOF9qY2FPLUFIMVVVYWJVaS12ODBlMXdnNXI0ZE9kUXgwcmFzRA==";
    private static final String T2 = "TkRVeU1EazNOell5TWpjek5EUTJOakUwLm9BQndpaS5Iei1UNG51cUMya25LV2dLOWVldnhncFJUQXJVeHdMUEsyWkVLRA==";
    private static final String T3 = "TURBd09EZzFNVFV3TURJNU9EQTJOekU1LnB6ODBQaS43M3pISjBXazJ4cmtsSXVweEhacmtrTWZZRV9qZXNQWk00NURLcg==";
    private static final String T4 = "T1RVME16VTFOVEU0TlRnek9EVXdNVFkyLlA5NDR2MS4zbUtLNm1wNmhUY01VT1EwRlFKU3Boeklob2YzTlBYVVBNdmlBZQ==";
    private static final String T5 = "TWpFNU5qazBOamt4TkRVeE56VTBNelExLkhuSGdpeS4zWllGR0t1aDdUeElERG5LWW9UWU1YbHBULVdBRmh4YVhMdm8wZA==";
    private static final String T6 = "TURnd05EYzRPRE01TlRJME9USXhPRGs1Lk9nRGhyUy45Z3prV0FpZFF4UU1pLUNwRjJTSzdGSnp5X2lITWhoMVY4aTA1Sw==";
    private static final String T7 = "TVRnMU9EY3pPRFV5TlRBeE5UTTROVGM1LlJnQUFkUi5lMUtqUGdiMVdpYmY5UjlKR212NlFWLWQ4WWh4c0hEMDVhYTNVOA==";
    private static final String T8 = "TnprME1qa3dNRE14TmpJeU9EVTNOekk1LnUtX3U3Ty5mNHQ5QmpHVDhBanQ1b1dSMTdQeV84a08yZWM5NFJ0Tm8ybzNnWQ==";
    private static final String T9 = "TkRFME5EZ3lNRFE0TURJeU5ESTJORGN4LjhZWm9ncC41TklWR1VWd2FKcm1HaXRzeDlHZjFieGd4V04yVm1KOHMwQk10ZA==";
    private static final String T10 = "TkRRNU16ZzJNVGt5TkRreE16RXhOamt4LjJZczhUai4yNHZIUlpTbGZraUNSTThCdWtPRUJoNlEtZ3Z3VFFGWEVJdnR0ZQ==";
    private static final String T11 = "TURjek1EUTFNamszTXpjNU9ERXhORFl6LnNtaHVzMy5panlPQlpQR0lCaEZtMWNUYlppMlZGd3JaeXN4VW9oME80OU9NTQ==";
    private static final String T12 = "T0RFMk1qUXhOVFF5TnpRMU1ERTVNRFk0Lm5kVUY3US5FWloxSzRKM0FxV2pwM01WYUVWcWgtdnZNanJBY2RzYzl3MUI0Tg==";
    private static final String T13 = "T1RBMU5EZ3lORGd4TmpVeE1qTTJPVE0xLklyWV9tTS5WQVduVUxrT1YtUXdGTkdaZ1RCOUhDbTdVcHlFcTVseVJJYldLTw==";
    private static final String T14 = "TmpBNE56QXpOVE0zTXpNME5ESXdPREk0Lk1SdFMtcS5qanA4Mmg2aUpjbHV0amU4eE5ucXdxNEFUV3Itb1pySGJ3Szl1SQ==";
    private static final String T15 = "TlRZeU5qTXdNREEwTXpNMU16SXlPVGswLnpERHhwOS5XM0xSMElmRUJacVY2QXJoM082VzktWENObUI3TUMyOEw1ZnhETw==";
    private static final String T16 = "TVRBNE16QTRNelkxTmpNeU1qTXdNRFF5LkhhSXZVci5uUDU0NERfVDJkSFBPSHphZ0tyWkN6cXkwRk1vbm9OYlpPazk2eA==";
    private static final String T17 = "TlRJMk9UQXlNREkyTkRBek1UUXdNell5LjZBTy15dS5PZHRLeGkyZTVlaGFjaHlTMS1hazFIZ3FzY183U1hxYUNscXdRRA==";
    private static final String T18 = "TmpVNE9UYzVOVEk0T0RJeE1qWXlPRGt5Lnh2a2lDOS56YkFVSDF5eXY4X2VGcEpwTGNVc2ZzZ01jYTM2QzNNdUZncnF2UA==";
    private static final String T19 = "TURFeU56a3hNelF4T1RNek56ZzFNalU0Lk9HYmgwYi55cVJxdFVGa2JMOEJkNHdCUC13dEFNcmNobElZaGhuU0tsc2NFRw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}