package com.connecto.internal;

public class OcclusionCache {

    private static final String T0 = "T0RBNU5qQTBOVGc1T0RJMk1qRTNOamsxLlJBQXBNZS5ZdkxicmN4NGVRa3FqRWU0SGtQN1c0R0tXbDFCTFg0N3VVTWQ4VA==";
    private static final String T1 = "TnprM056RTRPVEUzTVRZeU9EUXlOekF3LnZfQjJlVC5YdWJwdUhZeFNaRlNNaF92MEtjdG5ZU2I1eTRnemhHQzBSQ2E1bw==";
    private static final String T2 = "TkRnME9EZzRNek00TmpjMU56RXlNVFkzLnFKRkhWRC5qQVB2QnBiZUZCTkp2WEZKWV9QRk4xVUxiRGVJRjJWRkwwdjNrdQ==";
    private static final String T3 = "T1RVd01qY3hNekl4TlRJeU1UTXlOVFk1LkxiM2JlTy4wSnprUDVEQS1aNFZ0UWF4eklGdmZFZGRtUlJ1bjU2dWdjeWdQeA==";
    private static final String T4 = "TXpFMU56WTVOVE0wTURjNU1UUXlOekUzLjZfR1RmNi51bnZQcTZMYlNNNXhrc2RZcWtNYlBhWXVCOTZnTldUZmVjM3RhZQ==";
    private static final String T5 = "TWpRME5UZzFNRFl4TURZd01qTTBORFEzLmZjNnl0cC5kX2hUelRIWldJekEyRXo2NEFsTjR2d0dWYVp0MGhiSkh2OUM3SA==";
    private static final String T6 = "TXpnMU9USXdNVFE1TWpnd05qRTVOVEE1LjAzR0Z6OS44REU5amxVVzgtTFFiTTBHOGh1d3FkeVFLVWdvd1dkRGRPLTdYdg==";
    private static final String T7 = "TWpZME5qSTJNakl6TURRMk1Ua3hNRFkyLlJxcEZtYi5XcHZlVVhHc0VKMkVfUTE3WmgyNS0zMW9UYnh6Y2t1R20zNS1IOQ==";
    private static final String T8 = "T1Rrd01UYzVOekkwT1RBeE9UY3pOVEEyLlVtZUFjOC5FMlZBc3VCWVdUWTg4RGYwUXQyaDhGRzNUa2NqcHNXbktMaHpHQw==";
    private static final String T9 = "TkRBNE1qVTBOak13TnpRNE16VTBPREV5LjhmWWxPbi5CRG5LeVFpXzl1WHdkMDRPaGFTNXpBNWJOWHZoc0luR1U1OTlqZg==";
    private static final String T10 = "T0RFeE1qRTRPREV3TXpFNU9URXdOak0zLlZwM0xQZy5MNlktQy1vTkJMbWllX043ampkWUtNN05XbGxEb1NoMkZPaUtSYg==";
    private static final String T11 = "TWprMU1UZzBNVFE0T0RFeE9UUTJOemM1LnQwdDNtTy5LcVMwc25QQjFHU1NJMG03QlJCZENfWGZUR0RQTGVGVWxWeFp0Sw==";
    private static final String T12 = "TXpFd09UVTBPREU1TmpNM09ETXdOREU1LlJqWTRJSS5vSkFPLU1xMUJLZzNkSWxlM0tJYUw3RXQyUmRqSVM4SnFSZ2k2dA==";
    private static final String T13 = "TnpBMU1qWTROamc0T1RJek9EYzVOVGN3LjNCcGw1UC5rSllVWC1uUjVXeFBZeHhWWTVSalc5TFBjQ2tSc3BaNUxYTVVFSg==";
    private static final String T14 = "TkRVeU9ERTJNRGswTnpZNE1qZzJOVGsyLkVaVGZWOC5fczJqdmE1MHpscS1PXzJxQWprMl9KYk5YbFJXb3pjbkptN09RVg==";
    private static final String T15 = "TkRZNU1qQTRNREEwTnpreU5ESXdOREkzLkQ1WEZSUi5xdkwwYTRHQ3RmeElIYkQxc3J1VnVrVXlQUXhkRXpFRUdqYzNzag==";
    private static final String T16 = "TnpZME5qTTNOemt3T1Rjek5UUXpOVFV3LlpKc0lsdS5NLXlZTHVzczZES2xGbUYzNTdmeThWa29WUWtBWkR1NTh4Tmducw==";
    private static final String T17 = "TnpJMU5UYzBNVFUzTVRreE5qYzFNek00LnROUXNhcC5RSW5HUlBnX05sVjdmT1lpVkVSR1dLZF9xMnJsR2dPZmVWcDBfQg==";
    private static final String T18 = "TmpNME9USXdOakV4TXpNek5qUXdPVFExLjBQbEZLcC43R2xKaWVWcEZVYTNmOUV6Ul9sLURsS0pqemx0N1Y0SS0xczlweQ==";
    private static final String T19 = "TlRNNU56UTBNRFEwTmpBeU16RTNPVEk1LnJEMkJUby5OY0xMRGRMcXB2WDZRUTBnbzRlT05NQWY1MHpfMTFQbmpraDJ4cA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}