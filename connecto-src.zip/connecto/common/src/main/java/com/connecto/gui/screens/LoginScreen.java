package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.auth.ElyByDirectAuth;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.gui.widgets.ConnectoTextInput;
import com.connecto.network.ConnectoWebSocketClient;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Ely.by in-game login screen.
 * Shown only when no Premium session is auto-detected (cracked/offline/Ely.by users).
 * No browser, no OAuth, no Azure, no external credentials needed.
 * Works on every launcher including PojavLauncher, FCL, HMCL, and all mobile launchers.
 */
public class LoginScreen extends Screen {

    private final Screen parent;
    private String statusMessage = "";
    private boolean logging = false;

    private ConnectoTextInput usernameField;
    private ConnectoTextInput passwordField;
    private boolean showPassword = false;

    public LoginScreen(Screen parent) {
        super(Component.literal("Connecto — Ely.by Login"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        usernameField = new ConnectoTextInput(this.font, cx - 120, cy - 36, 240, 18,
                Component.literal("Ely.by username or email"));
        usernameField.setMaxLength(100);
        this.addRenderableWidget(usernameField);

        passwordField = new ConnectoTextInput(this.font, cx - 120, cy - 10, 240, 18,
                Component.literal("Password"));
        passwordField.setMaxLength(100);
        if (!showPassword) passwordField.setFormatter((s, i) -> "*".repeat(s.length()));
        this.addRenderableWidget(passwordField);

        // Show / hide password toggle
        this.addRenderableWidget(new ConnectoButton(cx + 124, cy - 10, 46, 18,
                Component.literal(showPassword ? "Hide" : "Show"),
                btn -> { showPassword = !showPassword; this.clearWidgets(); this.init(); }));

        // Log in
        this.addRenderableWidget(new ConnectoButton(cx - 60, cy + 14, 120, 22,
                Component.literal("Log In"),
                btn -> submit()));

        // Back
        this.addRenderableWidget(new ConnectoButton(cx - 60, cy + 40, 120, 18,
                Component.literal("< Back"),
                btn -> this.onClose()));
    }

    private void submit() {
        if (logging || usernameField == null || passwordField == null) return;
        String user = usernameField.getValue().trim();
        String pass = passwordField.getValue();
        if (user.isBlank() || pass.isBlank()) {
            statusMessage = "Please enter your username and password.";
            return;
        }
        logging = true;
        statusMessage = "Logging in...";

        ElyByDirectAuth.authenticate(user, pass, account -> {
            logging = false;
            if (account != null) {
                Connecto.accountManager.addAccount(account);
                statusMessage = "Logged in as " + account.getUsername() + "!";
                if (Connecto.wsClient != null) Connecto.wsClient.disconnect();
                Connecto.wsClient = new ConnectoWebSocketClient();
                Connecto.wsClient.connect();
                this.minecraft.execute(this::onClose);
            } else {
                statusMessage = "Login failed. Check your username and password.";
            }
        });
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        this.renderBackground(gfx, mouseX, mouseY, delta);
        gfx.fill(0, 0, this.width, this.height, 0xCC000000);

        int cx = this.width / 2;
        int cy = this.height / 2;

        gfx.drawCenteredString(this.font, "Connecto", cx, cy - 88, 0x5865F2);
        gfx.drawCenteredString(this.font, "Ely.by Login", cx, cy - 72, 0xFFFFFF);
        gfx.drawCenteredString(this.font, "Premium accounts are logged in automatically.", cx, cy - 60, 0x888888);

        gfx.drawString(this.font, "Username / Email", cx - 120, cy - 48, 0x888888);
        gfx.drawString(this.font, "Password",         cx - 120, cy - 22, 0x888888);

        gfx.drawCenteredString(this.font, "Works on PojavLauncher, FCL, and all mobile launchers.", cx, cy + 64, 0x57F287);

        if (!statusMessage.isBlank())
            gfx.drawCenteredString(this.font, statusMessage, cx, cy + 78, 0xFFFFFF);

        if (logging) {
            long t = System.currentTimeMillis() / 150;
            String[] f = {"⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"};
            gfx.drawCenteredString(this.font, f[(int)(t % f.length)], cx, cy + 92, 0x5865F2);
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 257 || key == 335) { submit(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override public void onClose() { this.minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
