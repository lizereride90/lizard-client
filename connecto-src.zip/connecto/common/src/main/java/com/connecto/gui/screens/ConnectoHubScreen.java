package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.gui.widgets.ConnectoButton;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ConnectoHubScreen extends Screen {

    private final Screen parent;
    private int activeTab = 0;

    private static final String[] TABS = { "Friends","Global","Groups","Discover","Profile","Accounts","Host" };

    private FriendsScreen friendsPanel;
    private GlobalChatScreen chatPanel;
    private GroupChatScreen groupPanel;
    private DiscoverScreen discoverPanel;
    private ProfileScreen profilePanel;
    private AccountManagerScreen accountsPanel;
    private WorldHostScreen hostPanel;

    public ConnectoHubScreen(Screen parent) {
        super(Component.literal("Connecto"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (Connecto.accountManager.getActiveAccount() == null) {
            this.minecraft.setScreen(new LoginScreen(parent));
            return;
        }
        friendsPanel  = new FriendsScreen(this);
        chatPanel     = new GlobalChatScreen(this);
        groupPanel    = new GroupChatScreen(this);
        discoverPanel = new DiscoverScreen(this);
        profilePanel  = new ProfileScreen(this, Connecto.accountManager.getActiveAccount().getUuid());
        accountsPanel = new AccountManagerScreen(this);
        hostPanel     = new WorldHostScreen(this);

        int tabW = this.width / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            this.addRenderableWidget(new ConnectoButton(i * tabW, 0, tabW, 20,
                    Component.literal(TABS[i]), btn -> { activeTab = idx; getPanel().init(this.minecraft, this.width, this.height); }));
        }
        this.addRenderableWidget(new ConnectoButton(4, this.height - 24, 80, 20, Component.literal("< Back"), btn -> this.onClose()));
        getPanel().init(this.minecraft, this.width, this.height);
    }

    private Screen getPanel() {
        return switch (activeTab) {
            case 1 -> chatPanel; case 2 -> groupPanel; case 3 -> discoverPanel;
            case 4 -> profilePanel; case 5 -> accountsPanel; case 6 -> hostPanel;
            default -> friendsPanel;
        };
    }

    @Override
    public void render(GuiGraphics gfx, int mx, int my, float dt) {
        this.renderBackground(gfx, mx, my, dt);
        gfx.fill(0, 22, this.width, this.height - 28, 0xCC000000);
        int tabW = this.width / TABS.length;
        gfx.fill(activeTab * tabW, 0, (activeTab + 1) * tabW, 20, 0xFF5865F2);
        gfx.drawCenteredString(this.font, "Connecto", this.width / 2, 26, 0x5865F2);
        getPanel().render(gfx, mx, my, dt);
        super.render(gfx, mx, my, dt);
    }

    @Override public boolean keyPressed(int k, int s, int m) { if (k==256){onClose();return true;} return getPanel().keyPressed(k,s,m)||super.keyPressed(k,s,m); }
    @Override public boolean charTyped(char c, int m) { return getPanel().charTyped(c,m)||super.charTyped(c,m); }
    @Override public boolean mouseClicked(double x, double y, int b) { return getPanel().mouseClicked(x,y,b)||super.mouseClicked(x,y,b); }
    @Override public boolean mouseScrolled(double x, double y, double dx, double dy) { return getPanel().mouseScrolled(x,y,dx,dy)||super.mouseScrolled(x,y,dx,dy); }
    @Override public void onClose() { this.minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
