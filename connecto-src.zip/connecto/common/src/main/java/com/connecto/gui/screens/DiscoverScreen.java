package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.friends.Friend;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.network.ConnectoAPI;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class DiscoverScreen extends Screen {

    private final Screen parent;
    private List<Friend> discovered = new ArrayList<>();
    private boolean loading = true;
    private int scrollOffset = 0;
    private static final int ENTRY_H = 28;
    private static final int LIST_TOP = 50;

    public DiscoverScreen(Screen parent) {
        super(Component.literal("Discover Players"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(new ConnectoButton(this.width / 2 - 40, 30, 80, 16,
                Component.literal("🔄 Refresh"),
                btn -> loadPlayers()));

        loadPlayers();
    }

    private void loadPlayers() {
        loading = true;
        discovered.clear();
        var account = Connecto.accountManager.getActiveAccount();
        if (account == null) { loading = false; return; }

        ConnectoAPI.getDiscoveryList(account, players -> {
            discovered = new ArrayList<>(players);
            loading = false;
        });
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        gfx.drawCenteredString(this.font, "§b🌍 Discover Players", this.width / 2, 26, 0xFFFFFF);

        if (loading) {
            gfx.drawCenteredString(this.font, "§7Loading...", this.width / 2, this.height / 2, 0x888888);
            super.render(gfx, mouseX, mouseY, delta);
            return;
        }

        if (discovered.isEmpty()) {
            gfx.drawCenteredString(this.font, "§7No players online right now. Check back later!", this.width / 2, this.height / 2, 0x888888);
            super.render(gfx, mouseX, mouseY, delta);
            return;
        }

        int listBottom = this.height - 32;
        int visibleCount = (listBottom - LIST_TOP) / ENTRY_H;

        for (int i = scrollOffset; i < Math.min(discovered.size(), scrollOffset + visibleCount); i++) {
            Friend f = discovered.get(i);
            int y = LIST_TOP + (i - scrollOffset) * ENTRY_H;
            boolean hovered = mouseX > this.width / 2 - 180 && mouseX < this.width / 2 + 180
                    && mouseY > y && mouseY < y + ENTRY_H - 2;

            gfx.fill(this.width / 2 - 180, y, this.width / 2 + 180, y + ENTRY_H - 2,
                    hovered ? 0xFF2A2D3E : 0xFF1E2030);

            gfx.drawString(this.font, "§f" + f.getUsername(), this.width / 2 - 160, y + 4, 0xFFFFFF);
            gfx.drawString(this.font, "§a● Online", this.width / 2 - 160, y + 14, 0x57F287);

            if (hovered) {
                gfx.drawString(this.font, "§b[Add Friend]", this.width / 2 + 80, y + 8, 0x5865F2);
                gfx.drawString(this.font, "§7[Profile]", this.width / 2 + 140, y + 8, 0xAAAAAA);
            }
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int listBottom = this.height - 32;
        int visibleCount = (listBottom - LIST_TOP) / ENTRY_H;

        for (int i = scrollOffset; i < Math.min(discovered.size(), scrollOffset + visibleCount); i++) {
            Friend f = discovered.get(i);
            int y = LIST_TOP + (i - scrollOffset) * ENTRY_H;
            if (mouseY > y && mouseY < y + ENTRY_H - 2) {
                if (mouseX > this.width / 2 + 80 && mouseX < this.width / 2 + 130) {
                    Connecto.friendManager.sendFriendRequest(f.getUuid());
                } else if (mouseX > this.width / 2 + 140) {
                    this.minecraft.setScreen(new ProfileScreen(this, f.getUuid()));
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double dx, double dy) {
        scrollOffset = Math.max(0, scrollOffset - (int) dy);
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
