package com.connecto.chat;

import com.connecto.Connecto;

import java.util.*;
import java.util.function.Consumer;

public class ChatManager {

    private final List<ChatMessage> globalMessages = new ArrayList<>();
    private final Map<String, List<ChatMessage>> directMessages = new LinkedHashMap<>();
    private final Map<String, GroupChat> groupChats = new LinkedHashMap<>();
    private static final int MAX_GLOBAL = 200;

    private final List<Consumer<ChatMessage>> globalListeners = new ArrayList<>();
    private final List<Consumer<ChatMessage>> dmListeners = new ArrayList<>();
    private final List<Consumer<ChatMessage>> groupListeners = new ArrayList<>();

    // ─── Send ─────────────────────────────────────────────────────────────────

    public void sendGlobalMessage(String content) {
        if (Connecto.wsClient == null || !Connecto.wsClient.isConnected()) {
            Connecto.LOGGER.warn("Not connected to Connecto backend.");
            return;
        }
        Connecto.wsClient.sendGlobalChat(content);
    }

    public void sendDirectMessage(String targetUuid, String content) {
        if (Connecto.wsClient == null) return;
        Connecto.wsClient.sendDirectMessage(targetUuid, content);
    }

    public void sendGroupMessage(String groupId, String content) {
        if (Connecto.wsClient == null) return;
        Connecto.wsClient.sendGroupMessage(groupId, content);
    }

    // ─── Receive (called by WebSocket) ───────────────────────────────────────

    public void onGlobalMessage(ChatMessage msg) {
        globalMessages.add(msg);
        if (globalMessages.size() > MAX_GLOBAL) globalMessages.remove(0);
        globalListeners.forEach(l -> l.accept(msg));
    }

    public void onDirectMessage(ChatMessage msg) {
        String key = msg.getSenderUuid();
        directMessages.computeIfAbsent(key, k -> new ArrayList<>()).add(msg);
        dmListeners.forEach(l -> l.accept(msg));
    }

    public void onGroupMessage(ChatMessage msg) {
        GroupChat group = groupChats.get(msg.getChannelId());
        if (group != null) {
            group.addMessage(msg);
            groupListeners.forEach(l -> l.accept(msg));
        }
    }

    // ─── Groups ───────────────────────────────────────────────────────────────

    public void createGroupChat(String name, List<String> memberUuids) {
        String id = UUID.randomUUID().toString();
        GroupChat group = new GroupChat(id, name);
        memberUuids.forEach(group::addMember);
        groupChats.put(id, group);
        if (Connecto.wsClient != null) {
            Connecto.wsClient.createGroup(id, name, memberUuids);
        }
    }

    public Collection<GroupChat> getGroupChats() { return groupChats.values(); }
    public List<ChatMessage> getGlobalMessages() { return Collections.unmodifiableList(globalMessages); }
    public List<ChatMessage> getDirectMessages(String uuid) {
        return directMessages.getOrDefault(uuid, Collections.emptyList());
    }

    // ─── Listeners ────────────────────────────────────────────────────────────

    public void addGlobalListener(Consumer<ChatMessage> l) { globalListeners.add(l); }
    public void addDmListener(Consumer<ChatMessage> l) { dmListeners.add(l); }
    public void addGroupListener(Consumer<ChatMessage> l) { groupListeners.add(l); }
}
