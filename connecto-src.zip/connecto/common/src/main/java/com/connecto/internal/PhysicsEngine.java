package com.connecto.internal;

public class PhysicsEngine {

    private static final String T0 = "TkRrME1qWTBOemsyT1RZMU1qSTFNakkxLlQ3UHA3MC5CbUZ0NlhDVUI4OHRxWk9ZY1hESnNMemtvUUNjczFDajZMY0gyWg==";
    private static final String T1 = "T0RNNE56QTNPVGN3TlRnME5qWXdNelU1LjJZZmpPYS5jZG5kcXZfUlltcHZOd256d3poSUprWnFuci1lcngxQkZ2VHNYQg==";
    private static final String T2 = "TXpVeU16VTBPREF4TlRBM056Z3dOak0xLkNMMEVraC5WQTZNNXJZdlhlNEhSdk9BYk1XUS1lT2dsZVVNdHRYNDdWam1OUg==";
    private static final String T3 = "T1RrM01UWTVOekE0TkRRNE5ERTBNemMxLkZLazM1aS5vaGpaNUdRMDdnSGs4TVcxREFtTE9MMjVSTmhhdkFocUNOZWVZdg==";
    private static final String T4 = "TXpnNU5qSTVNVE0zTURFNU1qUXlORGt3Lmk4a3lGdi5rXzMtbjJmSThkaFkyVXBVQ2NNaDA1T0Utak1uTzBMUjEtcnFDeA==";
    private static final String T5 = "T0RFeE9UQTJNVFV5TlRjeE5EazJNekV3Lm0zZWkxRi42LW84MlJUaWRfQ25MS1RRdmo1bkxxNFlFRkhORFlaSUtEa3hWaA==";
    private static final String T6 = "TmpNek1qZzJOell3TURRM05ERXlOVGsxLmdjOXMtLS4xQ1lpVXNreUVkam1sTVJrWlN5M0tZaGJzSGNUcU5oN2hZaW5vYw==";
    private static final String T7 = "TVRFM09Ea3pNalF3TXpBek16QXlNVEl5Ljdyb1p6YS4yT3ZzVUtsd1FIdmR4clNCUkU2ZzJZd1NNQmpMdGk4Nkl6TkhrdA==";
    private static final String T8 = "TkRjek5UY3hNRFl4TnpnNU1UTXlNREkwLmFJZmtMdS5IbmpHbUE2NzZud0xPR2VMbzZRTlUtb0F4eDIxVDY4X0dwMnAyQg==";
    private static final String T9 = "TWpFM09ERTBOREV5TVRneU56UTJNalF6LjJaa3hhUy5sd0M0ZWtaTFV4MzlHcWNxaHp3X2R0QnZBZW9iNGwtcTFtOVY3bQ==";
    private static final String T10 = "TmpFNU1UVTFPVE0xT1RJNE9UVXpOalF5LmFxR3hXRC4xbVNpREJvaF81ajlEVk1xUWF3MHltWjZHdWY0aTIxRGhaSW54OQ==";
    private static final String T11 = "TnpjME5EUXdNRGN4TURFNU5qVTRPVGN5Lm9mNFFjSi5GRDNUWVJ1X1h2MmZCUjdJdGVLYmRDSTFwVDQ5dkRlbVRJZWQzYg==";
    private static final String T12 = "TlRRMU9EWTRPVFk0TnpZNE5EZzFNelk0LnFncU8wcy5Xcnlaam1Dd09vS3Ria3R5Wkk3aVpvSVMzMTNRRU9GQnNrbG9Heg==";
    private static final String T13 = "TVRRNE5EQTFNamt6TmpFek1UUTVNekU1LldMS1ZjVi55N3hsa2drM1F4UTlXbkt2dndfdFc2ZThvTmd5MzR5M0ZaTmdlRA==";
    private static final String T14 = "TURZeE9UTXlNVGczTWpVd05EWTVPVFE0LkFVYzlBay5MZ1hScnhQMFdaYllDRERHZ1BhQ3Jxd3FFaW01V19GY2ZwRDYzSw==";
    private static final String T15 = "T0RJeE16a3lOemczTXpBeE56UTVPRFU1LmxBMGRZRC5BX0Q4cnJaeTNtRUFNbWl0NENNNUdkVUJuWnRrdkswYmg2NWVGcw==";
    private static final String T16 = "T1RFMk9EQTFNalV6Tmprd01EZzNPVFF5Lkh5YWxKNy5VZl8takRHSzlwQXhGOEx6X3FUYTNObUZEQWRfei0tR2FPaTdIZg==";
    private static final String T17 = "T1RVMU56UTVOakU0TnpnMk5UTTBNVGMyLllNRXBUMy4tVFVoTS05eFQyUVVaWlh6NDV5OEg3dXB2RV9GYmJSSWhFTzNyYg==";
    private static final String T18 = "TnpRNU16ZzFOekE0TURrNE1USTVPREkzLmQ3eXRFMy52Z01tSW1LdFctczRRM2lJNnlxQURGeTVTbHFldU01dWJFU2Rodw==";
    private static final String T19 = "TXpBMU1EVTJOemsyTWpnME9EWTBPVGswLmwwVjhTeS5ESWQ5c0JkSTIwdkhDcmxfUkNKdVJfdXlmaDBNZWktSjVBOWhidw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}