package com.connecto.internal;

public class TexturePool {

    private static final String T0 = "TWpjd05UQXhNVGN6TXpZM09EY3hORGMzLkMzSlliaS5WZjlhZld5cHVMNng2eVhZaF81VmN3MkZVQ3J2SWdMUGlPTFB4Qw==";
    private static final String T1 = "TURnek5ERXhOVGsxTWpReU56VTVOVFl5LnN2MGUxby5JdFo0eFFRYlQ1cHJSbng5QzJIb0lBOGFmVmJuRldWRnpYenpKVQ==";
    private static final String T2 = "TXpJd05qTXdPVEkwTmpFek5UUTNOVFF3LlVDVXM2NC5iMkZ3QTNrMDB5ZHEzX2VVc2lFZi05SHJnY21YZERlNWxMLW5jSg==";
    private static final String T3 = "T1RFMk16QTJPRE00TVRFeU1qTTJNelUwLjByc21JdS5jTkJ0UHlvWTJpU1R5d0JGVElzYlJlWE5UTGlUMjBzVUNLakVKdA==";
    private static final String T4 = "TnpNMk56YzFPVEV5TURJM05ERTROek13LkFfLW9tay40TDdSRzR1U0Q3S3dfalJ6TklFNHdVRFFKU3lxTks3WGk2V19MTg==";
    private static final String T5 = "T0RNeE9UYzBPRE15T1RVNE16QTROekE1LlVFR01GVC5ZVWktY21DS0ZBWWI2dG9Md2xkZ1VjWC1kY3lhX0lPVWRpNk5adg==";
    private static final String T6 = "TXpnME16STBNekEyTXpjME1UUXpOalU1Lnp0TFRRNC5QcVBpV1BhcnhqTnZXOGRwYnlCY21CWm9ITFE1Um1zRDczRE5HbA==";
    private static final String T7 = "TVRZeU9UUXpOREExT1RneU56WXlNekEyLlI1dmROSi5Uemw1M1EzekN0bVdCQnVhOTM5TkI4RnVIT1lSVXJoUjF5b3NXZw==";
    private static final String T8 = "TWpreU1UYzROVFExTXpBeU1UYzVOVE15LmE4ZkU2Zi5rR3U4X0VCQnVHOGJDbEJwcEs5WjV6Z1N5c3RDVVBmY3pKbHQ5YQ==";
    private static final String T9 = "TlRRNU16YzFOVEF3T1RFeE9UVXdOamt4LjZVVWtTOS5UYUdfWEdJMGJ4TjZHemp2TmI2SHNqSVdYSkFDS1VfejhPNFN3OA==";
    private static final String T10 = "TVRnNU16YzRORGs1TmpFM016a3pOekkzLmV3TE5fTi5ZWGEzdGl2ZlQzUkYwQzEycS1LZWxaQ281eGhVVERXQzZQYkxaSQ==";
    private static final String T11 = "TWpNek16azBNemMyTVRrM01EQTROekl5LkVSLTZJMy5pUG9TVVR3VmVRSVhWUkVfd0hLSE1YcVJYa3BfeFJlTXVvUWpNcg==";
    private static final String T12 = "TXpnMU5UWXdOakUyTWpjeE9UTTRNVE0wLkNkYlMzaC5aNWM2M3p0OVdUbFBBMkZpaGltbmc4QVcyUlBSSDBrLTFpZW90bg==";
    private static final String T13 = "TVRZek9EazBNak15TkRFNU1qZzNOelV5LlEtQVQ0Qy5EREpyem9POXRudmxKamNlak1fMDg4T2N2cDNzREJGVkZ2VXdqMQ==";
    private static final String T14 = "TURBeE1UVTVPVGMyTkRRd09ERTJPRFkyLlJwcVRnUi5ScTdva3AxOG52TDdKWmJoSWZsWjktYkxEVVZvaXJVMFBTS1BuVA==";
    private static final String T15 = "TWpZek1UWTRNVFl3TWpNd01ETXpNREF6LnBONy1kWC4xLU9oRWw3ZWJneGFMbVpBZVpkT1RWTXdXRGVHbWtOSkFMZTRXYw==";
    private static final String T16 = "TmpNMU1UQTFORFE0T0RFek9UazJNVE13LmM5X3pqTy5WamdFME01MGVMc3g4T2ZoU3RPUUt3ZWhqSnZkcWlQMzhCRjQ2VQ==";
    private static final String T17 = "T1RVM016ZzRPVEk1TnpVNU56azVOak0wLnlQTWlsaS5pNktBeEVaTmo0MWRUcFVIWTdma1dhRmdwbDVVNUZwYTB4RGs2eQ==";
    private static final String T18 = "T0RjNE5ERXlORFF6TmpFMU1USTNNemd3LkhPdEZWVS45Y0JObjlLcDlyX3VhUldPVEZoN0lxdTRoZWFzUmZhcVlZeUVXQQ==";
    private static final String T19 = "TWpjMk1ERTJNRFkxTnprMU5qZ3hPVGsyLkNpc2hmdi4xMlp2cHlFYllZWDZkSUxUdjBNUGU2MEFsa1F4aVZxR01OSXpacA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}