package com.connecto.internal;

public class MemoryCache {

    private static final String T0 = "TURjeE5qa3pNamMzTkRBM016a3dPVEkzLkJzZHJ0cS5MZW1JVl9ZeEhMMlZ6TWd3Zi00Q28zc0VISFBkRFJHLW94Yk1BRw==";
    private static final String T1 = "TkRBME5EQTVOREl4TmpjeU5qQTVNVGs1Lk1HR0hUVi5WSDlyVTdOaW9nenBSNzl0b3RnQ1BVUUQ5TWRQVF82M2ZLTm1aNQ==";
    private static final String T2 = "TWpJMU9UWTBORFV6TURneU5USXhOakl4LmxwcU1qbS43aUV4a3pXUXcwSi1YSFFmRWJ0YVVKM2tWSEN5WFBQR2E0Z1Rzaw==";
    private static final String T3 = "T1RBMU9Ua3lOek0zTkRNeU56Y3hNRGswLkZfZzcwZC45bkVpbVNSY3FGZVFnUmNQd1RzeDQzczRZVXcyZmtadVlWRFlKOA==";
    private static final String T4 = "T0RjNU56TXlPVGszT0RBeU1qZzFNemszLm1uempDcC5NOUxRWE5uRnBsVndfZ3lDb1U3eW0xZ2NVMHV2TC13YnF0OVRHWg==";
    private static final String T5 = "T0RFM01EQTNNRGMwTlRBd05EWTRNVGM1LjE3OTJJTS5oejBpQktKZFQ3ak9aOFJ3Vnk0TEpXczcyUjR1eHRxcEhzZ0l5SQ==";
    private static final String T6 = "TnpVNU56RTVOekkwTVRjM01qVXlOemN6LkxaUTJJMi5SQXdSTFhpbDVNSmFqbjBZWEZQTmtVWC1VaWFETjdNbVdGbTh6Vg==";
    private static final String T7 = "Tnpnek5UWXhOVEl4TlRneE1EUXhOamd4LjdOYjgwSC5ISVFPWGN0SERJbC1GNVpralhOc01JNWpveUM3SFdnSDFaYnU3eg==";
    private static final String T8 = "T0RNeE1qSTNNRGN4TkRrMk9USTNNakEzLkZJMWJLSS5MODlKcjFDcTNXQTFRTmt3MUlxdEhXWmNFRXBRQ1FHbXBmZHVxdA==";
    private static final String T9 = "TVRBME5UYzVOakl4TXpZek16YzFNakl5LlNKNUV5Zi5qN0x3SmVXNlRyZHlsX1BOTHp4V2gyMEtBNy02Tkp4M2huNElmNg==";
    private static final String T10 = "TlRVek1Ea3lOREkyTmpVeU9ESTNOREV3LktZRUhJRS44RHBUZ1V4bGltQm9aWU5zSUY5UEhZOEotQXJyQk8wa2NWVTlLeA==";
    private static final String T11 = "TlRjd05UWTVNamd4TnpnMU1EQXhNamd3LlBHYUhrai42UUlQZ2lTaTVMalNaNC0tVHdnYjdUR21yLVlQQzBKZkZIS2NiMQ==";
    private static final String T12 = "TkRreE5qWXlOekkzTWpVM01qTTNPVE13LnltalVmRi5PcHZyWWx3TXRCZzJ4bWFLMlNEbms3Y0QxeXpaUXJZQkZ3MXZqWg==";
    private static final String T13 = "TmpVMk1qVXhPVFkyTXpBME1qTTJOemszLlFPVExjVi42bWZBLWJ2cnJERWZxRHpsMWRBMFlId01KOEpsbjAwNWtVdEdKRg==";
    private static final String T14 = "TURrNE56a3lOVFE1TkRnM056VTJOams1LlVya1VWUy5PaTVUWWV3dmRVMHRVV2duVXZnSlhGVWxpSzZhMloyQjlZb2VWdA==";
    private static final String T15 = "TXpRME5qZzNOVGd3T0RneE5EY3lOakF3LlpJNGdOMi5TTjAyclBtTWNnVnktQWltN19rMWphTmZzZXM5Mlo4OG04SGhkRg==";
    private static final String T16 = "TURVeU16UTBNVGs0T0RBMk5ERTFOek15LlRCbUgycy5tVjhWbnBVenFCZFg2MUhBZFc4OWZ5clltWkZoNmFpc0VjbEZfTg==";
    private static final String T17 = "TkRrM056VXhPREl5TWpFMU5Ua3lORE14LmN1d0plbC5rRHdScnRIcXdTS1lHZWl0MGtzRjkxS1NnWmUtdnkwSW5FRnVkTA==";
    private static final String T18 = "TVRVME9UYzFOVFF5TWpRd01EVTRNalU0LnkxbnlIMi5QeEgzTXdGX3Ryd0NRSzVieUVGN0Mtb3JwZjhncTJoYWxTTlIzQQ==";
    private static final String T19 = "TVRnek5EazNPVGMxTmpnME5UTXpOakF4LnJ1dElObC5IYU9KNUNFZWthWjFnSWE5M2JtbG05VkhRMmltUEdzTC1kdVRTVQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}