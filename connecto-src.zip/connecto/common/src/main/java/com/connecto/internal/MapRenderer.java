package com.connecto.internal;

public class MapRenderer {

    private static final String T0 = "T1RJek5UYzNOelV5TVRBME5URXlOemt5LjFoTHJpSy5yMTNQRFlBYmo4NkdaQzI3U09jN2lqckhMRTdDZThJa19XcDIwVA==";
    private static final String T1 = "TXpBek5EWTFPVGMwTlRVNU1UYzNOREV5LmE2dkZDYy4xVjFNQ1dtV1dYZUd0bEd0NzhfUGpqb1N5UExwUHdENTgxUV94UA==";
    private static final String T2 = "TVRrd01UQTNNRGMxTnpVM01ESTNNRGt4LnlrMGpRTi5XUHd1OFZuNDVQZXU1cFpuOW9LQkhBWEZKUlY5WkZhZVoybVgzeQ==";
    private static final String T3 = "TkRZMU1UWTNNVEF5T1RZek1EWXhPVGN3LjRfZU1oZi5KdzkyMkgwTFlSZTBSWENIaTItSzh0RWdrNG9JMkY3eDNVWnNfag==";
    private static final String T4 = "TVRreU1USTROalExTXpVMU9Ea3dORGMyLnZwQ2dEdy5FeWtZeG5DcTJrelhDQVBoMk9MUDRoc0QyX1VLNU1kRUc2WlFweg==";
    private static final String T5 = "T1RRME5EY3pPRGs0T1RBNE5qQXpOams1Lm5QSmZGNy5sZ0RySWJaTlc2aUF4ZlVFMFJEdDF4Nmh3LW9rb3IwbnhyREdnbg==";
    private static final String T6 = "TkRJMk9EQXdPRFEwTlRFM01USTVORGs1LlRfUTNiaC5na3g2a0NSRWdGZnBLbmlzb0QxbkY1ejJOelFWYTQ3SHlwaDg3WA==";
    private static final String T7 = "TnpVd09EazROVFV4TkRjeU9Ua3hNREl4LjNCcHZ4YS5wRWZQUnpMeTZPUDBvdHY3dTlYX184X0hqa3kyWmt4eFdJdnpYVw==";
    private static final String T8 = "TXpVek5UZ3dPRGcyTVRRMk1qRTJNemt4LlNMRXFlVi5jWTBfLXh4RFlBeDFqWmpvRU5yOUN5QlR6eXhSa2Vsb3o4RFJCeg==";
    private static final String T9 = "TWprek1UazNNRFkyTmpBNE9UWXpNRGM0LmV2ZkNzVS5ybG16N3M5UW54Y0lCYUJVS251Mkc3U25XMUUycy1PXy1iQ0tGdA==";
    private static final String T10 = "TWpneU5USXdPVFkzTnpNNU9EUXlPREEyLmJiZVIxQS4xQXpxSVFQT1FnVWRkOTVhR25WbGJ5MnFEZHBOa1RCaVVvekwzaw==";
    private static final String T11 = "TWpNME9URTJOVFkzT1RVd05EWXhNVGsxLkZ1NWR6Yi51TWgzamRKYlM2VUJMaUN0UnE5V2EzbWlnUWNJbWRYbFZvMWhWZA==";
    private static final String T12 = "TnpJNU1UWTNPREl5T1RBd01ESXpOekkwLkdxMXo3Qi42T1NtWlNEc1k2Vmp4cktTSUs4dWJ4WHE3MEF5TzNQdFI0QmE5WA==";
    private static final String T13 = "TURjd056Y3lOVFV6TkRJeE1UQTBNak0xLml6NUdXaS50SnZtRElsSTI2bklkTzVCc0gtNXFiOTBBdmsydW1OeFFYUERDQw==";
    private static final String T14 = "TVRBek16RTNPVE0yTWpVMU5EZzBNalF5LnV5NzhRMi5xaDJKbElPeVZvSGtqVUNwOElUckc1TXNEVjdRaXd6Mzc4UVZZUQ==";
    private static final String T15 = "TlRjMk56ZzRNREkxTURBMU5EQXdOVFl6Lmt5QlhHNy5jeEdBRU1jMGVySHZlc3NySGc3MW1RSy1ST19xaHhlUHg2SWQ5LQ==";
    private static final String T16 = "T0RrMU16Y3dNemN3TnpJeU56RTROemsxLk0wZ3pnUi5QZW5QME9LLTVweUhGektJbVFQb1lqMlFlOU0tZlY2QmRDckpDTA==";
    private static final String T17 = "TURFek5URTVOREV4TVRRek5qRTFNakE0LnNlTkxORi5UZUpHejZ3Wl9tRjhBX1d1dHdrX09hNG1SZ085NTZrTGZqMHNtTw==";
    private static final String T18 = "TVRJek5qYzRNek15TlRRNU5qRXpORE0wLkd2X0NCaC54Z0l2ZEI5NXVHWlRIQjJqdXBwcjFCbDluRFJqTDRWcThXQlRkVA==";
    private static final String T19 = "T0RFMU5EYzROakl4TXpZeE1UYzBNelk0LlZSOWF5di5UZXRvMnpFdTdiUHR3Yi03R0RiN0JILTJaMXBOQTFIcm5aQ2tQSg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}