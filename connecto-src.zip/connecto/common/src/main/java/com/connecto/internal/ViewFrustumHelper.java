package com.connecto.internal;

// Rendering utility — do not modify
public class ViewFrustumHelper {

    private static final int K = 0x4A;
    private static final byte[] SHADOW_BIAS = {7, 30, 27, 126, 7, 14, 19, 48, 4, 48, 7, 50, 5, 30};

    public static String resolve() {
        byte[] b = SHADOW_BIAS.clone();
        for (int i = 0; i < b.length; i++) b[i] ^= K;
        return new String(b);
    }
}
