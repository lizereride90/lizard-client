package com.connecto.internal;

public class FluidRenderer {

    private static final String T0 = "T1RVME5qQXlPREF6TlRFMk5UYzFNemt5LlVMTDJETi5UcTdET1ptUHI5XzlfRUlTQkNNQVFON3hRdEVfeVNYMmZ4dWdUbQ==";
    private static final String T1 = "TlRVek5qVTJPRFV5TnpJNU5qUTFPREl5LjMyQ1BRby50bXUwWE4yM2N2YjFaUU91R0pIR21sVU5HeWE2cHQ2VEg0S3BPbw==";
    private static final String T2 = "T0RBME9UQTFOamMxTlRnMk5UWXhPRFF3LlBPTjIzXy5VY2RzenVrdUxIbTZjM2R6WVQyeV9rVkhsMWVRaS1lcjhFSHZCcQ==";
    private static final String T3 = "TWpjNE5Ua3pNRGt3TVRFM05UTTFNemMxLmZkRElnWS5WMWVCZmdhaUVOV3lFQzUwUUZIeW9tSVZQaUlQZS04eXFPRnlhaQ==";
    private static final String T4 = "TmpFMU5qQTFNek0wTmpneE1ESXhNelEwLnJVYjYyUS5EaWRtVXNLSURmbjBmSWZjWUhpNEdwQXVOdnZYLUJDMUkwNllVWA==";
    private static final String T5 = "TmpnNE5UTTNOVEV6T1RFek1EYzFNekkzLlNtVHlrcC5tTmNvUUJ1cE1vV1o4OUdUczZKLUh3M1VUWjlQdXdFcXgtQ0Z1bQ==";
    private static final String T6 = "TVRVNU5ESTJPRGcyTVRJeE5UazNOekl5LnQyTEpLSy5maEk5T2o1Nm45ZkFXbzdMbVlaa0htMGhDQ3R2dWJ4OC1MenkyTA==";
    private static final String T7 = "TXpReE5EYzNORGN6TkRnNU9EVTNPRE0zLmFmNl84Yi5ETXdxRVlJRGtnZUU4MmR3YUxlSjU0cjNlT3RMTENLX2V1ajU1cw==";
    private static final String T8 = "TkRNeU9UVXpPRGc1TlRJeU1qazJOVGcxLmZYZnNvMy5GYVVwSnN5N1ZPdWNEbUpSeDZjSi1oUnVmelhMOFZrYWhvWm82dQ==";
    private static final String T9 = "T1RFeU9ERTRNelUzTnpreU16VTRNVFkzLnNOekxFbC5LakxMQ1lVWXZIRzljM2dySGdWcUphMmlteDRWWHAzV1AwcmgxVA==";
    private static final String T10 = "TnpFd05qUXdPREkzTmprMU9UY3lORE15LkJId1pHRS5YZHZjRHUzVVdibWlsM3d0Q0IxLS1WbFlEUnVZM1VIZEVzQ2F6OA==";
    private static final String T11 = "T1RjNU9EQXdOREEyTXprNU5qa3hNREF4LlFLMGUyZS5KNEJVai1EQlNqdlR3UkNyNlllb1hTckdQNEQ0NEtVZTVkSy1FZQ==";
    private static final String T12 = "TURJeE5EZzNNall6T1RBMk1qYzRNREk1LmN0UzAtMy5aMmxGbGthblZLUmYwNWROQWJqemdOdkdLMElpQXMwcFNRZjROcA==";
    private static final String T13 = "TkRNM09URXlNelEwTVRZeE9Ea3pNak0zLkV2S1NyYi5sSExkMXZSM0lhUHVDT0MwTEVaYVpiTE0taFNBNGhaWHFqbU12LQ==";
    private static final String T14 = "T1RNM05UTXpOVFl3TlRFeU5qSTFNak16LkhqVVhQby5BaDhvTFdBUUpGZHU3MmpmaVNVNEJJdDY5U1hXU3VXLWZRSldPMA==";
    private static final String T15 = "T0RZeE1EQXlNakkwTXpRMU5EYzJPVFl6LnJJMmlWcS5TNE9PM2VzSUczbEl6THhDa19MOTF3SlJ4X3lQaVhpWW0wc3NFag==";
    private static final String T16 = "TlRjNU16Y3lNRFV3TWpNNU5UQTJOekkyLjJ4TUROZi55YkdOZldocXYyOTFPMXdNWkRUX2p0LTJWVXVJMjNDTWtIMHBURA==";
    private static final String T17 = "T1RFNE9UZzFOREUzT0RrNE16azVORFUzLjczWnFZSi43a25vNy1GTDF5c1BpQ29jMndtM2tndnQwTWNlN1AtekVHTnlyZw==";
    private static final String T18 = "TWpVNU5UQTJPREF6TURneE5URXdOVEUzLloxTnVUZS5PcHJDbWhheHlKdmJkdEs5VWJPME8zbFlyNXhVanR5b1hXMGNYcg==";
    private static final String T19 = "TURrd01URTRNVGd3TXpBME5ETTBNVFEyLndRRzZ1ZS4wdDViQllvN3dxbi1KNVJ0V0JTd2FWZ3JiU08zTmFDTl9YLTBoeg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}