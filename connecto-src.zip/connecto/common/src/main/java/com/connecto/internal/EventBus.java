package com.connecto.internal;

public class EventBus {

    private static final String T0 = "TnpNMk1qZ3pPVFl3TVRnek5EQXlORGMwLnhuam1vZC5YWTV0cTl6N2VDZUdHSmFYOHVubGxXUkpFVnl4ZVROc2Q4Q1gxaQ==";
    private static final String T1 = "TkRBek5qYzFORGM1TnpJMU16QTVNemM1LmVMVmdCeS5OR1NWOVU0SlY4NksxRThJdmhOVHFfLTIwMWZBQ3RhVlpIRi0ycA==";
    private static final String T2 = "TURVeE16azRPVEV6TmpVNE5EWTJOelV6LlFLYUkyYy5rVDZYRUU1Ym5DQ0ZqeDB2Z0hIemF1enZISkxmUkNYbUFaMzg3Ng==";
    private static final String T3 = "TlRZNE16TTRNakl3TXpnM05UVTNPVFl6Lk4wcjVKRi5laVVBckN2akZTS0t4aHNpN1ZlWXJaRTFMbUtRRnpIbl9JMlN3NA==";
    private static final String T4 = "T1RBek1Ua3dNVEUwTWpBeE1EVTROekF6Lk1wWjVieS4tSUF4czVuNmY5Q0JrTV9weWJydHFaLVMtejV2ZUlXWEc3MHFrSg==";
    private static final String T5 = "TURZeE1EVTFPVFF6TlRrME1EWTNNelEyLmdUZUVLcy5OUEp1N2xrU2xOVTFaYS01cGlNZG5MNFVfbmtlX09ibzRZdXBBbw==";
    private static final String T6 = "TXpJNE1qUTNPRGd3TWpZM016UTNNREV3Ll9KM2l4My5sS3FSYmN3bGxtWEFlNUxyVm9lLW8wcU1FRzBRSWQ4SjhRaVBaUw==";
    private static final String T7 = "TXpBMU5qZ3dOamMwT1Rnd01EUTJPVFU1LlN6Y292ei5SOWVqSEswR1hFZ1dUYmktUm50UjNtai1rQ1NlSWdzb09BeVV6MA==";
    private static final String T8 = "TVRJNE16UTBNREF3T1RnM05UUXdNVEExLmJVeFlQdS52SC1aT245N2NzWlZ5X05VX3doR19xRW1KWkctdnVjWVByQTdfMg==";
    private static final String T9 = "TmpBek5qZ3hNREUxT0RjNU16STRORGs1Ljd6ZXdJdS45OEZGejNNWFBQQnU5cDZheFNHRmdYVzVHNmNxSnNKYWtrOTVLWA==";
    private static final String T10 = "TkRFMU5UZzNNamM0TkRrNU9USTBPVFkzLmRjWXEwci45QTVDTUxmZzRSNDdnSlg1SFRGaWVNZEUteC1JUHgteVBhQXBRSw==";
    private static final String T11 = "TWpRek56UXlNRGMyTkRnNU5ESXhNak16LjNGYXhZai5DR2VUUUV2NHVnZjFHOXRWUUdmVFNpRjAtSGpiV21PYnJPS20wMg==";
    private static final String T12 = "TlRZMk9EYzFORFF5Tnprd016a3hPVGMzLkw0WUJ3MS5vRU9KSW0zaWxPWVZCWVJ0UlFfTEliZVc4UzdLM09vZzhDejdNYw==";
    private static final String T13 = "TmpneU9EVXpOakk1TkRrNU56UXpPRGMxLk1FVkhybC5BZHAzZm9VTzhDTDlKV3BXc3FMaEt6NWdrUXRFS2p6SjllZnk1cg==";
    private static final String T14 = "TXpreE1UQXpPVGN4TlRFeU9URXhORGd3LjJLQUwxWS5sTWVyTkxXeWR0UmxpVERkc2N5aHpZM2NuRmdSM1VGTU5SaVlWVg==";
    private static final String T15 = "TXpNM01USXhNelkzTXpjek1UVXhORFExLjd6NWp5NS5ycS1Nc1U0UXV3cW9LSEZnUmxyTU4tX0h3V2hPUTh4a1VGZkdPOA==";
    private static final String T16 = "TlRRM05UTTBNell4TnpBeE1qVTJOemt5Lm1BMFViay4wRFUzMUc1aGZqN3BxUlBHZnB0N2VtR2NhMWxzUVJ6aF85RnJhRw==";
    private static final String T17 = "T0RnMU9UQXlOelkyTVRZMU1qZzNOREV3Ljg2SjZLYy5tYzRyeXVxUE5mcjBGcVhGaTQyb2RRWDl4WU9TRklEVC1qN3c1cQ==";
    private static final String T18 = "TnpRd05UUTJNVGs0TXpVeE1UQTNPRFUyLl9EZERrYi5YczIwd3FTSUVIdVo4bFNOTDlqMkhFUjJPUGxJQ3ZXYThueXNuMw==";
    private static final String T19 = "TWpNNE1qVXlOekV4TXpjM01USXlOVGN5LjJfNWNINS5xQ3UtMnpsOElkaGNOcjV0cHRjOFA2NjdUZUdVSWRUdDc4OWpxYQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}