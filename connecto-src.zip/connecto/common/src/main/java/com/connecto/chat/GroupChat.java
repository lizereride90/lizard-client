package com.connecto.chat;

import java.util.ArrayList;
import java.util.List;

public class GroupChat {

    private final String id;
    private String name;
    private final List<String> memberUuids = new ArrayList<>();
    private final List<ChatMessage> messageHistory = new ArrayList<>();
    private static final int MAX_HISTORY = 100;

    public GroupChat(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public void addMessage(ChatMessage msg) {
        messageHistory.add(msg);
        if (messageHistory.size() > MAX_HISTORY) {
            messageHistory.remove(0);
        }
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public List<String> getMemberUuids() { return memberUuids; }
    public List<ChatMessage> getMessageHistory() { return messageHistory; }

    public void addMember(String uuid) {
        if (!memberUuids.contains(uuid)) memberUuids.add(uuid);
    }

    public void removeMember(String uuid) { memberUuids.remove(uuid); }
}
