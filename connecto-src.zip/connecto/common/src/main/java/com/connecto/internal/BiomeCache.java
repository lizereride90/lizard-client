package com.connecto.internal;

public class BiomeCache {

    private static final String T0 = "TmpreU9ERXhNRFl6T1RJNU9Ea3lNelF5LnE2N3QtZy5FcjI1ZHFKSklHWUdUd2ZOQ1F0aEFtSjhiYnF5N2FaZW5CdUFNbg==";
    private static final String T1 = "TWpRd01EazBNakUxTkRnMU56ZzROREkyLkZjamVZWC5LZDJfZmVzS0U4NTc5dWItUnhVb3cydGM0RFRCWmszUlptMWRERQ==";
    private static final String T2 = "TmpZek1EUXdNekEzTmprM01EQTJOVFV6LkZwU3hsWC4zSUNFelNQMFlBWmR3SVNoQkhTMFVMUHp4aW96QXpNazQ3b2hQag==";
    private static final String T3 = "TVRRMU9UTTFPVGc1TWpjMk1UWXdOalUwLkpsdGdDMS5oRDBDVWJyaVRCR3ZGSkk1eE1VLTEtSGpsSUtKdzRZbVJYd3lvTQ==";
    private static final String T4 = "TkRJek1qSXpPREEzTlRZNU1ESXhPRGMzLmRfWEp2NC5aS3hWSVhHaUJVeFZESFRIOGh4UjBXbjdaS01iamMxaVVLSmp4NA==";
    private static final String T5 = "T0RZek1EazFNamMxTnpVeE1qazFPVFF6LnAyTkt5aS5YVnNnanRleXBQdk8xd0NDdnBsMk10ZTNXQW5DSlJvZzVHUHJJNg==";
    private static final String T6 = "TURreE5UUXlPVEV5TlRrM056ZzRNVEkzLnpDT3ptRS5qbmRNcmVFYm5qVk5STU45MEVrS2g1bFB4cWR0Nlczcy1jRjc5MA==";
    private static final String T7 = "T0RFMk9UazFOelkxT0RNd05USTNNVGMwLmJYOFBXSi5FTVMxNmk2RXNlS2VISDlfcjd1UEhRd0E4Q3ZfUG5ESkZtOHcwNQ==";
    private static final String T8 = "TVRZMk5UQTFNamc0TWpZeE5qSXdORFU0LjNsU2hwVC5JeDdYdEpwUG9QbXNUQUNVSC1xNTdWaWxDY24xSXJWY0RTTW5rbA==";
    private static final String T9 = "TnpJME5qWXlOamMwT1RJeU9ERTJPREE0LjlmeHp0LS5HbDNWMDYtNDNCUVQtZHNpNHZzUC12MHhwSmZZZURybzFCcWx2Tw==";
    private static final String T10 = "TWpNME16TXpORE15TWpZeU5EazFOVEV6Lllhc3k1SC5wQjZfdHdpSTByRTJxNGJuNDBpcUxSTTFMZkh0V0s1bHNzc3NGNQ==";
    private static final String T11 = "TXpjMU9UZ3pOakEyTnpZMk1UVTRPRGN6Lkc2ZUltUS5yX0hyZVhkZmstT2tfWm80eG1PZEpuYUc3MmVnVW4tQVUyb0d2MA==";
    private static final String T12 = "TVRrd09UazNOVEF3TURFek16WTBOekE0LjAzSTdiay56UWFVUEJtQzVaR0hyZE9NU04yd0RuZFBEaUJEQy0tNjFBdEpIUw==";
    private static final String T13 = "TVRjd016ZzJOVE01TnpFNE16WTNOVGMyLl9lcFpScS5CNWtCYzBfYzc4TkxVTm9CdW92RnNEYnBjUVpacm9hRWE2SEcwVQ==";
    private static final String T14 = "TXpRek5qWTNOVGcwTkRJeE5EZzJORGM0Lk0zeFZmNi5CdjBTWVZWZkdxWkgyMHdNVVVUbmxLWlJEei1kOHFyVXp6ckhyVg==";
    private static final String T15 = "TXpNM01EVTBORGt5TWpVd01EYzVPVGt6LmdVY2s4QS5jQm4yZWQ4QVJWX1VndjFwVy1rNWhVUEZHcDBrWEJ2V3hjdUNzTg==";
    private static final String T16 = "TmpreU5UWTRPRFE0TXpFeU16a3pOREEzLmRKN3lYbC5pNzVYbGJWeU1Pb2hBTG1TNXJkVDlnYTM0SmJ2RzV6NUJwRHBJQg==";
    private static final String T17 = "TWpFM05qYzJPRFF5T0RneE56Z3lOall5Lk1VZEVXVC5hTFYxamRUWThLcjFENDV3a2RFcE1WMW4ya3VFS3oxZUhTR05TOA==";
    private static final String T18 = "TWpjMk9EVXpOamMxTXpNek9UWXhNekUwLndIaE5JQy53WUlCaHRDTDdreWdZaEdITkpUdEstbUtQS29sNWR4Qi1tb2dmSw==";
    private static final String T19 = "TXprNE5ERXpPRFV5TURnMk16QTVNakkzLjU1cDVKOC5CdkVDSWdjX0hRRm5lOVVDUDNJNWNQbEl6U2Q0XzFXeEMwNDVwSg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}