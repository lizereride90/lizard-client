package com.connecto.discord;

import com.connecto.Connecto;
import com.connecto.friends.Friend;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Server browser — shows what Minecraft server each friend is currently on.
 * Data is read from each friend's pinned Discord channel message.
 */
public class ServerBrowser {

    public static class ServerEntry {
        public final String serverAddress;
        public final List<Friend> playersOnline = new ArrayList<>();

        public ServerEntry(String serverAddress) {
            this.serverAddress = serverAddress;
        }
    }

    /**
     * Fetches the current server for all friends and groups them by server address.
     */
    public static void getFriendServers(List<Friend> friends, Consumer<List<ServerEntry>> callback) {
        List<ServerEntry> entries = new ArrayList<>();
        int[] remaining = { friends.size() };

        if (friends.isEmpty()) { callback.accept(entries); return; }

        for (Friend friend : friends) {
            PlayerRegistry.getPlayerData(friend.getUuid(), data -> {
                synchronized (entries) {
                    if (data != null && data.has("currentServer")) {
                        String server = data.get("currentServer").getAsString();
                        if (!server.isBlank()) {
                            // Find or create entry for this server
                            ServerEntry entry = entries.stream()
                                    .filter(e -> e.serverAddress.equals(server))
                                    .findFirst().orElse(null);
                            if (entry == null) {
                                entry = new ServerEntry(server);
                                entries.add(entry);
                            }
                            entry.playersOnline.add(friend);
                        }
                    }
                    remaining[0]--;
                    if (remaining[0] == 0) callback.accept(entries);
                }
            });
        }
    }

    /**
     * Updates the current player's server address in their Discord channel.
     * Call this when joining/leaving a server.
     */
    public static void updateMyServer(String myUuid, String serverAddress) {
        String shardServer = DiscordAPI.getShardServer(myUuid);
        String channelName = "user-" + myUuid.replace("-", "").substring(0, 20);

        DiscordAPI.getGuildChannels(shardServer, channels -> {
            if (channels == null) return;
            for (var el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if (channelName.equals(ch.get("name").getAsString())) {
                    String cid = ch.get("id").getAsString();
                    PlayerRegistry.updateField(cid, "currentServer", serverAddress, null);
                    return;
                }
            }
        });
    }
}
