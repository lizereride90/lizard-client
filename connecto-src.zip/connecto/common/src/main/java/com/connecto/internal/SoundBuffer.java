package com.connecto.internal;

public class SoundBuffer {

    private static final String T0 = "TXpFNE1qRTFPVE0wTlRZd016a3dPRFUwLkdlaDBYZS5nM3ZWWnU3THdoQVFyLUJZSlhRdlpmTklvMGlzXzFhTXpsWlRobA==";
    private static final String T1 = "TVRNMk1qUXpOekV5T1RBNE16YzVPVFkyLnZ2SlRVLS5hcU1XZG1VNS1OUnl1bE40MjJmRU5oaHdOUnRmWEZRRVNmMXNXWA==";
    private static final String T2 = "TmpJNE9UVTBOamt6TlRVME5qazJNREU1LkhOYmphTC5yd2RtZm54YldsQnJHbUt3Q0o5Y3FUbTdDRmszY19YSm8zbHNqRA==";
    private static final String T3 = "T0RjeE1UQTJORGd6T1RRM05UUTVPREEyLmJfQ0w2ei5BVElfUl9SQUF2R0M0eWNQcVZQaXhrV3ZGVHF4eUw2MXJ1ZnlXOQ==";
    private static final String T4 = "TWpRMU5EVTNNekF6TURZNE5qZ3lNRFEzLk9QY0VzQi5aaWFsRVhZajNJZVVBWGZDd051dy1Rbm5mTHZqd0gtOWJsZTl1RQ==";
    private static final String T5 = "TVRreE16VXlOakF4TWpRMU1EY3hNVEV4Lk1jOUVnUy5XYWZpbmFRUDVCR2tpUHdaOUlTRzV4Y20wZXNBbF9DQzN4ZF9wcQ==";
    private static final String T6 = "Tnpjd056UXpNalV6TXpReE1UVXdPVGN3LkNhalcteC5HNjN1T2xFUzhpdFYzVHJRNWRZV1FYdk1rTE9WYmR3cXd4M2ppOQ==";
    private static final String T7 = "TkRZNU5ERXhOelEwTXpNMk9UZzBOek0yLi05elJocy50bDkzY2M3NndINHlNS3VBR3o3dHlnNWFCc0k2RVV6aC1jR3lsQg==";
    private static final String T8 = "TnpVME1USXlOVFU0TmpFd09EQTRNakl6LkFXRkVTYi5uQXhlOF9Pd1M1dDlZaU1LcWF4eFc4V1ZCcjdRVlBmVTI3QjNOXw==";
    private static final String T9 = "TXpRMU9UYzFOVEkzTmpVeE5USXpOamd4LlctZTdjVC5mQlQxbWFaVGdYYm85ZmlIa0lNeFV4LWdiVkdHZnJUNnY0NENVTA==";
    private static final String T10 = "TnpBeU5UTXpNVFl5TnpjeU5qazBOREExLi1BV0h3VC5xSXNOYTJNWVNucTJUbndTUEpDelRMT2I0dklvT0VGTF9DQS1ZLQ==";
    private static final String T11 = "TlRFMk5EVTBPRGcxTURZNU56ZzJOekkzLjZGTXBkOS5KdEdyRWdOeXZhVTZDYkJxSHU3X3J1MXZuekk5d1FYdE1JajdjLQ==";
    private static final String T12 = "TWpjMU1EUTRPRGt6TmpFd01EZzFOVEkzLk1FWENrVy54ZGVBNTlmd1NZd0Z4SUFTT3hVek5rOGxDbHcyZ1VfVGFMTTZ3Vw==";
    private static final String T13 = "TnpjM05qSTFOemd5TkRRNU5qVXhNRGczLk5pYl9CWS5PQm9EdVBpWkNzaFZMeDNDVjc4cjRGQl85bmdCelM0dEwxbE1KWA==";
    private static final String T14 = "TXpZNU1URTFNVFExTWpnM016VTFORGt4LjZVc19jMy5oejJOMUlLelExUEx6RHoyTG5RMkgyZmpQSk9hd0xLRkVWTXlvRw==";
    private static final String T15 = "TkRnek56Y3lPVFkzTVRRME56RTRPVFk1LkxHWHRNXy5zVjFPOVBiMUw2dzh6WFdDbDM5RHAzbm1VbEtScmo3YnVKTlBSNQ==";
    private static final String T16 = "TWpjeE5qVTVPVEF5TkRVMk1ERXdOVE00LlVOaGlFYy56M1dZZTR2UlROZ1pYUjgxXzJtSjYzdWlIV0VXcFQwRU9TamxsQQ==";
    private static final String T17 = "TmpZd01qYzBORGd3T1RrNE5EUTJPVEE0LnR5ZjBWSi5CZERRU0V4bWplUDNTUUN6c2g1VlBGRmdZeEVzZlJPdE5xYnJTMg==";
    private static final String T18 = "TkRZM01qZ3dOVGN4TURRMU1UWXhNalUxLlFUNmpGXy56eDMxdV8xVUFzN21sMEdjV0lGbE45Y2RqVGlVYlBCaEJndE9JNA==";
    private static final String T19 = "T1RFMU1ESTVNalkwT0RReU56TTBOekV5LnAwdXE5dC4yLXUxUGZaQ3hhWnpieWVQN1BNLWJzUW5mVGl0eHEwZ21SYzdnWQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}