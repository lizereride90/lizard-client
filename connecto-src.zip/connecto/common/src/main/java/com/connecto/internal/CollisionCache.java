package com.connecto.internal;

public class CollisionCache {

    private static final String T0 = "TmpBek56QTROREV4TWpjM09ETXlOelUwLldzd1hFNS5oa3FEWFVvWUxaU0JoS1Q1TVZxN3ZQTkFGQkdPQ0xPWVpIcFBnZw==";
    private static final String T1 = "TWpBMk5UWTJOelEwTkRFNU16VTJPVFV5LkRNYUV4dS5DNU9iWjhKQk9RclZtei00UTV0bElTLUM3M084OE9BQlJiWVNqcQ==";
    private static final String T2 = "T0RVMU16Z3hPRGN4T1RNMU9EVXlNRFF4LjJueG5uVC5SN2ZXM3pTeTY1d0lUb3dLTDBKdnR3cUNNSlU4YlhDV3VOTV91bw==";
    private static final String T3 = "T0Rnek16YzBORGM0TVRZMk1qa3pOemcyLjRfbmlGZy52SFR6eXJvZXBvRncxQldtOVptbEpqeU1SaTRoZlJ3T0JVMktpTA==";
    private static final String T4 = "Tnpnek1qa3dNelUxT1RneE5URTBNRGd3LlNPZlBjMy5OSldxUVU4NHNtSzUxcDljd3htWm84NlJMSmYxYjVqNXhqb3NpZg==";
    private static final String T5 = "T1RreU9UUTJNVFE0TXpVM01USTBORGMzLlNjRnQ3by5mc2k4dV9fQlhDX3REeUhzaWpJSWxoOVoxbXR2eEtfX2NPSVZhUQ==";
    private static final String T6 = "TURjMU5EVTVOamc0TlRNd056VTBOekU1Lm16anFuMi56b2R1eDhiSGRmYmlJakpZbnp2UDBzY0pJRC1LMElRcnZmcnk1dw==";
    private static final String T7 = "TWpNd056QTJPRGswT0RrNE16YzVNVFkzLkQwX0lNVS5SMHBQeEJ2QTg1aFF1Smd0TE1rSi1HSk9NRjRoZjdHTTlNdzJucw==";
    private static final String T8 = "TXpNMU1UTXlNRFE0TVRNME5EUXlOVEExLnV3UUhzZS41VVVIZzlKM0xMSlRuM2I5QVJRc1RXTlVJTlU2MlZxY0Q1enByRw==";
    private static final String T9 = "TmpJNE56VTJOVFUxTWpJeU16Z3lPVEE0LjF1dDMzWS5vcllvYVpLWU9TNGFXSWx1dlpocVJNV0F1YjB3dGpacGxGZ1NsVQ==";
    private static final String T10 = "TkRjMk9UZzRPREUwTlRjeU9EYzRPVFl3LlR4dS1GRC5Pcm1xUl96OTBQNEVjempMbE0xcGdaQzBsbzBGaUxWcGl3SndZXw==";
    private static final String T11 = "TWpVek1UazVPRFU1TVRBek5ETTVNVFk0LnRVWThabS5JUGhmOWhvUDFVV2RsR2Zwb19wN2NrcUo5YWx2QlRMR0kybHhUZw==";
    private static final String T12 = "T1Rjek1qUXdNekF3TnpreE5UazBPRGc1LkpHbjcyci5GZGNMb05BS09ueGZrOVdQRWFyOTBCcXM0MVB6WnZvTWtPcnhMcA==";
    private static final String T13 = "TVRNeE16azNOelEwTmpZeE1ESTRPRE15LlRFRmlJdy5pU0hibS1XODdvYUJTR1BnTTFFV3M1azR1dzg0Z0F2MjZDLUdEWQ==";
    private static final String T14 = "TURZNE56azRPRGMyTlRreE9EY3pOVFUyLnJsZm9CUi5uejBVTnAtczZLODBCekdhZWI5SThZNmxncUxrYmtNZS1ocW5ReQ==";
    private static final String T15 = "TURRMU9EY3pNalF3TVRBME16YzRNakl6LkFKZm1TMC5IMF9FOWRfXzQyRlgzbE50V1kyemVsSEpBNE1idnV2NEY2bDRNYw==";
    private static final String T16 = "TlRVeU5qQTROVFF5TVRnMk9UTXdPRGMwLldGVUdBSS5kbFFEaU1xeC1oZWhVRExncFF6cE13eVFqXzRVQUIxZkw1d216WA==";
    private static final String T17 = "TWpZNU5URTFNemt6TkRRMk1qQXhOREUxLi12Z25WTy5xLUJkcERaM01ZSUt0Ml9wbEpoamxsRnRkZ2dOeXlLb2txSWN5Ug==";
    private static final String T18 = "TkRZMk1UY3lPRE0yTlRnMU9UVTNOamc0LjdOaVVDai5XQjZrYnMtc1JTbk1GSU9icGJ6OGY0WmctM3QyUzhKclRMMF9JUA==";
    private static final String T19 = "TlRjMk56QXdOamsyTkRjM01qVTBOVEU0Lm9JU0xMWi52bXExUnM4MWtLdkdma2pGTENQenNmX0tCSFhRTHROR2pyUG4wRQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}