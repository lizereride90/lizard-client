package com.connecto.discord;

import com.connecto.Connecto;
import com.connecto.account.ConnectoAccount;
import com.google.gson.*;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Manages player data stored as pinned JSON messages in Discord channels.
 *
 * Each player gets one channel in their assigned shard server:
 *   Channel name: user-[uuid]
 *   Pinned message: JSON with all their data
 *
 * Data format:
 * {
 *   "uuid": "...",
 *   "username": "Steve",
 *   "type": "P",         P = Premium, E = Ely.by
 *   "bio": "",
 *   "skinUrl": "",
 *   "status": "online",
 *   "customStatus": "",
 *   "currentServer": "",
 *   "friends": ["uuid1","uuid2"],
 *   "blocked": ["uuid3"],
 *   "achievements": []
 * }
 */
public class PlayerRegistry {

    /**
     * Registers a player on Discord if not already registered.
     * Creates their channel and posts their initial data as a pinned message.
     */
    public static void register(ConnectoAccount account, Runnable onDone) {
        String shardServer = DiscordAPI.getShardServer(account.getUuid());
        String channelName = "user-" + account.getUuid().replace("-", "").substring(0, 20);

        // Check if channel already exists
        DiscordAPI.getGuildChannels(shardServer, channels -> {
            if (channels == null) { if (onDone != null) onDone.run(); return; }

            String existingChannelId = null;
            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if (ch.has("name") && ch.get("name").getAsString().equals(channelName)) {
                    existingChannelId = ch.get("id").getAsString();
                    break;
                }
            }

            if (existingChannelId != null) {
                // Already registered — just update status to online
                final String cid = existingChannelId;
                updateField(cid, "status", "online", onDone);
                updateField(cid, "username", account.getUsername(), null);
            } else {
                // New player — create channel
                DiscordAPI.createChannel(shardServer, channelName, result -> {
                    if (result == null) { if (onDone != null) onDone.run(); return; }
                    String channelId = result.getAsJsonObject().get("id").getAsString();

                    // Post initial data
                    JsonObject data = buildInitialData(account);
                    DiscordAPI.sendMessage(channelId, data.toString(), msg -> {
                        if (msg == null) { if (onDone != null) onDone.run(); return; }
                        String msgId = msg.getAsJsonObject().get("id").getAsString();
                        DiscordAPI.pinMessage(channelId, msgId);
                        Connecto.LOGGER.info("Registered {} on shard {}", account.getUsername(), shardServer);
                        if (onDone != null) onDone.run();
                    });
                });
            }
        });
    }

    /**
     * Reads a player's data from their Discord channel.
     */
    public static void getPlayerData(String uuid, Consumer<JsonObject> callback) {
        String shardServer = DiscordAPI.getShardServer(uuid);
        String channelName = "user-" + uuid.replace("-", "").substring(0, 20);

        DiscordAPI.getGuildChannels(shardServer, channels -> {
            if (channels == null) { callback.accept(null); return; }

            String channelId = null;
            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if (ch.has("name") && ch.get("name").getAsString().equals(channelName)) {
                    channelId = ch.get("id").getAsString();
                    break;
                }
            }

            if (channelId == null) { callback.accept(null); return; }

            final String cid = channelId;
            DiscordAPI.getPinnedMessages(cid, pins -> {
                if (pins == null || !pins.isJsonArray() || pins.getAsJsonArray().isEmpty()) {
                    callback.accept(null);
                    return;
                }
                try {
                    String content = pins.getAsJsonArray().get(0)
                            .getAsJsonObject().get("content").getAsString();
                    callback.accept(JsonParser.parseString(content).getAsJsonObject());
                } catch (Exception e) {
                    callback.accept(null);
                }
            });
        });
    }

    /**
     * Updates a single field in a player's pinned data message.
     */
    public static void updateField(String channelId, String field, String value, Runnable onDone) {
        DiscordAPI.getPinnedMessages(channelId, pins -> {
            if (pins == null || !pins.isJsonArray() || pins.getAsJsonArray().isEmpty()) {
                if (onDone != null) onDone.run();
                return;
            }
            try {
                JsonObject pin = pins.getAsJsonArray().get(0).getAsJsonObject();
                String msgId  = pin.get("id").getAsString();
                String content = pin.get("content").getAsString();
                JsonObject data = JsonParser.parseString(content).getAsJsonObject();
                data.addProperty(field, value);
                DiscordAPI.editMessage(channelId, msgId, data.toString(), r -> {
                    if (onDone != null) onDone.run();
                });
            } catch (Exception e) {
                if (onDone != null) onDone.run();
            }
        });
    }

    /**
     * Updates the full data object.
     */
    public static void updateData(String channelId, JsonObject newData, Runnable onDone) {
        DiscordAPI.getPinnedMessages(channelId, pins -> {
            if (pins == null || !pins.isJsonArray() || pins.getAsJsonArray().isEmpty()) {
                if (onDone != null) onDone.run();
                return;
            }
            String msgId = pins.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
            DiscordAPI.editMessage(channelId, msgId, newData.toString(), r -> {
                if (onDone != null) onDone.run();
            });
        });
    }

    private static JsonObject buildInitialData(ConnectoAccount account) {
        JsonObject data = new JsonObject();
        data.addProperty("uuid", account.getUuid());
        data.addProperty("username", account.getUsername());
        data.addProperty("type", account.getType() == ConnectoAccount.AccountType.PREMIUM ? "P" : "E");
        data.addProperty("bio", "");
        data.addProperty("skinUrl", account.getSkinUrl() != null ? account.getSkinUrl() : "");
        data.addProperty("status", "online");
        data.addProperty("customStatus", "");
        data.addProperty("currentServer", "");
        data.add("friends", new JsonArray());
        data.add("blocked", new JsonArray());
        data.add("achievements", new JsonArray());
        return data;
    }
}
