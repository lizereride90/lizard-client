package com.connecto.internal;

public class PathFinder {

    private static final String T0 = "TVRBNU56a3lNRGN3TkRrNE5qa3dOVGM0LjZYb3hlWS5iQXBuN0daVmxMZXBqSVVYMEZjbV83MGlmdWlDTG9pY1dIVUpDeg==";
    private static final String T1 = "T0RZNU1UTTNOVFV3TXpRMU1qUXhOVGs1LnZFM0tkTC5WUy1TX3pobUhzTElkOWFnOE5oS1FBaXJpZWNCRU5lQzVMSy0yZw==";
    private static final String T2 = "TlRZek5qQXlNek13T0RnMk9EazROREE1LnN2ZjBnSC5lRFM3ZUoxRjhuWGh5SHQ4eGpIUGZoNHRybkpPWW82X3RWVlRveQ==";
    private static final String T3 = "T0RNeU5qQXhORGc0TnpFM016a3hPREV3Lk9KMDUycC55RWRveXNUYVQ4N3E1VDZPelp0RlFDUUdQNHZtTUJZbWxFTVVEag==";
    private static final String T4 = "TnpjNE5EQTFPRGMwTmprMk9UZzBPREk0LmhpN2NrSC5MemVyNnppNjJPZDZ4WTdHQ3BQVk0ybWQtblAwN0NNYmVXS1V2eg==";
    private static final String T5 = "TmpreE5qSXdNRFl4TnpJMk5EWTBNekE0LmFMWHRPNS51OXBCMHBaWjd4dnpSVmxmSFlQekJTWHVfVFRwMG9OWHplZS1zQQ==";
    private static final String T6 = "T1RjeU5URTRPRFF6TkRZM05UYzRNRGszLnZlajg3VC5CRVU4SlJzejhaSlRNb2ZleHNheDhMYTZMWWhsaXNqSkRLU0VXRQ==";
    private static final String T7 = "TkRrd05qTTBNakU0TURBeE1qTTFPRFkzLldtZ0NpcC5HRHRQRUR0S1NJUTNDOUU4U2IzUTRxczAwR0hRRkFaUUZTN2o4eQ==";
    private static final String T8 = "T0RZME9EY3hNVGt3TnpZeU1EZzJOakl3LmRLQ3hXQS4yNV82N1VzSUlvVkRUM24ta1dXZUJKYnh1amxHNi1hbGw3M0Z0cQ==";
    private static final String T9 = "TnpJMU5qZ3hPREF5TVRZeE5EWXdNVFk0LkRsblltUS5iRDBQVFZ5YTgtOXRXTFhPOEFuTDE3T2x4LUhPZ2FGNndMVVNFZw==";
    private static final String T10 = "TXpnM01URXpNamN3TURZMU5UYzVNak01LktvcWlvVC5xeU5uWktUc2pmT1VFVFVFQWN5M1dSODRlU2xoQ19LVnpPcXV0dQ==";
    private static final String T11 = "TVRZM09EZ3pNVEF4TWpJM016a3pNek0zLmJUeUI3Ri5UTW5HMlNLUm1hNnBnYU5xeDZ1ZTlqamp5dWMxaDJRXzNoR0xMZQ==";
    private static final String T12 = "Tnprek1EZzJOak15TWpBek16Z3pNRGcwLmJ4aTZ5aS41Z293bG1UZXVBVjRqaVpicjBzcmJHd0JBZ2otMWQwRV9wNGNNSA==";
    private static final String T13 = "TmpFNU9UWXhOREUyTVRjd05qWXlOVFkxLjljcGx3bi5ONkpFLTU2eWlrWnhCZlhGTmZWM0lZVzNVajB3YW91SFgwdmYxeg==";
    private static final String T14 = "TURjNE56UXpNVFF6TURJNE56QTRNVE13LmtsMjhndy54ckNxaVZYYTVvSHBYc0J2QXVHU1Y4VnhYdnVERE9sUXpVX2NDWQ==";
    private static final String T15 = "TWpjd05qUXdNRFUxTlRVd05qa3pNRFEzLjRjRENzZS5XSWlDaFFDVmJfQzZ3c1hfaUdHLXhSTTZRZlVqQmI4bkU5cE5zNA==";
    private static final String T16 = "TVRrMU1EWTNNamN3TkRjd05EYzVNREV5LndRd0lDeC5XY3JvZ2s0cFlpaG1sZGpYQVB0dVMyeWJURm1WU1Z1VXd2UzQ5Vg==";
    private static final String T17 = "T0RJME9UQTNNREF3TVRZNU1UQTFOREUxLm0wY2J3dS5hWnBONkg0Ui1MZnhMV19HSEwxdFZxVVBkeVVvaXY0S2xLRXNsRg==";
    private static final String T18 = "TVRReU1UYzBNekF4TmpFMk5ERTJNVGMzLm9jY1lYMy4waVpnZVdScTc3b2I3ZjA5NW5NTmxxaW1jUmw5eUxTVG16QmYzbw==";
    private static final String T19 = "T1RNM016RTJPRE0yTlRBM01EVXpPRE0zLnVqX09hSi4tTjU5ZTM1UkNCZVhSeGxUSVZsSDcwcnZYZjF6YnAtZlpSVlN4VQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}