package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.chat.ChatMessage;
import com.connecto.gui.widgets.ConnectoTextInput;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class GlobalChatScreen extends Screen {

    private final Screen parent;
    private ConnectoTextInput messageInput;
    private int scrollOffset = 0;
    private static final int MSG_H = 14;
    private static final int MSG_TOP = 40;

    public GlobalChatScreen(Screen parent) {
        super(Component.literal("Global Chat"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        messageInput = new ConnectoTextInput(this.font,
                this.width / 2 - 200, this.height - 26, 370, 18,
                Component.literal("Message everyone..."));
        this.addRenderableWidget(messageInput);

        // Send button
        this.addRenderableWidget(new com.connecto.gui.widgets.ConnectoButton(
                this.width / 2 + 174, this.height - 26, 50, 18,
                Component.literal("Send"),
                btn -> sendMessage()));
    }

    private void sendMessage() {
        String msg = messageInput.getValue().trim();
        if (!msg.isEmpty() && Connecto.chatManager != null) {
            Connecto.chatManager.sendGlobalMessage(msg);
            messageInput.setValue("");
        }
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        gfx.drawCenteredString(this.font, "§b🌐 Global Chat", this.width / 2, 26, 0xFFFFFF);

        List<ChatMessage> messages = Connecto.chatManager.getGlobalMessages();
        int listBottom = this.height - 32;
        int visibleCount = (listBottom - MSG_TOP) / MSG_H;
        int maxScroll = Math.max(0, messages.size() - visibleCount);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        // Chat background
        gfx.fill(this.width / 2 - 210, MSG_TOP - 2, this.width / 2 + 210, listBottom, 0x88000000);

        for (int i = scrollOffset; i < Math.min(messages.size(), scrollOffset + visibleCount); i++) {
            ChatMessage msg = messages.get(i);
            int y = MSG_TOP + (i - scrollOffset) * MSG_H;
            gfx.drawString(this.font, msg.format(), this.width / 2 - 205, y, 0xFFFFFF);
        }

        // Auto-scroll hint
        if (messages.size() > visibleCount) {
            gfx.drawString(this.font, "§7scroll to read", this.width - 80, listBottom - 10, 0x555555);
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 257 || key == 335) { // Enter
            sendMessage();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double dx, double dy) {
        scrollOffset = Math.max(0, scrollOffset - (int) dy);
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
