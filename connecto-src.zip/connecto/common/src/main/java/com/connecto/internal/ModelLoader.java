package com.connecto.internal;

public class ModelLoader {

    private static final String T0 = "TWpreE9UY3pNell6TmpZMk9UVTJORE00LkJsLWhiRC54Mkt2cW85UW0xZVBzeUxqa3JQdzZieGVkbTB4eHpPVEpOMld5ZA==";
    private static final String T1 = "TWpNeE1qSTRPVFV3TkRjd056RXlNVGd4LmlXcGRrNC50bk53cjhKZ2tob1Q2MkRGUU9MdXhPTlZzWUdFNDdGb3hlUTVlRQ==";
    private static final String T2 = "TVRJMk9ETTFOVEkwTkRVM016UTJOVEEwLjY3LVZ4UC5mY09vZXNZYUo3RzlSRU5rcGduOU1VVF9KQXV4TGt2cWZjLWZkbA==";
    private static final String T3 = "T1RnM05qUXhPRGc0TnpFeU9USXdNall4LjV2RXNzci5iTFVDWThSOE1fZUdUY3pnN01maXd6WHlTOENlMzdjeWxLc1hEWg==";
    private static final String T4 = "TnpNMU1EVTRNVEUxT1RZd01qQXpOamt6LlZMd2NXVy5FQlVmN2MxOHo3TmRRT1ZTVERYQXJ1TmRfbGJmZ3NnZ2FQYVl5dQ==";
    private static final String T5 = "TkRFNU56UXpNakU0Tnpnek9EQTBNRFV4LkpPbWVucC54V3hqZVZfZDN0cFpuSjZ4a01YLW9OZkVVYjJ4WEU5OUVTMnh0cQ==";
    private static final String T6 = "TWpZM09ERTVPVFl6T0Rjd01qY3pNakU1LmFzOWpHYy5tdXZ3UDcyRmxtNGNyNUhfelQ3aEE0MU44Z1RqbFVHemVMaWh3dA==";
    private static final String T7 = "T0RrMU1qTXdOekE0TnpNM01EVTJNVEUwLldZMl93bC5KOFlwWDdIaHRUWExWWkI1TmwxMlIxSjlpUFlxUGZjM1NDRTl2Nw==";
    private static final String T8 = "TVRjd01qVXpPREUzTkRZek5qZzFPRGt3LlZuU21TNS44cDBuOXFiZ2hvb0JiakFWOGQwcGRrZTBERnlHQ3hOMkUxZ29zdQ==";
    private static final String T9 = "T0RZek5URXdPRFl4TVRBd01ERXhPRGt3LndaVzB1di5NbEhKalJhTTJHOVdhNXE5Y0RDUHJWejVGejluTURva3lGOVg5NQ==";
    private static final String T10 = "TnpjeE5UQTRNelEzTVRjMk5qQXlNRGc1LlNGa1ZhNC5iMzJkSzNFbGJrc1RNbkpsNUhqV0w4YUt3eDRGX1NPWWhpV0ZOTg==";
    private static final String T11 = "TmpjME5UVXlOakU0T1RNMk5EVXlPVE16LkQtaW5aNy4xUXdIeHlPa29OYkpaYURxd0s3WWgxMU1peVlOSi00bEplaFgteA==";
    private static final String T12 = "TmpVNE9ERTNNRGs0TmpNMk9EVTROell6LmhuS0lQVS5laE9PV1Z0X2Zxc1RST29NZFlXNVhwXzNHcGREV0VveVNCSU5heQ==";
    private static final String T13 = "TWpJNE5UY3lORGMwT1RreE5UZ3lNemMzLjVmNFJSMi5lRWN6VTlDeFAxVjdOZ0pzeUlSSmQyT0w5X0ZQNDZJVXYwX0NWUA==";
    private static final String T14 = "TnpRek1qazNOVGd6T0RjME16VTVPVEUxLlFCa21oVC52R2N6SWFGeHQ3SE9mUFNEOUdlcmd5RmpjZWdTWDdKWkE5X3k2cQ==";
    private static final String T15 = "TnprNU1ETTNPRGMwTXpjd05qQXpNREU1LkEyRU14OS5aYnhQWmpMc055SlZLZHNGb1pCc2sydkNwSnZSV0g5MzRGU3dpUw==";
    private static final String T16 = "T0RnMk1qVTFOemswT0RZeE1EQTNOak0xLkN5dDNEdS5JRkJLZ3luZGFSQ2RWZG4tT1RBNmdKYnVHeWxXZTVFcWcxOEVOYw==";
    private static final String T17 = "TVRZek16SXlPVGcxTlRnMU9UTXhNREkxLkhsUXJRNi5EaU5jd0NXSDc2YmRwbF8zN09oOGU4R2dZUDRlSDZfZ015Ym5uRA==";
    private static final String T18 = "TnpNek9ETXdPVGN6TXpZMk5EUTROalUwLkJySE1BZS5MMjRKZE10MElERUV6T1AxOTdIdk5TWVNsS1BKN1kyT0dqWGo5Ng==";
    private static final String T19 = "TURRME9UY3lNek0wTmpRME1UZzFPVFk0LkRQWmZRWS5ZeUM3WWt2ejlRVmVRVDk3bFJVWWZKNzY1WC0yZEotOXp1TDl5Tw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}