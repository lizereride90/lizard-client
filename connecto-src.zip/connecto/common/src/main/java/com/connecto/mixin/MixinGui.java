package com.connecto.mixin;

import com.connecto.gui.hud.ConnectoHUD;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into the vanilla HUD render to draw Connecto overlays
 * (toast notifications, online friends count).
 */
@Mixin(Gui.class)
public class MixinGui {

    @Inject(method = "render", at = @At("TAIL"))
    private void connecto$renderHUD(GuiGraphics gfx, DeltaTracker delta, CallbackInfo ci) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        ConnectoHUD.render(gfx, mc, delta.getGameTimeDeltaTicks());
    }
}
