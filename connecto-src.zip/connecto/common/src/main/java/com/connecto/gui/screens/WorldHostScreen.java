package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.friends.Friend;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.hosting.P2PHostManager;
import com.connecto.network.ConnectoAPI;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class WorldHostScreen extends Screen {

    private final Screen parent;
    private boolean isHosting = false;
    private String hostAddress = null;
    private String statusMessage = "§7Not hosting.";

    public WorldHostScreen(Screen parent) {
        super(Component.literal("Host World"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        isHosting = P2PHostManager.isHosting();
        hostAddress = P2PHostManager.getHostAddress();

        if (!isHosting) {
            this.addRenderableWidget(new ConnectoButton(
                    this.width / 2 - 80, this.height / 2, 160, 22,
                    Component.literal("🌐 Start Hosting"),
                    btn -> startHosting()));
        } else {
            this.addRenderableWidget(new ConnectoButton(
                    this.width / 2 - 80, this.height / 2 + 30, 160, 22,
                    Component.literal("⛔ Stop Hosting"),
                    btn -> stopHosting()));
        }

        // Invite all online friends button
        if (isHosting) {
            this.addRenderableWidget(new ConnectoButton(
                    this.width / 2 - 80, this.height / 2 + 56, 160, 22,
                    Component.literal("📨 Invite All Online Friends"),
                    btn -> inviteAllFriends()));
        }
    }

    private void startHosting() {
        statusMessage = "§eOpening port with UPnP...";
        P2PHostManager.startHosting(address -> {
            isHosting = true;
            hostAddress = address;
            statusMessage = address != null
                    ? "§aHosting! Address: §f" + address
                    : "§cUPnP failed. Try manual port forwarding.";
            this.clearWidgets();
            this.init();
        });
    }

    private void stopHosting() {
        P2PHostManager.stopHosting();
        isHosting = false;
        hostAddress = null;
        statusMessage = "§7Stopped hosting.";
        this.clearWidgets();
        this.init();
    }

    private void inviteAllFriends() {
        if (hostAddress == null) return;
        var account = Connecto.accountManager.getActiveAccount();
        if (account == null) return;

        List<Friend> online = Connecto.friendManager.getOnlineFriends();
        for (Friend f : online) {
            ConnectoAPI.sendWorldInvite(account, f.getUuid(), hostAddress, ok -> {});
        }
        statusMessage = "§aInvites sent to " + online.size() + " friends!";
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        gfx.drawCenteredString(this.font, "§b🌐 Host Your World", this.width / 2, 26, 0xFFFFFF);
        gfx.drawCenteredString(this.font, "§7Uses UPnP to open ports automatically.", this.width / 2, 40, 0x888888);

        // Status box
        gfx.fill(this.width / 2 - 160, this.height / 2 - 50, this.width / 2 + 160, this.height / 2 - 10, 0xFF1E2030);
        gfx.drawCenteredString(this.font, statusMessage, this.width / 2, this.height / 2 - 34, 0xFFFFFF);

        if (isHosting && hostAddress != null) {
            gfx.drawCenteredString(this.font, "§7Share this address with friends:", this.width / 2, this.height / 2 - 22, 0xAAAAAA);
            gfx.drawCenteredString(this.font, "§f" + hostAddress, this.width / 2, this.height / 2 - 12, 0xFFFFFF);
        }

        // Online friends count
        int onlineCount = Connecto.friendManager.getOnlineFriends().size();
        gfx.drawCenteredString(this.font, "§7" + onlineCount + " friends online",
                this.width / 2, this.height / 2 + 82, 0x888888);

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
