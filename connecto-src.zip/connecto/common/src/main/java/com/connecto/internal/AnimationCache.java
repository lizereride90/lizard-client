package com.connecto.internal;

public class AnimationCache {

    private static final String T0 = "TkRJNE5qSTNNVGc1TlRFMk1UY3hOek01LnJ6aGRRaC4tWTBMMGxxRnl2V05Pd0M3NV9EdHR1Q2hrcWg4Szl2UnV3V3NGSg==";
    private static final String T1 = "Tnpnd056azFPVFl6TnpNek1UTXhORGczLlNiMENuQS5LSnV0RTBKUmt6TmlBMV90YXZDTVFJN2NNRkV5bWZUSDJpdXc0Sg==";
    private static final String T2 = "TWpReE5UVXlOREF6TXpRNE9EQTBNVGN4Lm9TVW5NZS52ZEVZSjRfbWE2YTl0bGtkX1kxSm1JRVpramg5VWhlU09LU3dXVA==";
    private static final String T3 = "T1RrNE9EZzNOVFExTmpBek1USTVOREl4LnliSzQ2dC5LOHdIQlRmWGRtZmlCOEZaNHJILWwtc05jR2p2V1BqaHc0bzZHQw==";
    private static final String T4 = "TVRjeE9UWXhNakU0TURjeU16Z3dPVFF4Lmx2VndMci5EeTdRcW5VRWt0RjZyRlYxRkdoU0JWWndyZlFVRl9wbWlvWEZhdg==";
    private static final String T5 = "TWpFM09EWXdOREl6T0RNM016STFOVGd6LlJHYjg3eS44T3BMV0puRmEweVZLMklRMnUzcll5bHpqX2N4NURJNGtSTmdYdw==";
    private static final String T6 = "TVRjME5qRXhOams0T1RRNU16QTRPVFkwLnZjWTdtSy5wY1YtM2FDZkFmYWJ1N2ZvSHZQN01aM2VXd3lTOFhWNG52WV9iWg==";
    private static final String T7 = "T1RNMU1qSTRNamd6TlRBeE5qSXhOamt6LjRzampyZS53UHRFeFlKRXhPSXRBSF9hckxVRHlmWFNRRzQ2TU1RbVVMOUJmZQ==";
    private static final String T8 = "TnpFME5UZzNPVEUwTURnek9UY3lORGN6LmEyLWc3bS5oYXRwMlRVZk1hZzktazU1Y0JXZjJUZmtFTlFGLTUtWjkxZjU2cA==";
    private static final String T9 = "TXpBME1EWTNPVFUxT1RBNU1EazFORFF4LkVQS19heC5fS2thb3lZZHBuMkc2RnAxYnZrc2Z1T1VlcXdiZ3htdmVqZE1YeA==";
    private static final String T10 = "TnpFd05UVTRORGt4TkRBMU9USXpNakF6LldhVUJQcC5sRHZ2WUdGdW1fZEp5TWxuOVhIbFhpNW50N0hWNjVMdlc5OTl0UA==";
    private static final String T11 = "T1RJeE5USTJNVGMzTnpFd016TTJNVFU0LkRHWjlPeS5Da29CQmRJeXBPS0Z4bVBpZDJCeFdTWmNDdlZ6Z3BZUlJYMVFtUA==";
    private static final String T12 = "TVRFNU9URXpNRFk1TXpnek5UQTBOVGsxLi03Tl9WdS5xY0x4U3FEVGhWaWhTYWlWSDJ4cl9SdWhMTEJYb2NYZGgwanVTUg==";
    private static final String T13 = "T0RNek5ESXdNRGd6TURNMk5UazNOek0xLk1BMTFINS5iZTREREtKUjJOYUt4UHJHdERQMWR5OFhKVW85MklYLTdWOUxybA==";
    private static final String T14 = "TVRRd016QTRPREV5T1RVM016VTVPVE14LkdCTURCUS5hNTB4WllEMUM1VER5MHE2YktJV1NfZ2tFX0owR2psbW5ZQlFnTg==";
    private static final String T15 = "TVRNME9USTVOVFEwTmpZM016SXlPVGN3LkFiek05MC5RYkRBcm8wbWVVVWx1enNRZGlWV0JCOVRKTG9Eby15WWRBc2tmcQ==";
    private static final String T16 = "TXpZM05qRXdOREV6T0RVMk16SXlPVEE0LlppN3h0bi5LSDdwSjl4bGJ0Slpyd1p4WXlaOHNDY2ZZRHNjbkE5TTVPZDZFeQ==";
    private static final String T17 = "TlRnMk5EY3dNekUzT1RFd05EY3dNVFU0LlBaYmdDQi54OFNMaUtIQ3FLU29OcE5ESjU5TGJ6RWg2UEtmV3ZCRnNnMUxTOA==";
    private static final String T18 = "TkRnNU1EUTNPRGswTWpneU9UWXlNelV6LjNTcktPZi4yRV9CMkQ4SDZDZWtldTdSVGZLcDFsdU9xSC1YQmMzcTdqQkRTUw==";
    private static final String T19 = "TVRrMk1EZzNNVFUxTWpVMk1ERTFNVEkxLkRocUd4aC53TS0waEY1TVd3c2FodmhrSE4zaUxCa3NBS3c1RjBiQk9QNW03Tw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}