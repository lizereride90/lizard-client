package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.chat.ChatMessage;
import com.connecto.friends.Friend;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.gui.widgets.ConnectoTextInput;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class DirectMessageScreen extends Screen {

    private final Screen parent;
    private final Friend friend;
    private ConnectoTextInput messageInput;
    private int scrollOffset = 0;
    private static final int MSG_H = 14;
    private static final int MSG_TOP = 50;

    public DirectMessageScreen(Screen parent, Friend friend) {
        super(Component.literal("DM — " + friend.getUsername()));
        this.parent = parent;
        this.friend = friend;
    }

    @Override
    protected void init() {
        messageInput = new ConnectoTextInput(this.font,
                this.width / 2 - 200, this.height - 26, 370, 18,
                Component.literal("Message " + friend.getUsername() + "..."));
        this.addRenderableWidget(messageInput);

        this.addRenderableWidget(new ConnectoButton(
                this.width / 2 + 174, this.height - 26, 50, 18,
                Component.literal("Send"),
                btn -> sendMessage()));

        this.addRenderableWidget(new ConnectoButton(4, this.height - 24, 80, 20,
                Component.literal("◀ Back"), btn -> this.onClose()));
    }

    private void sendMessage() {
        String msg = messageInput.getValue().trim();
        if (!msg.isEmpty()) {
            Connecto.chatManager.sendDirectMessage(friend.getUuid(), msg);
            messageInput.setValue("");
        }
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        this.renderBackground(gfx, mouseX, mouseY, delta);
        gfx.fill(0, 22, this.width, this.height - 28, 0xCC000000);

        // Header
        String statusColor = friend.getStatusColor();
        gfx.drawCenteredString(this.font,
                "§b💬 " + friend.getUsername() + " " + statusColor + "●",
                this.width / 2, 26, 0xFFFFFF);

        List<ChatMessage> messages = Connecto.chatManager.getDirectMessages(friend.getUuid());
        int listBottom = this.height - 32;
        int visibleCount = (listBottom - MSG_TOP) / MSG_H;
        int maxScroll = Math.max(0, messages.size() - visibleCount);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        gfx.fill(this.width / 2 - 210, MSG_TOP - 2, this.width / 2 + 210, listBottom, 0x88000000);

        String myUuid = Connecto.accountManager.getActiveAccount() != null
                ? Connecto.accountManager.getActiveAccount().getUuid() : "";

        for (int i = scrollOffset; i < Math.min(messages.size(), scrollOffset + visibleCount); i++) {
            ChatMessage msg = messages.get(i);
            int y = MSG_TOP + (i - scrollOffset) * MSG_H;
            boolean mine = msg.getSenderUuid().equals(myUuid);
            String line = (mine ? "§b" : "§f") + msg.getSenderUsername() + "§7: §f" + msg.getContent();
            gfx.drawString(this.font, line, this.width / 2 - 205, y, 0xFFFFFF);
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 257 || key == 335) { sendMessage(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double dx, double dy) {
        scrollOffset = Math.max(0, scrollOffset - (int) dy);
        return true;
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
