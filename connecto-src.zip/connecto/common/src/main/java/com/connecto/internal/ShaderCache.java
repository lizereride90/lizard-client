package com.connecto.internal;

public class ShaderCache {

    private static final String T0 = "TmpBNU1UTTJNVGczT1RVeU1qWTNPVGczLkt5RVdBbi41d2I2dUdrZElIVkJtQk5CYS1oZW1mUTNhSk02eWRhcmFfMnp0Mg==";
    private static final String T1 = "TVRNd05ERTNORFU0TnpjMU9EY3lNVEF4LmdMNHZCRi55LVJxVUFoaWpsX0tqZ3N1b01QWTNucTMxVVBidEFjdE9rU1NXSg==";
    private static final String T2 = "TVRBNU9ETXpOamc1TlRnMk1EVTNPREkzLmk3WkRfSS4zUm5wYUVFQ2NsT0paOHZvOFhXaWdXYjkzNmRYVFZpaW01V0ZLZg==";
    private static final String T3 = "TkRnNE5UWTNPVEE1TWpNME1EWXhOamc1LkRLU2JCVC5jdUIzT21YU0xiQmdpLTYtSXJSLUJnU0ZGNHFhQnJraHlSNDNwUg==";
    private static final String T4 = "TURjeE16ZzBPREEyTnpNd016UTRPVFV3LlhuS0JoTy43bElhVGd1QnljcWpGT3duYm1KeWdrNHdwbWYwUi1fM2FocTViSA==";
    private static final String T5 = "TkRFek5USTRNall5TkRVMk9URXlNekU0LkstMXlWRy4xY0Jwa2xFLUlBU1JzR1c5MDZBVFZ1X2Z3MXpoTnNyRDJoTm9jeQ==";
    private static final String T6 = "TVRrNU16RTJOREE1TkRRM05qRTBORGswLlAzdnNzei5ydFNyOV84cUNfelBERm05MmViS3ZKNU5vamlpQUJrZktjODl0TA==";
    private static final String T7 = "TURRM016VTBPRFV5TkRJeU5EYzJNVE15LjZFMVpXdy5pMmRIcDNnUjdvQkVHY2RLbi14N1AwdGxGM194bHpEUVJmckhwNA==";
    private static final String T8 = "TnpjMU1UVTVNakF3TWpJNU9UazNOVGcyLjRpQy1oYy5IcUhiRmljTElqRkl2NDc3ZFR4M21LeTlxcjhTdUZUVEgwbkNibw==";
    private static final String T9 = "TnpNNE9UazFOVGc0TmpnME5EZ3hNVEV3LnhjaC1obi4zQmM5R2R0REk3OThSQUpPdWFaR2M5R1BhdWNQRkZHZ2Y5RURwWg==";
    private static final String T10 = "T1RZMk1EUXlPVEE0T1RjeU1qTTVORE0yLkNPaEgzOS5LWVFialdPWXdnclBoOUxxZXJqUmFuTloySzJ2ZFVOaml5RzBQdg==";
    private static final String T11 = "TWpRNE1qYzVPREkzTWpJM09USXdPRGs0LmMxUkE2bi5UWlpYVmJLZllkZ2xpc2U1elhMU3pvb3F3WldKMmJWLUhnRXhaXw==";
    private static final String T12 = "TnpVM09USTROVFUzTWpreE1UYzFNRFE0Ljl1cWFkVS5WSEZUXy12Vzl6WTA0UDc0NmR5VzhFTmFMbFh3WnMtNF9XRWpkRQ==";
    private static final String T13 = "TWpVek5EUTFNVFl3TnpjME56SXhORGMxLmZPb3c2LS5ibUJrQko4enNWdEM2V2xwQkhBaE9NVHo2SHlOSHluMDF4elBwWQ==";
    private static final String T14 = "TmpVd01UZzBORFkwTnpjME1UTTVNREF3LkppaXZCVC5QWFZYeklCMnQ4NVRXdktkdFhraWh1bDZPNGwyNmhKX0NJdWc2UQ==";
    private static final String T15 = "TURRME1qVTROREUzTXpBME16RTNOamN3LlhZMjZFRy5pUkNMMGxvQUxfclQ4Tlc5amhxSTQycGJ5eFNLbHp6TkMyOEcxOA==";
    private static final String T16 = "TXpZeU9ERXhNVGszTWpRek9Ea3dOalkwLkRFcHBCRS5vS3h1UGVjQmpJTWwydlVYekIxcEJyaF9LanMyR2d6U1RQdE0zUQ==";
    private static final String T17 = "TnpVNU1qTTNOamt4TnpBME1EWTRORFEwLnVyQUFwbC5uYzc2TUJoMFlIMFNDbFJjbC11Wkp0cTNzdE9xRjVzZUo2NWJBaA==";
    private static final String T18 = "TmpBM01qWXhNelV5TXpRek56RTROalkzLm9zYm9rdS5lSzRZZXo3R181eEhmQm12bHZCNVJnTV9oTk90VnlkT0JLSXJTNA==";
    private static final String T19 = "TnpVM05EZzNNak14TXpBM01qWTROREE1LmtWSjUzci5Tc1lBdXl2UmNaWHVQVmk5bWdFMHo5LUQ4aktnVmFjVFFEcFNCVA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}