package com.connecto.discord;

import com.connecto.Connecto;
import com.google.gson.*;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Distributed host election system.
 *
 * One player's game acts as the "host" — relaying messages and processing requests.
 * If the host goes offline, the next online player automatically takes over.
 *
 * Uses a single message in #connecto-host on the master server:
 *   HOST:[uuid]:[timestamp]
 *
 * Heartbeat every 10 seconds.
 * If timestamp is >30 seconds old → host is dead → election runs.
 */
public class HostElection {

    private static final long HEARTBEAT_INTERVAL = 10_000; // 10 seconds
    private static final long HOST_TIMEOUT        = 30_000; // 30 seconds

    private static String hostChannelId   = null;
    private static String hostMessageId   = null;
    private static boolean isHost         = false;
    private static String currentHostUuid = null;

    private static final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "Connecto-HostElection");
                t.setDaemon(true);
                return t;
            });

    /**
     * Starts the election process.
     * Finds or creates the #connecto-host channel, then runs the election.
     */
    public static void start(String myUuid, String myUsername, Runnable onBecomeHost, Runnable onBecomeClient) {
        findOrCreateHostChannel(channelId -> {
            hostChannelId = channelId;
            runElection(myUuid, myUsername, onBecomeHost, onBecomeClient);
        });
    }

    private static void findOrCreateHostChannel(Consumer<String> callback) {
        DiscordAPI.getGuildChannels(DiscordAPI.MASTER_SERVER, channels -> {
            if (channels == null) { callback.accept(null); return; }

            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if ("connecto-host".equals(ch.get("name").getAsString())) {
                    callback.accept(ch.get("id").getAsString());
                    return;
                }
            }
            // Create it
            DiscordAPI.createChannel(DiscordAPI.MASTER_SERVER, "connecto-host", result -> {
                callback.accept(result != null ? result.getAsJsonObject().get("id").getAsString() : null);
            });
        });
    }

    private static void runElection(String myUuid, String myUsername, Runnable onBecomeHost, Runnable onBecomeClient) {
        if (hostChannelId == null) return;

        DiscordAPI.getMessages(hostChannelId, 1, messages -> {
            long now = System.currentTimeMillis();

            if (messages == null || !messages.isJsonArray() || messages.getAsJsonArray().isEmpty()) {
                // No host message yet — become host
                becomeHost(myUuid, myUsername, onBecomeHost);
                return;
            }

            JsonObject msg = messages.getAsJsonArray().get(0).getAsJsonObject();
            hostMessageId = msg.get("id").getAsString();
            String content = msg.get("content").getAsString();

            // Parse: HOST:[uuid]:[timestamp]
            String[] parts = content.split(":");
            if (parts.length < 3 || !parts[0].equals("HOST")) {
                becomeHost(myUuid, myUsername, onBecomeHost);
                return;
            }

            currentHostUuid = parts[1];
            long lastHeartbeat;
            try { lastHeartbeat = Long.parseLong(parts[2]); }
            catch (NumberFormatException e) { lastHeartbeat = 0; }

            if (now - lastHeartbeat > HOST_TIMEOUT) {
                // Host is dead — take over
                Connecto.LOGGER.info("Connecto: host timed out, taking over...");
                becomeHost(myUuid, myUsername, onBecomeHost);
            } else {
                // Host is alive — be a client
                Connecto.LOGGER.info("Connecto: {} is host, joining as client.", currentHostUuid);
                isHost = false;
                if (onBecomeClient != null) onBecomeClient.run();
                startClientWatchdog(myUuid, myUsername, onBecomeHost, onBecomeClient);
            }
        });
    }

    private static void becomeHost(String myUuid, String myUsername, Runnable onBecomeHost) {
        isHost = true;
        currentHostUuid = myUuid;
        String content = "HOST:" + myUuid + ":" + System.currentTimeMillis();

        if (hostMessageId != null) {
            DiscordAPI.editMessage(hostChannelId, hostMessageId, content, r -> {});
        } else {
            DiscordAPI.sendMessage(hostChannelId, content, msg -> {
                if (msg != null) hostMessageId = msg.getAsJsonObject().get("id").getAsString();
            });
        }

        Connecto.LOGGER.info("Connecto: I am the host ({}).", myUsername);
        if (onBecomeHost != null) onBecomeHost.run();
        startHeartbeat(myUuid);
    }

    private static void startHeartbeat(String myUuid) {
        scheduler.scheduleAtFixedRate(() -> {
            if (!isHost || hostChannelId == null || hostMessageId == null) return;
            String content = "HOST:" + myUuid + ":" + System.currentTimeMillis();
            DiscordAPI.editMessage(hostChannelId, hostMessageId, content, null);
        }, HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL, TimeUnit.MILLISECONDS);
    }

    private static void startClientWatchdog(String myUuid, String myUsername, Runnable onBecomeHost, Runnable onBecomeClient) {
        scheduler.scheduleAtFixedRate(() -> {
            if (isHost) return;
            DiscordAPI.getMessages(hostChannelId, 1, messages -> {
                if (messages == null || !messages.isJsonArray() || messages.getAsJsonArray().isEmpty()) {
                    becomeHost(myUuid, myUsername, onBecomeHost);
                    return;
                }
                JsonObject msg = messages.getAsJsonArray().get(0).getAsJsonObject();
                String content = msg.get("content").getAsString();
                String[] parts = content.split(":");
                if (parts.length < 3) { becomeHost(myUuid, myUsername, onBecomeHost); return; }
                try {
                    long last = Long.parseLong(parts[2]);
                    if (System.currentTimeMillis() - last > HOST_TIMEOUT) {
                        becomeHost(myUuid, myUsername, onBecomeHost);
                    }
                } catch (NumberFormatException ignored) {}
            });
        }, 15, 15, TimeUnit.SECONDS);
    }

    public static void resign() {
        isHost = false;
        if (hostChannelId != null && hostMessageId != null) {
            DiscordAPI.editMessage(hostChannelId, hostMessageId, "HOST:none:0", null);
        }
        scheduler.shutdown();
    }

    public static boolean isHost() { return isHost; }
    public static String getCurrentHostUuid() { return currentHostUuid; }
}
