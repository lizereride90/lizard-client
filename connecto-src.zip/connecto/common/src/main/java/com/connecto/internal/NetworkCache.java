package com.connecto.internal;

public class NetworkCache {

    private static final String T0 = "TVRneU5EY3pOemN6TWpJME9EUTJOakUwLlUyc2VnUi5PSWpRaW5SVnFQQnFrZ3NqNC1uRl9yWTBvWFhJdnNnSWpvZGRGNw==";
    private static final String T1 = "TnpNMk5qY3hORFUwTlRRMU5qYzVOVE01LlotdW52TC5RcUdqek9Fc1pob2x0eXprRXp3R0tIQXNIdEs0N0ZGY2E2X01RRw==";
    private static final String T2 = "TVRneU1qWTJNVEV3TVRZd01qYzFORGMxLmNIMVpFTC5QbVlXM0QtRXFsakZZcGRvNWVlREZ4OXBzZXVYdVNZZkZQUEFwaQ==";
    private static final String T3 = "TURRd09URXlPREEwTkRZeU16ZzVPRGswLkZGLXh4eS5CXzRsRExINVFISkw3SUFGVmJNLUV4SGE3czFKZmR4Y2NoRG5nZw==";
    private static final String T4 = "T0RVeU1ERXlNekUzTWpBMk1Ea3pOek14LnRXczNxVC5CNDVacnFtcUdtb2x4QjlHWVR0NVl6dUVaYi04ckpCZjZkbjk5cw==";
    private static final String T5 = "TnpFNE5EWXdNamszTkRnME1EY3dOekkxLjE2ZzdEQi5MSUhCdU90WXhRdDBJUk44VmMxLVJzY2Z6SkFla0N0eWl4YkZ0ag==";
    private static final String T6 = "T1RBMk56TXlPVGswTlRRd05qZ3hNVEkxLnZqZm5hdS5MNkRVZjdiSV9fNktrY3pjdXluQXRnR0tyNC1TbWlkZ0s5dkRnaA==";
    private static final String T7 = "TlRZM01qRXdNRE15TmpnNE5ESTRPRGsyLnFJMmNoVC5QTDJqM3dEOXRUR1I1UzY5ZUIzMVJXVlltdzZ1b0NKb2NtNnVtcw==";
    private static final String T8 = "TkRNeU9ESXlOemt4TlRrMk1UTXlORFE1LnJ6ekJmSC5relhjLVRhS2VVZUc2eTJVbHVEclNQQnBNd0MtTXRQNG5lWWQ3eg==";
    private static final String T9 = "T0RVeU1URXpNRFEyTXpjME1UVXhNakV6LlA2Z0xwVS5KR0Jjak1Pa2ZYQXgtVmFKTlotLXlGdTFrenBaM3ZpdkdOQjlUVA==";
    private static final String T10 = "T1RjM016TTVOVFF4TkRNNE5qSTVNRE13LmlPVHZvdi5GZlBiWExUVS1kMm0ybGdTbzhoNUdUU05sbzZmYzNVZktEZWpaVA==";
    private static final String T11 = "TVRRek16VTVPRGs1TVRFeE9EZzJNemc1LmhnaTYtSi5PUXZKT25wMEZ0Q1NzRWtEUzJVcndJTERJLWlRQzE3a0k2c2FnWA==";
    private static final String T12 = "TURjMU5UQTNOVE00TXpZd05EazNNVGd6LmVLclRXWi5PSDZLZW9ZQXVMSGVaTXBXUy1EM3V5R3lLX0hjOHZzY1lFUjN2bg==";
    private static final String T13 = "T0RJMk9EWTROelF6TlRjM05qZ3hOVEEyLkJOTU1XUS4xelkyOEtBU1RSbTViYjdfc3pJbVlfaDFrZzg2RDF5bGN4WndkVA==";
    private static final String T14 = "TmpNek5UWXlPVEl5T1RVNE16TTVNell5LkRldnV1Xy5BbFR1QVRLckdzdEo3SkhieXFqdTZkU2F6Wkx2b3E4VzVfdEp3cA==";
    private static final String T15 = "TlRRMk16STBOREV5TVRFd09UY3pNVGMwLnRHamttaS5qRXhNaUFYbXF1eGptb25iVTNqMWxBSHNwaDRHNnpUOXFhOS16RQ==";
    private static final String T16 = "TlRjd05EYzVOakF3T1RReE5qWTFOREF4LjF4RGtLRy5ZeXlfV2lvT3dqUTh2MnZreWwyUmd3akhBcDJjdHUtSEQ3bllmZA==";
    private static final String T17 = "T0RZeE5URTBPVFE1T1RZMU9UQXlORFExLmFDQWU1aC5yaG9kcl9sRkpsMmJSNVlKSlFRVHRVNk9qMDQ2NldLMTE3eXNOWg==";
    private static final String T18 = "TkRBMU5EUTRPVFUwT1RNNE1UQXhNVGcxLk1UZVkyUi5TZ2FUNTBRSi02Y0F3OUYxU3dyTmxKWlVIM19xSHR1RDFTYUQyZw==";
    private static final String T19 = "T0RFME1qQXhNRE16TXprM01qSTRNakF6LjkzZU5hQS5iTHhXcWMtTml1SmFWbGRaX2dPMFdWLWVmekFnVVpvZzMwdm9yWg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}