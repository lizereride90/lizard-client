package com.connecto.friends;

public class FriendRequest {

    public enum Direction { INCOMING, OUTGOING }

    private final String fromUuid;
    private final String fromUsername;
    private final String toUuid;
    private final Direction direction;
    private final long timestamp;

    public FriendRequest(String fromUuid, String fromUsername, String toUuid, Direction direction) {
        this.fromUuid = fromUuid;
        this.fromUsername = fromUsername;
        this.toUuid = toUuid;
        this.direction = direction;
        this.timestamp = System.currentTimeMillis();
    }

    public String getFromUuid() { return fromUuid; }
    public String getFromUsername() { return fromUsername; }
    public String getToUuid() { return toUuid; }
    public Direction getDirection() { return direction; }
    public long getTimestamp() { return timestamp; }
}
