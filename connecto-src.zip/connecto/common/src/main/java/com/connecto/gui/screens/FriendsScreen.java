package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.friends.Friend;
import com.connecto.friends.FriendRequest;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.gui.widgets.ConnectoTextInput;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class FriendsScreen extends Screen {

    private final Screen parent;
    private ConnectoTextInput searchBox;
    private ConnectoTextInput addFriendBox;
    private int scrollOffset = 0;
    private static final int ENTRY_H = 28;
    private static final int LIST_TOP = 60;

    public FriendsScreen(Screen parent) {
        super(Component.literal("Friends"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        // Search box
        searchBox = new ConnectoTextInput(this.font, this.width / 2 - 150, 34, 220, 18, Component.literal("Search friends..."));
        this.addRenderableWidget(searchBox);

        // Add friend input
        addFriendBox = new ConnectoTextInput(this.font, this.width / 2 + 76, 34, 100, 18, Component.literal("UUID or name"));
        this.addRenderableWidget(addFriendBox);

        this.addRenderableWidget(new ConnectoButton(this.width / 2 + 178, 34, 60, 18,
                Component.literal("Add"),
                btn -> sendFriendRequest()));

        // Pending requests section button
        List<FriendRequest> requests = Connecto.friendManager.getPendingRequests();
        if (!requests.isEmpty()) {
            this.addRenderableWidget(new ConnectoButton(this.width - 120, 34, 115, 18,
                    Component.literal("§e⚡ " + requests.size() + " Pending"),
                    btn -> this.minecraft.setScreen(new PendingRequestsScreen(this))));
        }
    }

    private void sendFriendRequest() {
        String input = addFriendBox.getValue().trim();
        if (!input.isEmpty()) {
            Connecto.friendManager.sendFriendRequest(input);
            addFriendBox.setValue("");
        }
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        gfx.drawString(this.font, "§7Friends", this.width / 2 - 150, 26, 0xAAAAAA);

        List<Friend> friends = Connecto.friendManager.getFriends().stream()
                .filter(f -> searchBox == null || searchBox.getValue().isBlank()
                        || f.getUsername().toLowerCase().contains(searchBox.getValue().toLowerCase()))
                .sorted((a, b) -> {
                    // Online first
                    if (a.getStatus() != Friend.Status.OFFLINE && b.getStatus() == Friend.Status.OFFLINE) return -1;
                    if (a.getStatus() == Friend.Status.OFFLINE && b.getStatus() != Friend.Status.OFFLINE) return 1;
                    return a.getUsername().compareToIgnoreCase(b.getUsername());
                })
                .toList();

        if (friends.isEmpty()) {
            gfx.drawCenteredString(this.font, "§7No friends yet. Add someone above!", this.width / 2, this.height / 2, 0x888888);
            super.render(gfx, mouseX, mouseY, delta);
            return;
        }

        int listBottom = this.height - 32;
        int visibleCount = (listBottom - LIST_TOP) / ENTRY_H;
        int maxScroll = Math.max(0, friends.size() - visibleCount);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        for (int i = scrollOffset; i < Math.min(friends.size(), scrollOffset + visibleCount); i++) {
            Friend f = friends.get(i);
            int y = LIST_TOP + (i - scrollOffset) * ENTRY_H;
            renderFriendEntry(gfx, f, y, mouseX, mouseY);
        }

        // Scroll hint
        if (maxScroll > 0) {
            gfx.drawString(this.font, "§7↑↓ scroll", this.width - 60, listBottom - 10, 0x666666);
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    private void renderFriendEntry(GuiGraphics gfx, Friend f, int y, int mouseX, int mouseY) {
        boolean hovered = mouseX > this.width / 2 - 180 && mouseX < this.width / 2 + 180
                && mouseY > y && mouseY < y + ENTRY_H - 2;

        // Row background
        gfx.fill(this.width / 2 - 180, y, this.width / 2 + 180, y + ENTRY_H - 2,
                hovered ? 0xFF2A2D3E : 0xFF1E2030);

        // Status dot
        int dotColor = switch (f.getStatus()) {
            case ONLINE  -> 0xFF57F287;
            case IN_GAME -> 0xFFFEE75C;
            case OFFLINE -> 0xFF72767D;
        };
        gfx.fill(this.width / 2 - 174, y + 10, this.width / 2 - 168, y + 16, dotColor);

        // Username
        gfx.drawString(this.font, f.getUsername(), this.width / 2 - 160, y + 6, 0xFFFFFF);

        // Status text
        String statusText = switch (f.getStatus()) {
            case ONLINE  -> "§aOnline";
            case IN_GAME -> "§eIn Game" + (f.getCurrentServer() != null ? " — " + f.getCurrentServer() : "");
            case OFFLINE -> "§7Offline";
        };
        gfx.drawString(this.font, statusText, this.width / 2 - 160, y + 16, 0xAAAAAA);

        // Action buttons (rendered as text hints when hovered)
        if (hovered) {
            gfx.drawString(this.font, "§b[MSG]", this.width / 2 + 80, y + 6, 0x5865F2);
            gfx.drawString(this.font, "§a[INVITE]", this.width / 2 + 110, y + 6, 0x57F287);
            gfx.drawString(this.font, "§c[REMOVE]", this.width / 2 + 148, y + 6, 0xED4245);
        }
    }

    @Override
    public boolean mouseScrolled(double x, double y, double deltaX, double deltaY) {
        scrollOffset = Math.max(0, scrollOffset - (int) deltaY);
        return true;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Handle clicks on friend entry action buttons
        List<Friend> friends = Connecto.friendManager.getFriends().stream().toList();
        int listBottom = this.height - 32;
        int visibleCount = (listBottom - LIST_TOP) / ENTRY_H;

        for (int i = scrollOffset; i < Math.min(friends.size(), scrollOffset + visibleCount); i++) {
            Friend f = friends.get(i);
            int y = LIST_TOP + (i - scrollOffset) * ENTRY_H;
            if (mouseY > y && mouseY < y + ENTRY_H - 2) {
                // MSG click
                if (mouseX > this.width / 2 + 80 && mouseX < this.width / 2 + 100) {
                    this.minecraft.setScreen(new DirectMessageScreen(this, f));
                    return true;
                }
                // INVITE click
                if (mouseX > this.width / 2 + 110 && mouseX < this.width / 2 + 144) {
                    // Send world invite if hosting
                    if (Connecto.wsClient != null) {
                        Connecto.chatManager.sendDirectMessage(f.getUuid(), "§eI've invited you to my world!");
                    }
                    return true;
                }
                // REMOVE click
                if (mouseX > this.width / 2 + 148 && mouseX < this.width / 2 + 190) {
                    Connecto.friendManager.removeFriend(f.getUuid());
                    return true;
                }
                // Anywhere else on row -> open profile
                this.minecraft.setScreen(new ProfileScreen(this, f.getUuid()));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
