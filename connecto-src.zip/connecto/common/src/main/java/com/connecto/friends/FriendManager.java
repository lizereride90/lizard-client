package com.connecto.friends;

import com.connecto.Connecto;
import com.connecto.network.ConnectoAPI;

import java.util.*;
import java.util.function.Consumer;

public class FriendManager {

    private final Map<String, Friend> friends = new LinkedHashMap<>();
    private final List<FriendRequest> pendingRequests = new ArrayList<>();
    private final List<Consumer<Friend>> statusListeners = new ArrayList<>();
    private final List<Consumer<FriendRequest>> requestListeners = new ArrayList<>();

    public FriendManager() {}

    // ─── Friends ─────────────────────────────────────────────────────────────

    public void loadFriends() {
        ConnectoAPI.getFriends(Connecto.accountManager.getActiveAccount(), friendList -> {
            friends.clear();
            for (Friend f : friendList) {
                friends.put(f.getUuid(), f);
            }
            Connecto.LOGGER.info("Loaded {} friends.", friends.size());
        });
    }

    public Collection<Friend> getFriends() {
        return Collections.unmodifiableCollection(friends.values());
    }

    public Optional<Friend> getFriend(String uuid) {
        return Optional.ofNullable(friends.get(uuid));
    }

    public List<Friend> getOnlineFriends() {
        return friends.values().stream()
                .filter(f -> f.getStatus() != Friend.Status.OFFLINE)
                .toList();
    }

    // ─── Friend Requests ─────────────────────────────────────────────────────

    public void sendFriendRequest(String targetUuid) {
        ConnectoAPI.sendFriendRequest(
                Connecto.accountManager.getActiveAccount(),
                targetUuid,
                success -> {
                    if (success) Connecto.LOGGER.info("Friend request sent to {}", targetUuid);
                    else Connecto.LOGGER.warn("Failed to send friend request to {}", targetUuid);
                }
        );
    }

    public void acceptFriendRequest(FriendRequest request) {
        ConnectoAPI.acceptFriendRequest(
                Connecto.accountManager.getActiveAccount(),
                request.getFromUuid(),
                success -> {
                    if (success) {
                        pendingRequests.remove(request);
                        Friend newFriend = new Friend(request.getFromUuid(), request.getFromUsername());
                        newFriend.setStatus(Friend.Status.ONLINE);
                        friends.put(newFriend.getUuid(), newFriend);
                    }
                }
        );
    }

    public void declineFriendRequest(FriendRequest request) {
        ConnectoAPI.declineFriendRequest(
                Connecto.accountManager.getActiveAccount(),
                request.getFromUuid(),
                success -> pendingRequests.remove(request)
        );
    }

    public void removeFriend(String uuid) {
        ConnectoAPI.removeFriend(
                Connecto.accountManager.getActiveAccount(),
                uuid,
                success -> {
                    if (success) friends.remove(uuid);
                }
        );
    }

    public List<FriendRequest> getPendingRequests() {
        return Collections.unmodifiableList(pendingRequests);
    }

    // ─── Real-time Updates (called by WebSocket) ──────────────────────────────

    public void onFriendStatusUpdate(String uuid, Friend.Status status, String server) {
        Friend f = friends.get(uuid);
        if (f != null) {
            f.setStatus(status);
            f.setCurrentServer(server);
            statusListeners.forEach(l -> l.accept(f));
        }
    }

    public void onIncomingFriendRequest(FriendRequest request) {
        pendingRequests.add(request);
        requestListeners.forEach(l -> l.accept(request));
    }

    // ─── Listeners ───────────────────────────────────────────────────────────

    public void addStatusListener(Consumer<Friend> listener) { statusListeners.add(listener); }
    public void addRequestListener(Consumer<FriendRequest> listener) { requestListeners.add(listener); }
}
