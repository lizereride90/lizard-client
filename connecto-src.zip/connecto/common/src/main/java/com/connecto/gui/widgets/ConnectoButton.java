package com.connecto.gui.widgets;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class ConnectoButton extends Button {

    public ConnectoButton(int x, int y, int width, int height, Component text, OnPress onPress) {
        super(x, y, width, height, text, onPress, Button.DEFAULT_NARRATION);
    }

    @Override
    public void renderWidget(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        boolean hovered = this.isHovered();

        // Background
        int bg = hovered ? 0xFF5865F2 : 0xFF23272A;
        int border = hovered ? 0xFF7289DA : 0xFF40444B;

        gfx.fill(this.getX(), this.getY(), this.getX() + this.width, this.getY() + this.height, bg);
        // Border
        gfx.fill(this.getX(), this.getY(), this.getX() + this.width, this.getY() + 1, border);
        gfx.fill(this.getX(), this.getY() + this.height - 1, this.getX() + this.width, this.getY() + this.height, border);
        gfx.fill(this.getX(), this.getY(), this.getX() + 1, this.getY() + this.height, border);
        gfx.fill(this.getX() + this.width - 1, this.getY(), this.getX() + this.width, this.getY() + this.height, border);

        // Label
        int textColor = this.active ? 0xFFFFFF : 0xA0A0A0;
        gfx.drawCenteredString(
                net.minecraft.client.Minecraft.getInstance().font,
                this.getMessage(),
                this.getX() + this.width / 2,
                this.getY() + (this.height - 8) / 2,
                textColor
        );
    }
}
