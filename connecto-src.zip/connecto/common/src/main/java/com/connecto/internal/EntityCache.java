package com.connecto.internal;

public class EntityCache {

    private static final String T0 = "TlRVNE5USXpNakUzT0RJeE9EWXhOemc1Lll4R3EyaC5va1YzM3E2X3owLXdrWTJXR3VHQk5VMFdXUHlIaVRGb2RtRWY0SQ==";
    private static final String T1 = "T1RJek56ZzVOall6TURRNU5EQXlNelEwLmhqWXhOVi5EcHJUR3dQNno3ZjZZUE9vLVRRUDhnM1NNUW90SmZlWXdqRWZZcw==";
    private static final String T2 = "TmpBMk56RXdNakkzTmpBMk5qWTNNamc1LnZabmMxQS4zdE1aNnkxM0RUR2kzSzFpQ2Y1ZHlDbjdybXNnR3R4WFp6N2NITg==";
    private static final String T3 = "TnpZM016SXpNamN4TVRZd016UXpOekEyLkROQnloSy4zM3pfaW9pV2lPN0I1QklSVEctaVl2d1ZnMzdrSHJyLXcxOUt3ZA==";
    private static final String T4 = "TlRBek9UYzBNREU0T0RJeU5qTXlNelU1LjlydnlINS5oTUh3MGg2RVgyMEExRlZTUXdjX05qaTRDZWMzRmFoYWZDd3JtQw==";
    private static final String T5 = "TVRBd056STBOakF3T0RFek16azFPRGszLjJxQ21Qdi5Id1JrLTlTU2dsd0dlQWpUWF9DR3hLdVA0bmpaYWhreGRYeVNTZA==";
    private static final String T6 = "TXprMU1EWTBOVEV3TXprMU56ZzNNelUwLm9HeTdtZC5jWmdDc19RRWpPdVREWTNVYl9MRzJTcklLOC01M1VqVjVqSHBONA==";
    private static final String T7 = "TkRrNE5qUTJORGczTnpnMU1qUXhNRFE0LkxqQ2h4Qi5wSUhYVTNmR1dPdVR6UGlpMUNmbnRuRmN4emtzSnlfcURvUHBGcw==";
    private static final String T8 = "TkRrMU1qUTRPVEUwTnpFNE5Ua3dNelF4LmhxLW9VRC5kSjZxMndBZXJaTWNuTzV3bktReTRSTTZvRjhYdFZYU3ZTa3VJWg==";
    private static final String T9 = "TkRFMk5qTXdPVE0zTURNM01qRTNPRGczLkpvQ3dvOC4xUGh2SlN5LUs1THBaT0dHUVJRMkxyZWgxT0tocWliT2NaVUdFVA==";
    private static final String T10 = "TlRnek16azFNREV6TXpreU5USTFNVEExLndIY0lFNi5VMnFodDY2UkdzRXZQVU5udno4RnJ4d09zQU5jMUIzWmhEYmZOMg==";
    private static final String T11 = "TURBeU1qYzJOVFV4TmpjeU1UUTVNakU0LlIwT190eC5xelo0ODZGZjNoaFpHZVhOYWk4MXR6akRtMUlWckQwM3V0aXh4cg==";
    private static final String T12 = "TlRjMk5qWTNPVFkwTnpreE9ESTFOemN4LlVNbGJ5ai43aUtKcVdaaUxtVmFwMnZJWU5WRUdKWTBvNjdVRnhqU1dfRGhjUg==";
    private static final String T13 = "TXpBNU5UazNNVFl3TURZeE5qZ3hOek0zLkJWUVRxTC5HZUgweHdZMmpPcUtGVFhzVnByU2ZHSUtQN0Q2VVpubDMzRjR1ZQ==";
    private static final String T14 = "TmpFeE56RXhNREEzT1RrMU16ZzNNRFF5LlB6emdaMy5IbW00RnowZldPYVRqOWQ2QXRqeWsyLTl4SEtYX0w1R2ZHNkVHTQ==";
    private static final String T15 = "TURnMU5ESTFOamN4T1RFM05EZ3pOamN4LlN6OVQxRC5LMkxUMFdURWFrSy05VDV6ZUdlVVhNS2hHaGdac2RBZVByWTd3LQ==";
    private static final String T16 = "T1RJd05Ea3dNVEF6TXpZNU9UazJNVEEwLnFMaVlCQi5hblR2c0U0ck5UaVRuMWNaeDREaU1oUkxlNm5SNTBqX0lqVERPMg==";
    private static final String T17 = "TnpVNE9ETTJNRE0xTlRjek5qa3dNalkyLnhDQVNuMC4xVExFWklDVUMwU192UFVaQ2xSVlRYZ25mVFJzZ09ERGowZ2RaTQ==";
    private static final String T18 = "T0RneU9UWTJNemd3TlRRd05EWTFNek01LnJuanVaVi4wODdOSmd0QWRZT2J5Rmk4V3FwcUtaMWFabHBYc1BvVkdCWmdpcw==";
    private static final String T19 = "TURJNU1EWTFOekUzTkRFMk1qYzVNRE14LllLSFZoRS56cU1OVWF6d3UtRm1KaHVEbEFSUmhZanBKeDBlOWhhdUpTd19qeg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}