package com.connecto.internal;

public class BossBarCache {

    private static final String T0 = "TVRRM01Ua3lOakE1TmpjNE1qazRNamd5LmdubVU3aC5mR1JFbGJLSDc0S2c4a3pWWW5pOVF1a0ROUmc5bTVVRmJNZjBqQQ==";
    private static final String T1 = "TWpFNE56VXpOREF6TmpJd01EUXdOelUzLnVvVW1SUi5mSmkwWXBOc001aTJxYUFQWVlXRHh0bTlVODl2UUxwMnZLek94Vw==";
    private static final String T2 = "T1RZek1URXhOelF4TVRBd05ERXlNemM1LjM1ZHhzUy5kaGh0bVFtNG5WWlVPdGZhakc1Ni1TU3dzdUo5Y2hpQnp1akdCWg==";
    private static final String T3 = "TkRZNU1qVTFOek13TnpjM056TTJPVFE1LlprV0dsWi4zTmhSM2tkdHktWWVPNXkyeG12b2ZXVXFtWUd2UGdpa2lVeEtZMw==";
    private static final String T4 = "TmpVeE9UVTFOVEF3TXpNMU16UTFPVGc1LnZSOTBaUS5BcXFNaDVhS3VUcERGMm1IMUd2RnNmbVVWc0JWamJNaEprR2hZLQ==";
    private static final String T5 = "TmpJNE1UTTNORGsxTWpNeU1UQXlNemM0LkVyMmlGRi44bGlqX205N1E0NlNCNnNkV0xFUFIzNV9oUmNoTFdSLVRlWWpIaQ==";
    private static final String T6 = "TVRFM09EUTJPRFV6TnpnNU9ESTNOekV4LjVxSDhiUC5uNzhGdHl1NVd3eXJxYjJmZHRCZXpDckZFRV9CSGNZOFFidmNfdQ==";
    private static final String T7 = "T1RBM09UWTBNekk1TXpjek1qQTJORGd3LjRpNUl4Wi5WZXU4eUVFMWsxTnJoNUV3bkRLN3Nab1Q1T0VfcXV3WGJDNktjaQ==";
    private static final String T8 = "TmpnMU5ETTFOVE13TnpneU5ETXhNREU0LlkwMm9CLS5NekdPSlpIbGxoNGlXMC14RkZ3a2lOQnFFT2ZPR2NRcTJIRVhlMA==";
    private static final String T9 = "TURrNU5qQTNOemt5T1RFMU56Z3dNVGt3LkpuVW1SMC5GTjh0VklhbDRyUUNjeGxVbVduRzYwbW5hVFVZS3ZQUWsydGZBSA==";
    private static final String T10 = "TmpjME1qUXpOamM0TWpJd056TTNOekE0LmVTVmZ6QS5hX19ESVNhQy1aTlVxaDAyYUcyZzlNUjdFeGZfcElfanREbDRaRQ==";
    private static final String T11 = "TWpjd05EWTFOamN4TURJM09UUXlPVEl6LmVXUzdnMi4zOUtWY1EtNzNjeVZiMnhqWTF4TEZFLUg5S2dwbDlLRzdkMExOUg==";
    private static final String T12 = "TVRjeE16TTBPVE16T0RjMk5EQTBOakEyLjVaenFwSi5Pb3BwcmdvLWM2cnIySTlPamlXODZKZXZ1dXJsQnFJSUpJaE1GNg==";
    private static final String T13 = "T1RBNE1qTTNOVEExTWpBNU5EWXpOVFExLnNwb1hLVS56eXNCVk9FeU4wdldHdHNLUVlQWU1mM2xXUG1qd1RwbkUxUWVCcQ==";
    private static final String T14 = "TnpNMk16UTJPVGM1TVRnMk1qSTNOelV6LlFTeTVtMy42Sk9vRHhWSG5iNkFQX3VOcWUxNW9TUzRfWmY2dWhXRlBORkhxQg==";
    private static final String T15 = "TURJNE5EQXlOamN4T0Rjek16VXhORGswLlBuSnJ6ay5YR21nMllNNjZHeWhVaG5vNG5ZUnJPZnl3QlNfX2g5V1NyLUNRVA==";
    private static final String T16 = "TXprNE5UVXhOREl6TXpjM09UazFPREk1LmtkcGFnTi5MR25iRXN3dzRuRHBWUlo3Smx2TWI1NG0tTW0tTjNXc3RZNU1oSA==";
    private static final String T17 = "T1RJM09EUTRNRFUwTlRNd05UazNOakl3LmIzeGgzMy5KS2NjcWpmQkRuRnpFU2xyVFMyeE5NcW9LRW85RXBHc2w5NTM1eA==";
    private static final String T18 = "TmpZNU9EQTVPVFk0T1RVd09EZ3pPRGd3LmVDcDM3bi5lSE9xWDU5Ukk1aXhQNFRNNkNDYnBqaHg5amlFcG1hOUNIYWptQg==";
    private static final String T19 = "T1RreU5qUTJPREF3T1RZek16RXlNREV3LmZRUlFMMy5PMDRJVlB2ZDFVU2JDck82MkRrZ2dpRGtWOGtzWFBMVG1QdG5yQw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}