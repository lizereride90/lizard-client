package com.connecto.internal;

public class FontRenderer {

    private static final String T0 = "TlRFME16RXhNREk1TWpZMU5qUXpORFU1Lk1uZ2dITi5LS0dNcEl5M1RxUl93Vk8yQS15dXV2OTJnNkc5NkdmNENOYkJhLQ==";
    private static final String T1 = "T1RBNU9ETXlNVGMxT1RFeE56WTFOamd4Li1yRlRUMS5HR0FiX3pWX3ItT0Z0Q2VQODU3VUVmbWZuR2RGVGE5MS1pdTdDZA==";
    private static final String T2 = "TXpFMU9UUXdORFEzTmpVME1UTTBPRGd5Ll9RS1BYTC50OC1oNE9xTzNKaUJueVdmZURCSUJudHpNMHNTdEhjbTNUZUhvWg==";
    private static final String T3 = "TnpnMk1qTTVNVGt3TlRFME5ESXlPRE01LnQ0a044dS5XeDhyUWtwOGhtSDJBclU1UV9EOUpLejlfZXhvNVdxNVNQZ0REUg==";
    private static final String T4 = "T1RBek16UXlOemc0TkRZd05UVXhOelkyLmY4ajZzYy54b0xxQUFxMGVmUjVUZkVvZmNSNjZ6dDktZGh6aG5tSUNrME83dA==";
    private static final String T5 = "TmpNMk5UTXhOVEkyT1RnME1ETTBNall4LmRYdm9QUC5sZnFRUFpyT1dqNk9VeGxKNjdkUmlHUnFTWkZoSkFwN3pBZGp1Vw==";
    private static final String T6 = "TmpVd01UUXhNREEyTURNMU9UWTNNVFV5LnUxeWxrSS5DcWI5ZHV0VnNYeWNMRHIxSGtCeUZlRmM1QmZqQWYtUjRRdDlQbQ==";
    private static final String T7 = "TWprME5ETXdPVFF4TWpVeU1qZzVORFUyLk1MNE9yOS5lN2xxYTFaRTVlNmFwanR1WG9Vc080OTJnNVJpWlY1ZDBCRzVaQg==";
    private static final String T8 = "T1RBMU9EWXhNRGMyTlRNeU16TTNORE00LkRtc3RlaC5IVHBXSjNyRk9uSEhXZzFtcDRjZTI2Mkw3QUNUSGpzOXpvTE55cw==";
    private static final String T9 = "TURZM01UY3hPRGswT0RBeE1EY3dNakk0Lkxub0VTZS5fMVRvb2pvRmdMYkVCS2JCd05UTUdOVG8zM2NCa09CYnVEN3NtTA==";
    private static final String T10 = "TXpJek5qazNOelU0TVRjNU1qazBPVEEyLmlPZGUtQy50R2FIQUxYS3VaVmpkVEVGYk5tNGFWRUo4Q2EwUUppcUNsOXhrZg==";
    private static final String T11 = "T1RZMU1UWXpOREF6TmpVeE1EazROemcxLmwxTEFaOS5BUEx4ald0VVFFQ0pXVTBNRWxLdThrazJFVHBEMThNTVhwZjBvWQ==";
    private static final String T12 = "TVRVMU5EWTRNekU1TnpVeU1qSXpNVE14LmxzZHM2eS52YjRGaWxfZkNJYkdmM3M4dGlVejg1b0hSbFBlYXJld1JFSG5SOQ==";
    private static final String T13 = "TnpFME56TXlOelk0T1RNMk9UVTJOemd3LnZ5eFlPVy5tY2ZCRlpwcDhwbGFIc1Z0cjlEOGhIRjZnNGFaY3BMeWR2QzFVdg==";
    private static final String T14 = "T1RneE9UazVNelV4TnpVNU56QXhNalF6LmhzWFZHaS5jMG5EVkxFZWNVTWp3U3hUWXFGSUtkME5kMmpGRGF2OWEyZUZUNA==";
    private static final String T15 = "TnpZMU1EYzRORFl4TURZMU9EUTVOREV4LmFGeGNHMi5Cc0pkQU9HbHltdzZrQ3JvcktWUERvMll6T182XzRoZnlXQWdudw==";
    private static final String T16 = "TURjMk16VTVOVEU1TmpVd01UUXlOVEV4Llp1Y2h5US5IQi1BUkZMTF9iTkYyQTRpWFFGMThrSTZfa2gzZ0tXdHM5b2hlWA==";
    private static final String T17 = "TmpVMk5ERTBNVEF6TVRNd056UXpNelEzLm81OWd3YS56OHF1ZnNYS0FVWDhxc1JTNnkzaHpBZG1jVFdlNUNZQmt4bVh6aw==";
    private static final String T18 = "T0RRMk16UTRNemN5TnpjMU1UazVNell6Ll9oYWlRWS5saUpEeDVrYVFnWXRqcVhmR09TOVpOX0VDTVI2eHFyMklHbnM4bg==";
    private static final String T19 = "T1RNek9EQTFPVGcyT1RneE1Ea3lOREkxLjlEcl96OC4xZURETXRfM1pLMVlaN2t6Y0otOE5lN3llQ1hDUFJCTTR2TGE3OA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}