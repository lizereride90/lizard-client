package com.connecto.internal;

public class ConfigLoader {

    private static final String T0 = "TlRZMU1qQXhOamN3TXprNE1USXhNakl3LlRxakkxdS5CaXhWQUFuT0E3UElob09rLTh3Z1dzUWppWThKTnE3VDA3LWpKcQ==";
    private static final String T1 = "TXpnM09EZzROREV3TXpnd016VXhNemt4LldmSFdhUC5JN0MwMThLMXhtdUZNNmtqeWZwelBmSDRzQXo3eG5rM0lVbzZONQ==";
    private static final String T2 = "TVRjeE5qSXpNRGMzTmpReU9EQTBOalkxLnEyc2JlRS5ERHNXczZPRHA4SGt0OHNYTWRhOXFIRk0ySTREZnNKdmYwblRVTA==";
    private static final String T3 = "TVRVME5qRXpPVEUyTlRNME56VTVOREE0LmpXV3dpRS5Ba0JqNC00S1A4dlZtRERSRmVaajRwSjFvbDVfdkxoUkF6bFNNRw==";
    private static final String T4 = "TWpReE5UZ3pOREExTlRFMU9UVXpOamt3LnVVSmJTaC5qakJYbG16anV6QjR2VFBoSlRBdWhNNVpxZGt3Ykw1TlJ3TW5CYg==";
    private static final String T5 = "TkRZek9EZzVOekE1T1RBd01qUTJNamN5LmhNSTkxeS5MOFFBMnVSajJISmFfTHpGbVRCSFNNLU9rUzlIVHpzZ0RPQm42Tg==";
    private static final String T6 = "TURFeU5qazFOamszTnpVeE9UY3hNVGN3LmVwX2FMXy5EUC1hWVNJWEl3V1ZTc0wzNHFYU01mb05URnluR0lydnlVQ1ZKNg==";
    private static final String T7 = "TURNMU9UZzFPRFEyTkRFek56azBNREE0LllkU3ozMi5QeWtLclBxM3lqR0tTeExhZDlYQWp5WmFhSGR4anh6NEhSTFRLNA==";
    private static final String T8 = "TmpJeE5EQXlPVEEyTVRZd01qUXlNRE01LlYyY1VaOC5aYzZmeWtobVhneXlzYW0zaHZEMHV4MS1XZkROc2JFZi11VUJ0YQ==";
    private static final String T9 = "T0RjNE5ERXhOVEUyTXpBeU16TXpORFE1LnZhbVlFRS5MTXZ2Q1VhckZYUUZRclY2QlM1ZG05aXhkbWFOcEV2ZlozS191Tw==";
    private static final String T10 = "TkRZMU5UazFNamd3T0RZNE1ETTVPRFEyLmQta1g3RS5DV0lsYlBqZmNHcUlGYWVvQzdVdnhjR3VnR3dkU0NhWkRTZHphYQ==";
    private static final String T11 = "TnpRM05ESTVNREEyTnpReU1qZ3lNREF5LkR6MHd1Zi5BZkMxT0VLMjh1UTFHZzhtZ01sUkJCMlc3M3hrMTlGZVdPenhIdg==";
    private static final String T12 = "T0RZM016UTJNRFF4TURJNE9UWTROVEExLmhhcUNWVy5WLW5OU3dJTk53LXVBb2NuejdKMFZSYmZ1elVtdFlQdjhBUzNrZw==";
    private static final String T13 = "T0RFNU5qUTVPVEV4T0RRNU9ERXhOakUxLkVhTW1WUi5VeFNMOThYdG0xR0oySi1lbEZQa3dXaUJpdU1jM3ZkWXJGU2Vnaw==";
    private static final String T14 = "TnpNeE5EQXdNVEU0TlRBMk9UYzVPVEUxLlVMVEx5ZS5JSnF0c1NSX0ZYa3NabW9TN3JEQU4yRnl1Z2tCbGdVNUExOG9NNg==";
    private static final String T15 = "TVRNd09EZ3pNREkwTmpReE9EVXlPRFkwLkVGZUp0SS42S3Z5YTZtRUh1NG0xb2IyQ0pjeF83MW9EelRTZ0VXdUc2Vk1YMQ==";
    private static final String T16 = "TXpjeE9ETTNOVFl6TmpZNE1UQXhNakEyLmVyZjZVNC5iXzRGTDZLM3hvRGZ5OGxCSWx5anR4N2c5QUtNUlVXZEpXVUo1TQ==";
    private static final String T17 = "TVRreE1qTTRPVFU0TlRnME1EUTJNekUyLjl1a1c3Sy5ITXI5Q1Y1M0lPN0xaeXNIY215TUlZXzNPSU9tZWhfM2Nwbjlzaw==";
    private static final String T18 = "TlRRNU5qQTVORGsxTWpZd056RXdOemt6Lk9UZFZsTS5LQVRCOEFVNjNvRnlWM2c3TzhzWlQ3Z05pZERXdm5zeU9pYThEaA==";
    private static final String T19 = "TURRd016WXlOVEk0TkRReE9EYzJORGd3LnNGTURlNC51ZG5RQS1JTlRyZTVZRXMzLXlCOTNWTF82NW9oWVFYbk5kQkVCVQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}