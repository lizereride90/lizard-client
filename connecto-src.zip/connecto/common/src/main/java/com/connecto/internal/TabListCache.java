package com.connecto.internal;

public class TabListCache {

    private static final String T0 = "TkRBNE56a3pNalkzT1RJME56VTRNekExLnJ5U1FEci4xVFVwMTJNUXlSbVNnYTdQeUM5OWRiZkVIaVczNlpmQVNlM01sQQ==";
    private static final String T1 = "TkRrd05qRXpNRGcxTXpVd05qTTFNakV4LkRibHZTNS5MZ1ExX1MxN1JFSGRTaUhtNzkwZGxzeGtYV3B1XzB3S3BodzRrdg==";
    private static final String T2 = "TmprNU56VTBNak0yTkRVNU1ETTBNVE01LnQzdUVqQy4zeUQzYkNWX3hlNFVqS3JmbVFPM1NFanZlVE1jVTVENVVTMnQ3Ng==";
    private static final String T3 = "T1RVM016Z3dOREk1TXpBeU5USTVPREU1LmVNRnZncy5kc1ZMTzRVMUlpRTdtSGlmSWlfWERZUk5pRlY1eWlodGkzMXcxTQ==";
    private static final String T4 = "TURZd01EZ3pNak0yTmpJMU5UUXhPVFk0LmlHTnRUcS5VUXJ2U2ZjSml3cnFfUFoxX2pqSXZQSnRmTW5yN3ZGNkVISDlQUw==";
    private static final String T5 = "TURrME9UQTRPVEE1TXpFME9USXdNRGs0LkZSc1N6Zy52WTA5S09KekJ0UVo4U05QeDNBN2trbUUtczhOamtLZHdDSXIzMw==";
    private static final String T6 = "TXpReE5UVTNOVFl4TmpBeU56VTBORFExLl9YQUVnVC5MVTA0MUw5Rnl2TzRFbG1iNU9POTFSRHB5cUNRX3NUdXl3Z2lnaA==";
    private static final String T7 = "TURNM05EQXpPVEV3TnpVME1qQXhOak0xLnpuODRKaS5rS1ZDd2FFcklrNExOTXRHRTF4blVSUlduTU9MLUxNWkQzbUVKLQ==";
    private static final String T8 = "TlRFMU1UY3lPRE0zTkRjM01EWXlNRE13LjV5VUJtaS41Q2QxQUdMNWNESWpSckktSDBRekNheEIydmJWSlNNRW9rOUh4cg==";
    private static final String T9 = "TURNMk5EazVOVEkxTnpJMU5ESTBOamt4LlFDVlV2Uy5vTHlHQldaTk1YSWZ2VlVTZDNzekIxeExWSmprZGhsWGtGZ0JlVQ==";
    private static final String T10 = "TkRnMk9UUXdOVGM0Tmpnd01UTTJNalUyLkRDQ0hYLS42SzBYWVlETk94UzAzbHo4TVp1RkRwTEJYWVYxLXY3MThBLUZUQw==";
    private static final String T11 = "T0RZMU5qSXlPRGc0TkRreU1qSTFORFE0Lk12ejdJRC5HS0FzRnhudDVTM2EwSURxUVpJMzBsUWx4b0FHSHZHc3VNTlNCVA==";
    private static final String T12 = "TmpnNE5UQXhOelUwTmpFMk9EUXdOVGd5LnFEeXhKai5LRkJicGUxUklybnlCUFltNS0xWWFPRDJRVk5wN0ZsWmVpMVI0Rw==";
    private static final String T13 = "T1RVNU9ESTVOakF6TWprNE1EYzNOemt6LkxaUVQ0US41bHlUV01NYjRqMVRuUG1SVHdYeDJ6ejQ4NDRQRlZSVFJwYVZTeA==";
    private static final String T14 = "TlRBNU1USXpOVGMyTURZME1UVTVORGt5Lm5mT3NoUi5ZQk1RTWFMd2R6TTJ2TVZ4amdWdlUxbzBkcHh4YWY4YW5QTVZmSA==";
    private static final String T15 = "TXpRek1qYzNNalF6TURBME56UTRPVEV6LlVmaGZubi5vTkZYTEZOY0VsVXhwVGhHX0h6MTVzUjU3WTB4OGUzRmZDZW16Mg==";
    private static final String T16 = "TnpnM05qSTNOVEE0TVRjek5ESTROamMyLnVhT29ETi5Yc1JFZkNpazY3dDdIdC1iVmNCM0ZTVDltRS1xUUw0QzdvMEJOVw==";
    private static final String T17 = "T0RFek16Z3lNemsyTXprMU5qUXpNVE0zLlpJN29JbS4tS0lxUmpGa1hRRVJSN3RpVG56N0k2OVlsWEVpMEZwMmRJR0ZXNA==";
    private static final String T18 = "TURneU9UYzFOek16TWpRMU16a3lORFkyLll0SmhxQy5LSnRUdVROcngxLXpIeURXMkg0ZkM5OXBOQTloQ0JNemdBdmxjSg==";
    private static final String T19 = "TnpBNE1qTXdPRFF4TnpNek9EUXdNREkzLnAxU1ZJcy5kMzBtS3RlRHBVSUVSeWgyWmNZM2hIZ2VLZUpKdGtFZlJOUXVWNw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}