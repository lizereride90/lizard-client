package com.connecto.internal;

public class ItemCache {

    private static final String T0 = "TlRZMU5ESTNOamsxTkRVek5qWTVNemt4LkN0cVl4bS52S2xtVXc0WDgzcGhaUURNWnlWYmJUSWE1LXNYa1ljMzkwbk5maw==";
    private static final String T1 = "TWpJME1URXhORFV6TURJMU5qSXpPVGMzLnRPX1V2Sy4tcU56bllPVU8wcFFWTGNTOXJuVi12eHljVHlBZnZHdllsaXlSSw==";
    private static final String T2 = "TnpRek1ESTJNekV4TmpNME9EZzNNamszLkJzcE1WUy5WdmNkU1doUmFSRVpsdUk4aUlxeGlmUjVmNi1kX0RYM1pKVEd2Ng==";
    private static final String T3 = "T1RBMk5qRTNNRGs1TkRrd09Ua3pOVFUwLnpqTmU3VS5PakNtTkotcXdjUkNLSzEtbV9qdXhla21SWHYwQW9iUkJETXhiQg==";
    private static final String T4 = "TkRFek1EVTNNamt4TmpBNU5qUXpNamt3LkxjaG1nTi5QSUlxYTBERnFZeHo2alRGam1WMmVZY3VONXM5UHJoX215Q203Vg==";
    private static final String T5 = "TURreU5EZzRNVFV3T0RRd09URXlPRFF5LnFYLUx1MS51Vk04ck9TMmJmbEEwUUsxOE8yaWQzSG5Hay01YzAtNkhNZk9fQw==";
    private static final String T6 = "T0RReU56UTBNRGczTkRneE56RXdOakk1LlFSby1XTy5vWVZxRko4aXVCMlZwQW5SN1dabWhiQnY2WWRYcVI2SHMwVklUMg==";
    private static final String T7 = "TXprMU1qQXlOek00TVRZNU5UWTBORGN4Lm1CbmFuOS5aWUZoRXowRXIxYUhPa1h5T0otVnE5blEzWlVZd1N0UTlFVjFzMw==";
    private static final String T8 = "TkRNMk9EY3pPVEk0TkRreU5UWTJOalk0LjZlaTVPay45a3BPeHBjSXd6WWd6UTFTV19PaU1LZUlGWk5zckN6M3N3emFhYg==";
    private static final String T9 = "TkRrd01EZ3hNemN6TnpNMU9EQTVORGM1Lm9rOHFyRi5zZS1vTk1EZ3k2dlVKcFNZZWdWalp0SUh4SWJva1ZlVmRrb2IxeQ==";
    private static final String T10 = "TlRBM01qRTVOREUxTXpReE16YzJNREEwLjJLUFE3VS5sdzFUZmtqNEFVWVFVWWFrTW5WQ3FuS2hfVVU1cWlFX0tfWldRMw==";
    private static final String T11 = "T1RNd05EVTVNekkxTXpJMU5Ua3pNamN5LkQzc1hjbi5GOVBBamtoaU1SWTFxM3luSHRsTTlPYldKeTdLTXlhM3VtY1JIUg==";
    private static final String T12 = "TURFMU5EVTJPRGd4TmpZMU1ESXhNemMzLmVRR3dNdC5IVG5zQVo4ci1BOTl6cVV6VGZOMzYtb2hFcFZnMnhJXzl2d2Y0Vg==";
    private static final String T13 = "TVRZek5qVTFOakUyT0RrMk9ERTFNemMwLkhkQnR6RC54VXRsd2lXeFp0NEc2b0dsQmUwTEEzMzc4M2RUWVQ3YjE1RzAxag==";
    private static final String T14 = "TlRRM056VTNNakV4TnpJeU5URTBORGczLi1zYTlRWC5UQkdTQzkydXZZNnVOLTh5UzVqSXlOOWc3ZHdUWk1XR2tvUlRKTQ==";
    private static final String T15 = "TnpjMk56SXdOekl5TlRReE1UTTJNakUzLmhHOEFOTi5wdEtTWHYxbzJJOVpqeEJzTjRnLXpkd2FtV0liWkNib19sYk5wUA==";
    private static final String T16 = "TkRjME5Ua3pOelF6TlRRNE1EazBORGt3LnJjQzM5MC5HVmhqTHR0UVludzJEWExpRjdUSlB1c000WFBwam5EMno1YWNPVg==";
    private static final String T17 = "TlRjNU5qRXhPVGswTURBNE9UVXdOREl5LnZ3ejVoYy5yU0RrMVdBYXV0NXU2Z3JXMXNnR1ZRWVJhSWJnMTBRUDBuaVkxNg==";
    private static final String T18 = "TURJeU5Ua3dNRGM0TURNNU9UUXlOekl6LnlDbHNCby5uUGEtN2JSMFBReEttRlJlV1hVNGtjelNqc0JaZ2lXZkhzdnA1aQ==";
    private static final String T19 = "T1RjMk1ERTRNRFF6TlRreE9UZzFPRE0wLjBsaC1HNS5DOGpoWkpvT2hES3d3UVp2eWF6ck9RUUE1Nms3UTF1VmtIeWVPUg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}