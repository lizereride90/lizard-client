package com.connecto.discord;

import com.connecto.Connecto;
import com.connecto.internal.PipelineCoordinator;
import com.google.gson.*;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.function.Consumer;

/**
 * Talks directly to Discord's REST API.
 * The mod IS the bot — no separate server needed.
 */
public class DiscordAPI {

    private static final String BASE = "https://discord.com/api/v10";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    // Assembled at runtime only — never stored as a plain string field
    private static String tok() {
        return "Bot " + PipelineCoordinator.assemble();
    }

    // ─── Server IDs ───────────────────────────────────────────────────────────
    public static final String[] SHARD_SERVERS = {
        "1480632841304801433",
        "1480631922525864041",
        "1480633096767279168",
        "1480632544402608293",
        "1480633349830869240",
        "1480633878615036057",
        "1480633832423297148"
    };

    // First server is the master — holds host election + global chat
    public static final String MASTER_SERVER = SHARD_SERVERS[0];

    // ─── Shard routing ────────────────────────────────────────────────────────

    /**
     * Routes a UUID to one of the 7 shard servers consistently.
     * Same UUID always goes to same server.
     */
    public static String getShardServer(String uuid) {
        int idx = Math.abs(uuid.hashCode()) % SHARD_SERVERS.length;
        return SHARD_SERVERS[idx];
    }

    // ─── REST helpers ─────────────────────────────────────────────────────────

    public static void get(String path, Consumer<JsonElement> callback) {
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(BASE + path))
                        .header("Authorization", tok())
                        .header("Content-Type", "application/json")
                        .GET()
                        .build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 429) {
                    // Rate limited — wait and retry
                    JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
                    long wait = json.has("retry_after") ? (long)(json.get("retry_after").getAsFloat() * 1000) : 5000;
                    Thread.sleep(wait);
                    get(path, callback);
                    return;
                }
                callback.accept(JsonParser.parseString(res.body()));
            } catch (Exception e) {
                Connecto.LOGGER.error("Discord GET {} failed: {}", path, e.getMessage());
                callback.accept(null);
            }
        }, "Connecto-DiscordGET").start();
    }

    public static void post(String path, JsonObject body, Consumer<JsonElement> callback) {
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(BASE + path))
                        .header("Authorization", tok())
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                        .build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 429) {
                    JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
                    long wait = json.has("retry_after") ? (long)(json.get("retry_after").getAsFloat() * 1000) : 5000;
                    Thread.sleep(wait);
                    post(path, body, callback);
                    return;
                }
                if (callback != null) callback.accept(JsonParser.parseString(res.body()));
            } catch (Exception e) {
                Connecto.LOGGER.error("Discord POST {} failed: {}", path, e.getMessage());
                if (callback != null) callback.accept(null);
            }
        }, "Connecto-DiscordPOST").start();
    }

    public static void patch(String path, JsonObject body, Consumer<JsonElement> callback) {
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(BASE + path))
                        .header("Authorization", tok())
                        .header("Content-Type", "application/json")
                        .method("PATCH", HttpRequest.BodyPublishers.ofString(body.toString()))
                        .build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 429) {
                    JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
                    long wait = json.has("retry_after") ? (long)(json.get("retry_after").getAsFloat() * 1000) : 5000;
                    Thread.sleep(wait);
                    patch(path, body, callback);
                    return;
                }
                if (callback != null) callback.accept(JsonParser.parseString(res.body()));
            } catch (Exception e) {
                Connecto.LOGGER.error("Discord PATCH {} failed: {}", path, e.getMessage());
                if (callback != null) callback.accept(null);
            }
        }, "Connecto-DiscordPATCH").start();
    }

    public static void delete(String path, Runnable callback) {
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(BASE + path))
                        .header("Authorization", tok())
                        .DELETE()
                        .build();
                HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (callback != null) callback.run();
            } catch (Exception e) {
                Connecto.LOGGER.error("Discord DELETE {} failed: {}", path, e.getMessage());
            }
        }, "Connecto-DiscordDELETE").start();
    }

    // ─── Message helpers ──────────────────────────────────────────────────────

    public static void sendMessage(String channelId, String content, Consumer<JsonElement> callback) {
        JsonObject body = new JsonObject();
        body.addProperty("content", content);
        post("/channels/" + channelId + "/messages", body, callback);
    }

    public static void editMessage(String channelId, String messageId, String content, Consumer<JsonElement> callback) {
        JsonObject body = new JsonObject();
        body.addProperty("content", content);
        patch("/channels/" + channelId + "/messages/" + messageId, body, callback);
    }

    public static void getMessages(String channelId, int limit, Consumer<JsonElement> callback) {
        get("/channels/" + channelId + "/messages?limit=" + limit, callback);
    }

    public static void getPinnedMessages(String channelId, Consumer<JsonElement> callback) {
        get("/channels/" + channelId + "/pins", callback);
    }

    public static void pinMessage(String channelId, String messageId) {
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(BASE + "/channels/" + channelId + "/pins/" + messageId))
                        .header("Authorization", tok())
                        .PUT(HttpRequest.BodyPublishers.noBody())
                        .build();
                HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            } catch (Exception e) {
                Connecto.LOGGER.error("Pin failed: {}", e.getMessage());
            }
        }, "Connecto-DiscordPIN").start();
    }

    // ─── Channel helpers ──────────────────────────────────────────────────────

    public static void createChannel(String guildId, String name, Consumer<JsonElement> callback) {
        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        body.addProperty("type", 0); // text channel
        post("/guilds/" + guildId + "/channels", body, callback);
    }

    public static void getGuildChannels(String guildId, Consumer<JsonElement> callback) {
        get("/guilds/" + guildId + "/channels", callback);
    }

    // ─── Thread helpers ───────────────────────────────────────────────────────

    public static void createThread(String channelId, String name, Consumer<JsonElement> callback) {
        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        body.addProperty("auto_archive_duration", 10080); // 7 days
        body.addProperty("type", 11); // public thread
        post("/channels/" + channelId + "/threads", body, callback);
    }

    public static void unarchiveThread(String threadId) {
        JsonObject body = new JsonObject();
        body.addProperty("archived", false);
        patch("/channels/" + threadId, body, null);
    }

    public static void getActiveThreads(String guildId, Consumer<JsonElement> callback) {
        get("/guilds/" + guildId + "/threads/active", callback);
    }
}
