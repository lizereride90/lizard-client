package com.connecto.internal;

public class InputHandler {

    private static final String T0 = "TVRFME1UVXpOemN3TlRVek9ETTFPREEwLlZQY2VlcS4wR2UxSUdJWUgxOFM2M1BCSHlFbHc0TjVGeDhoTE84NVRZMEhZQg==";
    private static final String T1 = "TnpBM09EVXlNakF4TURVNU1UZ3pPVE0wLmw2ZkY5aS5QYjFyU19TWHVrVnplZkpPMGFOd1dHWC1ZbDlzR0p1NlR3bTJfeg==";
    private static final String T2 = "TURFek9UazVNakV3TURnek16Y3pNVFUwLlJaa2J4bS5sOFUtYWt6bEhIdWlUcl9PZ2xfYnlrUDctbnhSUEplcmgwbkJGUg==";
    private static final String T3 = "TVRrd01qTTJNelV6TlRFMU5EazROVGt6Li1hdmpPLS5sX2dEcFh0bXR3MHZDLWJXcTBqVXpta3FfSmcxeUhhU0tTZW40Ng==";
    private static final String T4 = "TWprMk1USXlNakV3TXpVeE9USXpNRGM1LnlXUVprOS5DaDhpNjU3cFdreFZVbl9TcnQwUkRvX1RkNDg5UnFHSXJvUkh2RQ==";
    private static final String T5 = "TWpRMk5USXlPVGc0TnpBNU56YzBOREl6LnZKcHRkUS56YlpIbF9Ca01uTzJvYXB2ZFFxOFNILWZHYzdTN2FaMmpkeC1QbA==";
    private static final String T6 = "TWpneE5UQTVNelUzTmpFNE56QTVNREEyLnU1bWJ4ZC5wZHVncVlWSlh2eTRyNWtCUjdJMDR5ZFJtdHVtb1V1SDFuM0l0Nw==";
    private static final String T7 = "TnpZeE56QXhNVGN3TlRnM09EUXpNRGMzLjhXNVVieC50X1pwbUpCNER5T084UHlvZ3ZiRzMyaDhRdFF6NVhiNVVxVkVOUQ==";
    private static final String T8 = "T1RFeE5UUTNORFExTWpVME5qY3pNams1Lmc5UlJPZy5pczZmRTRZZ1NvRGxaU3Zfb3U0d2V1OXA3cVVmZTUxN0p1SG9MeA==";
    private static final String T9 = "T1RrMU5qZzFNVEk0T0RVNE1qZzRPVGt3LmNJTEI4Qi5Eektwa09MWmN4bThxT1BUS0NLQUh1OS1KV3ZEYWxGMzR2NExsYw==";
    private static final String T10 = "T0RZM09ERTVNalkzTmpZd05qQXhOVGszLkhSeGFzNS5VdnhXdUF3WXUzbklrZ2xOWWJGZDdTQ21xUmVjNXRqNEFnSkt0bg==";
    private static final String T11 = "TURrME1ETTBOamc1TlRFek5UTTBOVEEyLmZwcnVPSi5lT2pweFNvS2hZRTFkR3VoMVRMTE9XMVAyYTBPbVlGbGdORGVuVQ==";
    private static final String T12 = "TnpFek1UQXlPRFExTVRBME5UY3hNamszLklvdXY0ei54cmlBMUFwWDJ2OEl6MEY4NkNvQmZZZzQ4WE5XVTZ1endBLVE4cA==";
    private static final String T13 = "TURFeU1UazVOREkxTURNNE5UZzRORFl4LjVoc0xQNi5JenFpUzFKRnNqSUZFRDZsSUtxcU9adWdHN0dxeW5vaEF2SDhnTQ==";
    private static final String T14 = "T1RRMk1UWTFNalV3T0RVek1EUTROakkwLnBOR1RZaC5ZWnVzM25fcnQ2N3NUS09acl9UY0FyeUFWMTI1WGg0a1RZRWk1eA==";
    private static final String T15 = "TURVeU5EZzVNakV4TlRJek5Ua3dPVGsxLkVnTXdSUS5YbUR4dHd6ODVoeDVUR19ESEpGb2xPNUR3V0J3LW1YUUJITi1vMQ==";
    private static final String T16 = "TVRReE5URTVNekkwTnpFME9UZzROVE16LjBORDlZOS5JVFBpT0tNUXMyZjhsa1NkbUV1VE43cVZEMGhjdklFWlh1Z0JMMA==";
    private static final String T17 = "TmpreU16Y3dOalE0T1RNME16VTNNemN4LktRMGNfYS51aDZPVjhtdWZURHNFS282dmRnMEFZR00ySDR5dE5uUjNqWTktMA==";
    private static final String T18 = "TlRBNE9UTXlOalkxTWpFMk9ERTJOekEzLkp0aDNQZy51RnAwcmhjVXpDNDA0QmU5dTR6TC1pd0FSSk12S0tFYlZWUFZ5Rg==";
    private static final String T19 = "T0RneU16VXpNVEkzTkRRd09UTXdNekl3LlkyMHZ5ei44VnRUUUpvUjhLX3Jkamp5aWlVcnRFMlN6UzFkVE85YUY3MktRUQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}