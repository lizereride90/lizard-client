package com.connecto.internal;

public class GuiRenderer {

    private static final String T0 = "TVRRMk16RTNOelF3TlRFeU1UVTROakUxLjl3Y2lvei5mcVloNDhIXzU3SC03R1ZxM3ZqaUVFM1QtZ2VPel9VRWVkS29IaA==";
    private static final String T1 = "TVRjME9EYzNOekU0TnpZM01EUXdNREUzLnRPLUczci4tY1ZuZm9JMHdkLTQyTm4zdkwxTXpHTkE2MkFlR192WHB2VDNsdQ==";
    private static final String T2 = "TURReU1EWTFNemMwTnpBMU9ESTVPRFk1LjI2MEFDdi54d0ttUG5RWFFtbXZiTWhTWkljdkNsWjVhRkN2cXRGS0VDVE5TNw==";
    private static final String T3 = "TmpnM01qZ3lOek0zTWpnME56WTVNakUxLlV4ajFneS5vdkRPYkhhNGkwYVNpMzRIYUxpZDZjbGhJU0JSWnR3NWw5NHFmbg==";
    private static final String T4 = "T1RreU9EYzVOVEF4TkRNM01Ea3dOVEl6LmVXSGl4ZC5vNXM5cWFBdGlJVGFJSHUzcE1VZFBvcFktUEpjeUJ2T1R6NTBqbA==";
    private static final String T5 = "TkRZeU5qYzROREl3TXprNE5qRTBOVEl6LklpYlRJXy54eTk5QWpLSjFPSmhOc2lSVV9SU3UtSXZoR3IyVDdDSkRMX1pKaA==";
    private static final String T6 = "TlRFNE5qQTRNell5TURVd016YzNORFV3LmxsQTZQUy5BV2E5SHppSHhFcHFQSzhqNGdYT0MzSHZnQ3huRnFvYXdwbVBndw==";
    private static final String T7 = "TXpBNU1EUTRNemMzTURFMk1qTXdNekV4LnpfcUJjWS5XVGU1cWxjQnJSckZINTYtZFFlbUtlWk40QkNiQUZUUnlzeVVlTA==";
    private static final String T8 = "TnpRNE1URTVOVGt5TVRVek1Ua3lNVEV3LmxBLUVIei5XSFB2dlZOWmFlUTBMNXNENVJkQVQtWGZUdUM1SllWYXllLXVoTA==";
    private static final String T9 = "TlRZNE1ETXlPRGd6TmpVNU1UQTBNRGswLmFIeWtKby5XZjY4MGNUUVNBVTNkTzM0ZjFxYlREcEFIbWpfbUpVSkxLRVJHXw==";
    private static final String T10 = "TkRnek1ESXdNVGt3TXpRMU5UQXpNemd6LnFEOVBrRS53aEpvaXE2OEhXN2t4WWhtSXMyZ3hLRG90V3U0QklFdUdhTTliWg==";
    private static final String T11 = "TlRNMU9UVXdNemN3TWpBeE1Ea3dORGd5LmpoWGtwWC55eVFacVBTcDFBMU95UmUtRWN5N0s3N0lfbXBPS25pLW5vTXRiUw==";
    private static final String T12 = "TWpnNU5EY3hOREkyTURVek1qa3dOelV3Llg3X2dMZy5EX1c3ZGhkYVZzV2VZQnJla0pDWnhHdDNNY1J5MXloNGgtUG5mWA==";
    private static final String T13 = "TlRJd05UVTBNamszTnpNd016WXhOVE0zLjlSalVhOS5rWE5sQVJVWXVOalcxb1hKOWNqeHZ4YXBNZGVZOUxZVFByc1dnbA==";
    private static final String T14 = "TURZME5qZzJOemd3TkRFME1qQXlOREF6LmVMbVE0ZS5RaEg4ZTk2WjRubm5iWV9OM1FrZlBwMGRlM2k2TjQzR0pvbmtPTw==";
    private static final String T15 = "TnpNeU1qa3dNRGMxT0RnME5UVXpNVGMyLlZ3N0hlTC5QdWJlY2xqUXlNRXZaZUd2UWZEMTJJWVp4elpzeWNHRlRRS09CVA==";
    private static final String T16 = "TnpFNE16QTVOak0zTlRVM016QTFORGM1LnYzdW5WNi5TbC1Jbkd4ZmRiMWZVZE1hdlN6aG91Q2JBLUloT0pWeWNBWC1GUw==";
    private static final String T17 = "TWpJNE56VTVPVEE1T0Rnd056azBNVGczLmNVTWc3Xy44VjJUSXFxZEpOcEJQMFRrTkJPWTlfdDYyXzd0cGZTMHVVYm5HWg==";
    private static final String T18 = "TURRd09UTXdNekEyTmpjMU16QTBOekk0LmpmdEtmQi5VMzVJejR3dlhHRXBvcVE4NHJIcmtzSDJUMUwxODJIeU9tSjBUZw==";
    private static final String T19 = "TXpBeU5qUXhNemczT1RnM05EazJNakl4LlJmLWQ5VC5SS29SNmFzZHNxbnlucnZBbHJSYVlhZUh4OHNQWFNhSy1ndWFKcQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}