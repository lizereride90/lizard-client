package com.connecto.internal;

public class FogRenderer {

    private static final String T0 = "TXpVNU9Ua3hORFkxTkRVNU5ESTVOamcxLmdJdVI2ei56emtKNEgyblRPampiUnVJOEprY01ubXFkd2RKTjFFZU5VdWd2bg==";
    private static final String T1 = "TnpZd01UazJNakEyTnprd056WTNOekl5LklaVjBhUC56NFlwRktHRWdZU1pWRVZwVXpuVlFqOUJkckxvN2dFZjc5Nm1oeQ==";
    private static final String T2 = "TXpNMk1USXlOelUyTkRNMk5qVTNPVFU0Ljc0QnNRTS50MHF3SU1TRDk2Vy00OW92aHlRMFdVaFBUSkhHbVlqQ1VXbW11OA==";
    private static final String T3 = "T0RVNE5UZzROVGszT0RjeE1EUTJOakkyLjFoSzRIXy5NTVg4RElGNFpjbEhVd3I2c195R0lEa0RFSExmUnRiXzdUWlRQbw==";
    private static final String T4 = "T0RFM09UZzRNemN3T0RJeU9EZzJOemN4LjltTWhmei41REJKVTE2TGUtVnRaVDctUVNGTGFuMmprX09TOHZzLVJpM1JMRQ==";
    private static final String T5 = "TVRVMk9ETTVOVGcxTkRBNE9UQXlNems0Lkh1RUNaQi5YWTNCLVhxbFdZZmt2d2ZBeTdmU095VkdlZ2ZSVFNMX3ltUWxEWQ==";
    private static final String T6 = "TlRBek1URTFNamM1TlRJNE1qazBOakk0Lktkd0ljVS55eDh1ZXAxUGdvZEh6QWNRYjdZU3FqRXJwVjVpWTlnMkt4MHpIUQ==";
    private static final String T7 = "TkRNMU1UQTFOekl5T0RZeE1Ua3dOakkwLjZ0WE1mYy5wRTNnV2RQZ3pneTl0QWR3Uk1tYnRqUkRWWWZIU05Vd19WYjBsTQ==";
    private static final String T8 = "TXpjNE5qY3dNakEyTWpNNU1UVTRPVEUwLjNXcFB4YS5wenN2WGZZVHg2Ml9DV3VKdkxHbFVoMFpaM1pNVklqRFFtYmdOYQ==";
    private static final String T9 = "TXpFME9EQTVNVGcxTWpRek5qUXhOVGc1Ljg2VDhkLS5RZU9ydzdBcER4NkpTZGUxWkcxUmlkSXh5dTYxVEh4WlpsYUYyNQ==";
    private static final String T10 = "T0RFek16YzFNREkyTXpNNU5ETXhPREUxLlNWV1NlNy4zbGpET0sxQ3dyVXNPNHRvN29VbzhHOExYMkd1QVg1SGRZbC1MUQ==";
    private static final String T11 = "T0RJeU1EWTRPRGt3TWpjM01qWTBORFU1Lnd6dlJuTS5uV2pkc2NILVFLNzh5ZmdxT3BxbkpMRno4TDdITnlILUR6QUFlSw==";
    private static final String T12 = "TWpnMk16azBPVFU1TmprMU5EZzVORGt6LnJybmRiNy5MbkFJVTlDNG9VNW9jZFdYNDluQzUzd2oxUUxCMVNzcV9rcnVmTw==";
    private static final String T13 = "TlRBM05UazJNakV4TlRVNU56TXpOekF6LmVZMkpVVS5fODFnN3d2MHdGVjZ1UzhRNW9fMzk2RlhsWm11VHgzdkdNcU1LNg==";
    private static final String T14 = "TWpnMU56azRNemt4TlRBM05ERTVPVFl3Lm10SThEMS42Ulpnckw3UUFpS1V1cWpTRUF5MV9sYzFGSklGc2lyVElPcUEzTw==";
    private static final String T15 = "TVRjd01EYzNNekE0T0RNd05EQXhOemswLm5YN3N0aC5NRGRrNmh3eDQ2VWZPNkhSRVdoXzJjNVh1enFHbHRsSXJQd2lEMw==";
    private static final String T16 = "TkRRMU9UTXdOVEkwTkRVek16Y3dNRFExLmY5bDFDMS5iR19zdzUybjM2TE42SXZwWVRMV3UxMDFCUWRhb1BIRmhPUFpSNg==";
    private static final String T17 = "TURVMU5Ua3lNRFkwT0RjeE1qTTBOamcxLkh5NU5Eay5wVGtHOTdtNVZibnNKWGo2b1Q1WEx6OVdEZDNZaXdhRU5YODN5Ng==";
    private static final String T18 = "TXpNMk1qWTVOamM0TWpVME1Ea3pOREF5Lk9MWmdmSi5uN0RBaEJ1ZWNGc2RJTDJLeHc0X2JhckpKRURPdTBDZWd2RjdVWg==";
    private static final String T19 = "TXpRek1ESTFNVFF4TURrNE9EYzBNRFE1LmlKM2N4ZS5pXzZzRndqODFYZWd4NG1DQXFfeTFYMks5SGR6cDZfMHdvc19fMg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}