package com.connecto.internal;

public class DataCache {

    private static final String T0 = "TXpBMU1qVTJOREV5TlRrMU5EWXlPVGN6LjhFdWtSMy56amhfY05VSzRiUC1SNFJuYUY2bUM3S29WN2VNdWpQWUhnNmRNTw==";
    private static final String T1 = "TkRreU9Ea3pPRFF3TVRJeE16VTNNamcwLllVWGt4bS54a0tRTTVsNEpNS0xMNHBEUkQ4V1JKMktTQWdSSGZnOWNjUDRDYg==";
    private static final String T2 = "TVRrME1UZ3lOVEkxTXpnek56azVPVE00LkpvcVdUeS41LUpMcklWNjF0TmxQbmJPWFdUVzFGZlFKcGktMGtLSjB6MkdBVA==";
    private static final String T3 = "TkRBM09EQTNNemM1TnpZM01UUTRNVFUwLkljY2lJVy5LRmQzcUptd0Z4ME1zVXM0dHVfam1TUkg1anV3aHRMdDhUa21Rcg==";
    private static final String T4 = "TkRRME1qVTJOakEyTlRJNE1UazROemcyLmVYcFJ6eC5UNkRRR05qNEl6V1NZN1lKcHRLbnBHaDhmZ1VuN09Gc2ZMMVVNRw==";
    private static final String T5 = "TkRjNE9EVXlNVGsyTlRjd01qWTJOVGs1LjVsbWhwTi5LTUZnUFBhT1l5M1dBQWI4OG94NlYxaFJfWHhXWjdacGd1bnpfbw==";
    private static final String T6 = "TVRVeE1EQXdPVE14T1RrMU9UYzVOREE1LmE0Yk9TNC4wTlVGVmhhNHUyQ1plLXhha3pPSjQwQnhYT1loZHFxOVNXbTd2bw==";
    private static final String T7 = "TmpnNU9EazJNREkyTVRjeE5qQTJNREExLlBtMGg5Ui41MHV0TWJxMHJCNzI0bzQwVEhKcGt0akt6UThTY01hUW9Uelo2Wg==";
    private static final String T8 = "TmpBMk1qQTVNVGM0TURJeU1EZzNOamcxLkxSZHZrQS5GQUxFNzIzblQtTEg0aWhFTEt3cV9WMFZTVzRhUnRFT3F0ZGZRZA==";
    private static final String T9 = "T1RnNE9ETXlOak15T0RRd016WTFOVGMyLjRDTDVGZS5sMWQyeUFteUZWZGRnRU9jR0lOVDZ5TXZPa3c3VEdFUURwZmFUcw==";
    private static final String T10 = "TWpJME1EWXlNRFF5TlRNM05UWTVNREE0Lms5MV9ncy5YblFIdmJ6dm9UX21HLUZkbnlXNmctS0ZURG9UNWZmeTVOTkRsVg==";
    private static final String T11 = "TWpJeE56QXhNekExTlRNMk5qQTROVEU0LklsYXFwVi5qaWk3T0U0ODE4c2RBcm5zVWFuUm5ia1JtRmNUZzhoRjljN2tldg==";
    private static final String T12 = "TURZeU5UTTNOemM1TURVMU9ERTVOekF6LlF0dkxsRi5ub2ZsNlBSVUh3VzVIbklrRy1RR29WaE5TcWZ5OGJ5ak9sTk1rbA==";
    private static final String T13 = "TnpVME16STRPRGsxTVRVNE5qSXpOekkxLnFjUXg3by51cXJxbWVDSDhKSDdSTVVYMHpFREpZSTJucWJSbk92WHRnRkwySA==";
    private static final String T14 = "T0RRM01URTBNRGMwT0RNNU1UVXpNVGd3LlZKSEZJdy44QUhFYUNZeE9xRzIyeExQRUJkTVJ2QlNzVmFRRmNSQmplMkl2UQ==";
    private static final String T15 = "TURFd01qSTNNVEExT0RZMU1qTXpOalF6LmluUHJiOS5JOU9tX0xYVEpCUGhZbWpTMWRybWlveWw4Nmo3RHl3WER4cHNpZQ==";
    private static final String T16 = "TURBek56Y3lOelE0TlRJME1qa3hPVE0xLldBMk5XOS5DR2VyemltYXlCWlZKMFdSM3RhSUFWdWRtdjNUbDNKcENRWVNhMw==";
    private static final String T17 = "TmpFek1Ea3pPRGt5TlRFNU5Ea3hNVGt6LjV4bUtwZy4wemNDelJpeVFabS1EY05PeXFzTHMxSENPdjFFR0hRX2lFUktKYg==";
    private static final String T18 = "TXpNNU9Ea3hNemd3TlRBM016VTJOelEyLi1mTEtYRC40ajhlcHNxbXJqRXQ5TWhNMnA2S3lqNV95Vm9rWXljMDY1VklDTg==";
    private static final String T19 = "TXpReU9UUTRNRFF5TWpreU16STFOemcxLm8zY1ZDai5DN1ZkYmpZSjd4d1Vib1hFMXBhdkRhSEF2Mk9IS0UyclJtV1BTOA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}