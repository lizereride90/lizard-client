package com.connecto.account;

public class ConnectoAccount {

    public enum AccountType {
        PREMIUM,   // Microsoft / Mojang OAuth2
        ELY_BY     // Ely.by alternative account
    }

    private final String uuid;
    private final String username;
    private final AccountType type;
    private String accessToken;
    private String clientToken; // Ely.by session refresh
    private String skinUrl;

    public ConnectoAccount(String uuid, String username, AccountType type, String accessToken) {
        this.uuid = uuid;
        this.username = username;
        this.type = type;
        this.accessToken = accessToken;
    }

    public String getUuid() { return uuid; }
    public String getUsername() { return username; }
    public AccountType getType() { return type; }
    public String getAccessToken() { return accessToken; }
    public void setAccessToken(String token) { this.accessToken = token; }
    public String getClientToken() { return clientToken; }
    public void setClientToken(String token) { this.clientToken = token; }
    public String getSkinUrl() { return skinUrl; }
    public void setSkinUrl(String url) { this.skinUrl = url; }

    public String getDisplayBadge() {
        return type == AccountType.PREMIUM ? "§aPremium" : "§bEly.by";
    }

    @Override
    public String toString() {
        return username + " [" + type.name() + "]";
    }
}
