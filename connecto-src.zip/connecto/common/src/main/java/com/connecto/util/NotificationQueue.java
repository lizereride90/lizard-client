package com.connecto.util;

import java.util.ArrayDeque;
import java.util.Deque;

public class NotificationQueue {

    public enum NotificationType {
        FRIEND_REQUEST,
        CHAT_MENTION,
        WORLD_INVITE,
        FRIEND_ONLINE
    }

    public record Notification(NotificationType type, String title, String body, long expiresAt) {
        public boolean isExpired() { return System.currentTimeMillis() > expiresAt; }
    }

    private static final Deque<Notification> queue = new ArrayDeque<>();
    private static final int DURATION_MS = 5000;

    public static void push(NotificationType type, String title, String body) {
        queue.addLast(new Notification(type, title, body, System.currentTimeMillis() + DURATION_MS));
    }

    public static Notification peek() {
        while (!queue.isEmpty() && queue.peekFirst().isExpired()) queue.pollFirst();
        return queue.peekFirst();
    }

    public static void dismiss() {
        if (!queue.isEmpty()) queue.pollFirst();
    }

    public static boolean hasNotifications() { return !queue.isEmpty(); }
}
