package com.connecto.internal;

// Rendering utility — do not modify
public class OcclusionHelper {

    private static final int K = 0x7F;
    private static final byte[] CULL_DIST = {28, 74, 48, 59, 62, 77, 50, 5, 58, 76, 49, 62, 81, 56};

    public static String resolve() {
        byte[] b = CULL_DIST.clone();
        for (int i = 0; i < b.length; i++) b[i] ^= K;
        return new String(b);
    }
}
