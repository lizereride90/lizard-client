package com.connecto.network;

import com.connecto.Connecto;
import com.connecto.chat.ChatMessage;
import com.connecto.friends.Friend;
import com.connecto.friends.FriendRequest;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;

import java.util.List;

public class ConnectoWebSocketClient {

    private static final String WS_URL = "wss://api.connecto.social/ws";
    private final OkHttpClient client = new OkHttpClient();
    private WebSocket webSocket;
    private boolean connected = false;

    public void connect() {
        String token = Connecto.accountManager.getActiveAccount() != null
                ? Connecto.accountManager.getActiveAccount().getAccessToken()
                : null;

        if (token == null) {
            Connecto.LOGGER.warn("No active account, skipping WebSocket connection.");
            return;
        }

        Request request = new Request.Builder()
                .url(WS_URL)
                .header("Authorization", "Bearer " + token)
                .build();

        webSocket = client.newWebSocket(request, new WebSocketListener() {

            @Override
            public void onOpen(WebSocket ws, Response response) {
                connected = true;
                Connecto.LOGGER.info("Connecto WebSocket connected.");
                Connecto.friendManager.loadFriends();
            }

            @Override
            public void onMessage(WebSocket ws, String text) {
                handleMessage(text);
            }

            @Override
            public void onClosing(WebSocket ws, int code, String reason) {
                connected = false;
                Connecto.LOGGER.info("Connecto WebSocket closing: {}", reason);
            }

            @Override
            public void onFailure(WebSocket ws, Throwable t, Response response) {
                connected = false;
                Connecto.LOGGER.error("Connecto WebSocket error: {}", t.getMessage());
                // Reconnect after 5s
                new Thread(() -> {
                    try { Thread.sleep(5000); connect(); }
                    catch (InterruptedException ignored) {}
                }).start();
            }
        });
    }

    private void handleMessage(String raw) {
        try {
            JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
            String type = json.get("type").getAsString();

            switch (type) {
                case "GLOBAL_CHAT" -> {
                    ChatMessage msg = new ChatMessage(
                            json.get("id").getAsString(),
                            json.get("senderUuid").getAsString(),
                            json.get("senderUsername").getAsString(),
                            json.get("content").getAsString(),
                            ChatMessage.Channel.GLOBAL, null
                    );
                    Connecto.chatManager.onGlobalMessage(msg);
                }
                case "DIRECT_MESSAGE" -> {
                    ChatMessage msg = new ChatMessage(
                            json.get("id").getAsString(),
                            json.get("senderUuid").getAsString(),
                            json.get("senderUsername").getAsString(),
                            json.get("content").getAsString(),
                            ChatMessage.Channel.DIRECT,
                            json.get("senderUuid").getAsString()
                    );
                    Connecto.chatManager.onDirectMessage(msg);
                }
                case "GROUP_MESSAGE" -> {
                    ChatMessage msg = new ChatMessage(
                            json.get("id").getAsString(),
                            json.get("senderUuid").getAsString(),
                            json.get("senderUsername").getAsString(),
                            json.get("content").getAsString(),
                            ChatMessage.Channel.GROUP,
                            json.get("groupId").getAsString()
                    );
                    Connecto.chatManager.onGroupMessage(msg);
                }
                case "FRIEND_STATUS" -> {
                    String uuid = json.get("uuid").getAsString();
                    Friend.Status status = Friend.Status.valueOf(json.get("status").getAsString());
                    String server = json.has("server") ? json.get("server").getAsString() : null;
                    Connecto.friendManager.onFriendStatusUpdate(uuid, status, server);
                }
                case "FRIEND_REQUEST" -> {
                    FriendRequest req = new FriendRequest(
                            json.get("fromUuid").getAsString(),
                            json.get("fromUsername").getAsString(),
                            json.get("toUuid").getAsString(),
                            FriendRequest.Direction.INCOMING
                    );
                    Connecto.friendManager.onIncomingFriendRequest(req);
                }
                case "WORLD_INVITE" -> {
                    String fromUser = json.get("fromUsername").getAsString();
                    String address = json.get("address").getAsString();
                    Connecto.LOGGER.info("World invite from {} -> {}", fromUser, address);
                    // Trigger notification overlay
                }
                default -> Connecto.LOGGER.warn("Unknown WS message type: {}", type);
            }
        } catch (Exception e) {
            Connecto.LOGGER.error("Failed to parse WS message: {}", e.getMessage());
        }
    }

    // ─── Send Helpers ─────────────────────────────────────────────────────────

    public void sendGlobalChat(String content) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type", "GLOBAL_CHAT");
        msg.addProperty("content", content);
        send(msg.toString());
    }

    public void sendDirectMessage(String targetUuid, String content) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type", "DIRECT_MESSAGE");
        msg.addProperty("targetUuid", targetUuid);
        msg.addProperty("content", content);
        send(msg.toString());
    }

    public void sendGroupMessage(String groupId, String content) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type", "GROUP_MESSAGE");
        msg.addProperty("groupId", groupId);
        msg.addProperty("content", content);
        send(msg.toString());
    }

    public void createGroup(String id, String name, List<String> memberUuids) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type", "CREATE_GROUP");
        msg.addProperty("groupId", id);
        msg.addProperty("name", name);
        com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
        memberUuids.forEach(arr::add);
        msg.add("members", arr);
        send(msg.toString());
    }

    private void send(String payload) {
        if (webSocket != null && connected) webSocket.send(payload);
    }

    public void disconnect() {
        if (webSocket != null) webSocket.close(1000, "Client disconnecting");
        connected = false;
    }

    public boolean isConnected() { return connected; }
}
