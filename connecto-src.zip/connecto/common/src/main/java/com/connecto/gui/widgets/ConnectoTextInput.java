package com.connecto.gui.widgets;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

public class ConnectoTextInput extends EditBox {

    public ConnectoTextInput(Font font, int x, int y, int width, int height, Component hint) {
        super(font, x, y, width, height, hint);
        this.setMaxLength(256);
        this.setBordered(false);
        this.setTextColor(0xFFFFFF);
        this.setTextColorUneditable(0x888888);
    }

    @Override
    public void renderWidget(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        // Dark background
        gfx.fill(this.getX() - 1, this.getY() - 1, this.getX() + this.width + 1, this.getY() + this.height + 1,
                this.isFocused() ? 0xFF5865F2 : 0xFF40444B);
        gfx.fill(this.getX(), this.getY(), this.getX() + this.width, this.getY() + this.height, 0xFF1E2030);

        // Placeholder text
        if (this.getValue().isEmpty() && !this.isFocused()) {
            gfx.drawString(
                    net.minecraft.client.Minecraft.getInstance().font,
                    this.getMessage(),
                    this.getX() + 4,
                    this.getY() + (this.height - 8) / 2,
                    0x666666
            );
        }
        super.renderWidget(gfx, mouseX, mouseY, delta);
    }
}
