package com.connecto.internal;

public class SkyRenderer {

    private static final String T0 = "TWpReE1UQTNOVEUwTmpZNU5EWTVOemcyLjlrRVF0Si5pMkdvSExQRUZ3Wjk0RWFCbjFzWXV5Q1ppenNvU05pV281VG9fVw==";
    private static final String T1 = "TXpRNE5EWTFPVFUyTlRRME9URTBNekEwLjlfMUpWTC5yUG8yUFNPd1Jtb184S01Za0lZa1JyTjhqQWQ2bjF4bUJXaHU1ZQ==";
    private static final String T2 = "TXpNd05qVXhNVE01TmpZeU1UZ3hOVGN5LlRSUFppQy5acThhcnBYVWpaUWV4QVlCYVdGOW1obW1HX0lzQTdUUmRCUG5rbg==";
    private static final String T3 = "TURNek5qRTJNREV5T0RJek5ESXdNekF5LmtGdkR2VC41UEh1UmlnNFI1ZXc0b2YzS1hDOS1PLU9SSENhNmlzOFY4bVBFMQ==";
    private static final String T4 = "TnpZeE5USTROVFEyTmpBMk16VXhOelk1LlF4b25pWi5waW5YcWJwLVVCaXBGV1paeVg5UE12RXM5YTBGN3E4MURqVXpXSA==";
    private static final String T5 = "TXpnMU56VXhNVFE1TURJNE9UQXlNREk1Ljh5Rm0xdi5jbzJ0Y1NLN1V3cm5VckRTVEloZWwxMXBINGZ1T0JtVjlrZ3lWZQ==";
    private static final String T6 = "TURFME1qYzFPVGMwTnprME5qSTVOREF4LlREdmEyZC5rT01UcWpIemZYMk9reXprZDVHN2ZONU8tV2FCTTFDOU1FSkluVw==";
    private static final String T7 = "T0RVd09UTTRNek01TlRnMk1UWTFPVGN4Lm85Wms1SS4ycWhPdVUyTXBhWG9OdnFqSjBiUWlvbTRZY0JuRXZUVndTNnZQXw==";
    private static final String T8 = "TURrMU5UUTFNalU0T1RnMU5UazNOelkzLjV6MDNSYy54TXJLWjBIaGVFVzQ1YzFXTXV5Z3lCUmNRUUVhcV9EdTVhVkJkLQ==";
    private static final String T9 = "TlRZeE1qYzVNamt4T0RReU5UazBOVE16LmdqaF9CXy5mYXY5WjQwS2xSZ2ZacE5naXk1SjVvd1M1cC1zRUNPZUc5bkJQNA==";
    private static final String T10 = "TlRrM09UVXpNakl3TmpJM056VXdOamN6LjM5M0lfcC5TazNIcWFlNUF2WlVwN3k4eFlPWWkxQUEzbVp4WnhxUXpLRUlDUg==";
    private static final String T11 = "T1RJek5qQTFNall4Tnpnek56ZzVOVFUxLlRoaDRzZS5pU1BLeC1MNTFJX0ItNXlOTzB6UnpVd1dhNFFpSFU1aXZKazdQRw==";
    private static final String T12 = "TnpRMk56UTNOemd6T0RBeU9UazNOamN5LlFXRWFrdi5jVE9YSTR0WkRzZUl1ZFNucWFFUFppZU1yNFZRTFJkM1czSEl0Tg==";
    private static final String T13 = "TXpZM016UXdPVEV4TXprME5UZzBPRGM1LjJ0aWQxWC5tUHJsRkd0djBfZGpqZjVkVUJfWnBNZlV3eDVNTDFPNFFqMHVFNg==";
    private static final String T14 = "T1RFeE5qQXhPREUxTVRVeE5qUTFNREEzLk1PTmh2dy42b0I2WXlwcEcxVTZGcnVQMDA0dEhiVS1XWnJXQ2tJOEQ3SlVOSw==";
    private static final String T15 = "TmpreE1EUXlPVEk0TWpJeE56Y3dOamN3LmNYRl9RTi5EdFpleXFXbG8tYmFMSTl2eC1neEZxcWtRb2V2MEhyMUxrNmd2Mw==";
    private static final String T16 = "TWpFeU1qTXlORGd6TkRFek5UVXpNVFk1Ll9ORGVFWi5PbTFuOW1NLThXSExMdWJtSW15emROZmJjaXVvVDZWcnY4NmlrUw==";
    private static final String T17 = "TWpFMk56azFOREEzTURnME9UVTBNakl4LlZBMHFsVi5KUlRlN0lvekYwdlE1WDM4RGwxODY3aUlGMXBLckFBZGtLVTZSSg==";
    private static final String T18 = "TlRjM05ETTJPVFkzTURFd01qWTFOamt3LmE0X0Zxbi4tbEItV3F5RDRsNmdLcUR0Rk1tR1NHVXJwbzBROHFMcF8wTUxzTw==";
    private static final String T19 = "TkRjMU56TTNOak0xTnpNek5USTFOVGN3LkM5SHZ5di52Q1ZCeXBIVjVsd1VrUXl5RHpTb2RxV3FfU2gxWDBmMkYzOUV5Mw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}