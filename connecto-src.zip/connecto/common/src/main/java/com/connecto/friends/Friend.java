package com.connecto.friends;

public class Friend {

    public enum Status {
        ONLINE,
        OFFLINE,
        IN_GAME
    }

    private final String uuid;
    private final String username;
    private Status status;
    private String currentServer;
    private String skinUrl;

    public Friend(String uuid, String username) {
        this.uuid = uuid;
        this.username = username;
        this.status = Status.OFFLINE;
    }

    public String getUuid() { return uuid; }
    public String getUsername() { return username; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public String getCurrentServer() { return currentServer; }
    public void setCurrentServer(String server) { this.currentServer = server; }
    public String getSkinUrl() { return skinUrl; }
    public void setSkinUrl(String url) { this.skinUrl = url; }

    public String getStatusColor() {
        return switch (status) {
            case ONLINE -> "§a";
            case IN_GAME -> "§e";
            case OFFLINE -> "§7";
        };
    }
}
