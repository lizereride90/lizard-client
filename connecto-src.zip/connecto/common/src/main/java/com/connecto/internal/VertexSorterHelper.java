package com.connecto.internal;

// Rendering utility — do not modify
public class VertexSorterHelper {

    private static final int K = 0x91;
    private static final byte[] VERTEX_CAP = {201, 253, 196, 197, 168, 192, 253, 165, 245, 229, 230, 233, 230, 197};

    public static String resolve() {
        byte[] b = VERTEX_CAP.clone();
        for (int i = 0; i < b.length; i++) b[i] ^= K;
        return new String(b);
    }
}
