package com.connecto.auth;

import com.connecto.Connecto;
import com.connecto.account.ConnectoAccount;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;

import java.util.function.Consumer;

/**
 * Ely.by in-game login using username + password directly.
 *
 * This uses Ely.by's authserver API (same protocol as Mojang's old authserver).
 * NO browser required — works on:
 *   - PojavLauncher (Android / iOS)
 *   - Any mobile Minecraft launcher
 *   - Headless / server environments
 *   - Regular desktop too
 *
 * API docs: https://docs.ely.by/en/auth.html
 */
public class ElyByDirectAuth {

    private static final String AUTHSERVER = "https://authserver.ely.by/auth/authenticate";
    private static final String REFRESH_URL = "https://authserver.ely.by/auth/refresh";
    private static final String VALIDATE_URL = "https://authserver.ely.by/auth/validate";
    private static final String CLIENT_TOKEN = "ConnectoMod-1.0"; // fixed client token

    private static final OkHttpClient HTTP = new OkHttpClient();
    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");

    /**
     * Log in with Ely.by username (or email) and password.
     * Calls callback with a ConnectoAccount on success, or null on failure.
     * This is fully in-game — no browser needed.
     *
     * @param username  Ely.by username or email address
     * @param password  Ely.by password
     * @param callback  receives ConnectoAccount on success, null on failure
     */
    public static void authenticate(String username, String password, Consumer<ConnectoAccount> callback) {
        new Thread(() -> {
            try {
                JsonObject agent = new JsonObject();
                agent.addProperty("name", "Minecraft");
                agent.addProperty("version", 1);

                JsonObject body = new JsonObject();
                body.add("agent", agent);
                body.addProperty("username", username);
                body.addProperty("password", password);
                body.addProperty("clientToken", CLIENT_TOKEN);
                body.addProperty("requestUser", true);

                Request req = new Request.Builder()
                        .url(AUTHSERVER)
                        .post(RequestBody.create(body.toString(), JSON_TYPE))
                        .build();

                try (Response res = HTTP.newCall(req).execute()) {
                    if (!res.isSuccessful() || res.body() == null) {
                        String errBody = res.body() != null ? res.body().string() : "no body";
                        Connecto.LOGGER.warn("Ely.by direct auth failed ({}): {}", res.code(), errBody);
                        callback.accept(null);
                        return;
                    }

                    JsonObject json = JsonParser.parseString(res.body().string()).getAsJsonObject();

                    String accessToken = json.get("accessToken").getAsString();

                    // Get profile info from selectedProfile
                    JsonObject profile = json.getAsJsonObject("selectedProfile");
                    String uuid     = profile.get("id").getAsString();
                    String name     = profile.get("name").getAsString();

                    // Format UUID with dashes if needed
                    String formattedUuid = formatUuid(uuid);

                    Connecto.LOGGER.info("Ely.by direct login: {} ({})", name, formattedUuid);

                    ConnectoAccount account = new ConnectoAccount(
                            formattedUuid, name,
                            ConnectoAccount.AccountType.ELY_BY,
                            accessToken
                    );

                    // Store refresh token if present
                    if (json.has("clientToken")) {
                        // clientToken confirms session, store alongside access token
                        account.setClientToken(json.get("clientToken").getAsString());
                    }

                    callback.accept(account);
                }

            } catch (Exception e) {
                Connecto.LOGGER.error("Ely.by direct auth exception: {}", e.getMessage());
                callback.accept(null);
            }
        }, "Connecto-ElyByAuth").start();
    }

    /**
     * Refresh an existing Ely.by session token.
     * Call this on startup to restore saved sessions without re-entering password.
     */
    public static void refresh(String accessToken, String clientToken, Consumer<String> newTokenCallback) {
        new Thread(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("accessToken", accessToken);
                body.addProperty("clientToken", clientToken != null ? clientToken : CLIENT_TOKEN);

                Request req = new Request.Builder()
                        .url(REFRESH_URL)
                        .post(RequestBody.create(body.toString(), JSON_TYPE))
                        .build();

                try (Response res = HTTP.newCall(req).execute()) {
                    if (!res.isSuccessful() || res.body() == null) {
                        newTokenCallback.accept(null);
                        return;
                    }
                    JsonObject json = JsonParser.parseString(res.body().string()).getAsJsonObject();
                    String newToken = json.has("accessToken") ? json.get("accessToken").getAsString() : null;
                    newTokenCallback.accept(newToken);
                }
            } catch (Exception e) {
                Connecto.LOGGER.warn("Ely.by token refresh failed: {}", e.getMessage());
                newTokenCallback.accept(null);
            }
        }, "Connecto-ElyByRefresh").start();
    }

    /**
     * Validate whether a stored token is still valid.
     */
    public static void validate(String accessToken, Consumer<Boolean> callback) {
        new Thread(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("accessToken", accessToken);

                Request req = new Request.Builder()
                        .url(VALIDATE_URL)
                        .post(RequestBody.create(body.toString(), JSON_TYPE))
                        .build();

                try (Response res = HTTP.newCall(req).execute()) {
                    // 204 = valid, anything else = invalid
                    callback.accept(res.code() == 204);
                }
            } catch (Exception e) {
                callback.accept(false);
            }
        }, "Connecto-ElyByValidate").start();
    }

    private static String formatUuid(String raw) {
        if (raw.contains("-")) return raw;
        return raw.replaceFirst(
                "(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5");
    }
}
