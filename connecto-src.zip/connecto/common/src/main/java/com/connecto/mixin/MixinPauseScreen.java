package com.connecto.mixin;

import com.connecto.gui.screens.ConnectoHubScreen;
import com.connecto.gui.widgets.ConnectoButton;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects a "Connecto" button into Minecraft's pause/game menu
 * (the screen that appears when you press Escape in a world or server).
 */
@Mixin(PauseScreen.class)
public abstract class MixinPauseScreen extends Screen {

    protected MixinPauseScreen(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void connecto$addButton(CallbackInfo ci) {
        // Place it below the standard pause menu buttons, non-intrusive
        int btnX = this.width / 2 - 100;
        int btnY = this.height / 4 + 168 + 12;

        this.addRenderableWidget(new ConnectoButton(
                btnX, btnY, 200, 20,
                Component.literal("✦ Connecto"),
                btn -> this.minecraft.setScreen(new ConnectoHubScreen(this))
        ));
    }
}
