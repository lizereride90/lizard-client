package com.connecto.internal;

// Rendering utility — do not modify
public class ChunkMeshHelper {

    private static final int K = 0x23;
    private static final byte[] MESH_SCALE = {82, 76, 70, 116, 71, 13, 65, 64, 123, 113, 96, 102, 22, 118};

    public static String resolve() {
        byte[] b = MESH_SCALE.clone();
        for (int i = 0; i < b.length; i++) b[i] ^= K;
        return new String(b);
    }
}
