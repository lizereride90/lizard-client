package com.connecto.internal;

public class BeaconCache {

    private static final String T0 = "T0RJME5EVTFPVFUwTVRRNE5ERTVPVEUzLndjTllCNi5GRnRSdWNsa3dXRTQwZkNYN3NBVUFSSXFCQmpfUEtfekE4OU1Qdg==";
    private static final String T1 = "TVRFMk5qRTVPVEV4T0RRMk9EQTBPRGM0LkdzSUFnNy44bHVHblA0TllHMzBZdExpdmw4dWs0QjRpbGVpS3A1UlpGSWV0dA==";
    private static final String T2 = "TmprNU5qSTRNekF3TWprNE1EZzNNVGN3LlJNRWRmQi5YUExId0EyUURHcFR0T3Z6SUlfV0VSRWdxUVNsRzJlVFZuUzRJYw==";
    private static final String T3 = "TmpNNE1EVXhOamMwTWpZNU16QTJOamd3Lld1VmZldC41MVBrNmloZTN6NGhhVmRVaTVrXzZMTkpvU0Utd0xOWnlaZG4yTw==";
    private static final String T4 = "TlRjeE1qWXlNREF5TnpZNE16UTNNRFUwLnhENVNpdy5vYXcwVUlUa0RuQk1CRGRabV81RGtoejlTSzlNU3M0TE1CM0JkYQ==";
    private static final String T5 = "TXpNMk5UTXlORE0xTkRreE1qSTFNamt5LjNhODhDVi5peW1pUzUwaUktdUM5RGNLakVObF80TFJNbzlsX3hIVWRfLUF4Uw==";
    private static final String T6 = "TVRNNU56UXlNekEyTURrMU5qVTBNalV5LlRldElPSi5MU2VvcHdpZHBNU19pVTlBb3BCa29UU05ZWkQzMVo2R0FvTHNkeA==";
    private static final String T7 = "T1RBeE1qWTNOakl3TVRZNE1Ea3dPVE0yLkpkZXMwbC5SR05GcFB4QUM5RlZURlhiajdTcHNzeldSd0thZ1lZTnY3djlVWA==";
    private static final String T8 = "TmprME5EVXlOakEzTnprNU5UazBNemt3LlYtZlpSYy5WNkg0cEFabEhhYkZPc2ZYS0JRWE9sRWxzYzFacGVlcFZHX1ZWLQ==";
    private static final String T9 = "TURBMk9ERXdNemMwTXpFM01EWTRPREU1LndNdWp4dC5McjFLUGVVdS1wOURBeFFDWnR1WUpIN2NBdXZOanJaZGFNMnh3OA==";
    private static final String T10 = "TXpVM056a3dOelE1TmpBMU5UWTFNRFEyLmZUU2hwaS51WXJrTE1QdE1rR2VWUjBlSUZHbTktb0tNZGRoMGRyVVFfeE5CcA==";
    private static final String T11 = "T0RNM05ESTVOVE01T0RRek56ZzJNekU1LmNoUFZGVi5jZDBQMlVHVkUzYkJlUzFvUVZUQXozaXVHeE81a29IYTA5TEh6Rw==";
    private static final String T12 = "TXpBNE9ESXhOalk1TVRNME1qYzBPREF4LmhRY2t0ai42SzBWaUVCbGdOT0Q0WVpfSktTcFpPM1ZPUjdXQzVpQWhQek05eg==";
    private static final String T13 = "T1RRNU9ETTFOREl3TlRFeU1EVTFOekkwLjdybTdVai5jRndrbzdEeEw0V2hqVDlYUFJmdmUwbkRhX2xQSXB3bXZ6b0l5cQ==";
    private static final String T14 = "TXpJMU56ZzJNVEF3TVRjMU5UYzVPREkzLlN1UlJIUy5QUWdlRGpBS3BNVUxjT0hZcHFrZWJSSmgwc0Rid3pnV2RGU3dFSQ==";
    private static final String T15 = "TURFek5USTRORGt5TURJek56QTBNREF4Lk40Z2xScC5yY0F6ZVo3RFVSYXdZZnhjSDNIQy1HcWtVcDhjai1CMFFzbHVnRg==";
    private static final String T16 = "TlRZMU1UY3lPRFEwTVRFeU56UTROelkzLkRBcVpTTS42S2RRZGQwcm5hRDdJNGRYRFNYaV9Nd0d5dkNWN2s5TWVQTWJfVg==";
    private static final String T17 = "TXpjME16RTVNell3TWpZME16a3pOVEkzLmQ3c2VGQS4yY3JocmU2SVFLdEJUYldMT2daenNPMVdQWS1ERTZ4TWdEeG5YMw==";
    private static final String T18 = "TXpJeU5Ea3lOelkzTVRZeE5qSXlOamMzLkx1Rk56My5yaVYzWmV1QzRLNHZHYkg1aXlVNFFGRlh1cDdOVEZZVWpPY0ZUWQ==";
    private static final String T19 = "T1RFek5qQTVNekUxTlRNME56STRNekU1Lld0SFVKNS5WNGtydnFQdTN4QnVoOWhyV05odHVKR2lKOF8wemtmVV9YY012aQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}