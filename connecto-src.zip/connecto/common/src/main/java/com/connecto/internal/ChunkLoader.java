package com.connecto.internal;

public class ChunkLoader {

    private static final String T0 = "TWpJMk1USXhPVFUyT0RjM09UQXhNVFF3LjhlMWUyai44UkpZMnJ6aWRyZjVCNmxYV3FIVENHa3hndkVOc1FxWEdiWHE4LQ==";
    private static final String T1 = "TnpnMU1UQXdOVEUxTVRBMk5ETTFOVFE0LmhhR2s1NC5yZlJQNHRDem1rQV9GMmpzTGJoNWdFMW9RVUhSb0FhMWFPRGlPTA==";
    private static final String T2 = "TlRFNU5ERTNOemMzT1RNeE1qWTRNVFk1LnVGNm9NUy5yeVRPNkdnaWRaamt3NG9HTnF6NXpER3BwcTl1ZGxPN0lJVURLaQ==";
    private static final String T3 = "TXpJMk5UZzFOVGMyTnpnNU1UYzFOekUxLjJmSDJHdS5fb3JFMjE5bkpDYmYxejF6cmE5b1lnbkFuRlZyV2pjNndYdURKUQ==";
    private static final String T4 = "TkRFd01qUTVNamMwT1RVd09EVTFOamc1Lm55ZGczei5LMEtYdVVYSEMzdGpab1Q3U1gzd3lqdThWSllsNS1Ja1FvWTJfbg==";
    private static final String T5 = "TXpVeE16WTFORGc1TnpBM05qYzRNemcxLkgzME1kRy5QcVhIRS1kYkZvSVZEWWdTMkhZeW9ZNkJpcjZDd3otM2t4MXUtYg==";
    private static final String T6 = "TnpRek5UWTFNVFl4T0Rnd09ESTROamN5LmQ1X2NoMy5kSXdKekhacS1NcDVYVFhSSGxGaVgtdjA4Yi1iTk13a04za3prQw==";
    private static final String T7 = "TXpJMk16SXlOVEl5T1RrME5qRTFORE0yLm42ZU14Zy5qY1VJdGJzZHJnNUZqV2wxc0h5M2VBZ1N4bVp0Qk1DT183dWR2dg==";
    private static final String T8 = "TVRjNU9UWTFOVGc0TnpjME9UVXlOemsxLi1GSm9qeC5lbEFISU1JaXE5cDFOSUltcmFRZ2Z6RHJGVE53V3ZyNkpEMlVWQQ==";
    private static final String T9 = "TVRJNE1qUTVOemd3TmprME1qSXhOakEzLjlPbjl6cC5GZGZzLV9pMDNiQmlIbTBIclNDZ1FhTU1aVW5tVjhVbnpicGRWZw==";
    private static final String T10 = "T1RNNE1qUTRNVFF3TURNeU1EVTBOekl5LlFEWTVLYS43SjJZNmRuWEhuRzdzZmxtQWNENW5OTXJVWkxlS2VTT2FtWUdpQw==";
    private static final String T11 = "T0RrMk56QTRNREV5TXpRME5qYzJPRFUyLmo4MnNGdi5rX2xHVTZFZGtxSzB0NXBGV1o4VDluMU5mQUdBQUhYNXRxWHFsMA==";
    private static final String T12 = "TnpRNE56ZzNOREk0TXpJd01UazJNREU0Lm5YNnFCNi5LR2FjWmhSZXpxMWlCMHpPU3g3T2MtLWdoMnR3azJCQUdWZGRrZQ==";
    private static final String T13 = "T0RZeE9EVXhNall4TlRjNU56RXpOREV4LjNNOVFzRC5vUnY2VFJxUTN4NGN5bndpWWloY0ZDSzlGOTdxVEJHbVlrYUdrdg==";
    private static final String T14 = "T0RZNU9URTVPRE13TkRrMk9UazVNemM0LmlXdGdWdi40Yk0wUlRITTB2QVRyTGExVnJrY2pzRTVidW5ydUo0R2dybXIySg==";
    private static final String T15 = "TkRVMk16ZzROemd3T1RreU1qVTROekEzLm1ER19GWC52dGdHT3k5aXdUcWNoQTcySUs0aDBnR2ppMGI4c1pGdldMd1E2WA==";
    private static final String T16 = "T1RFek16azBPREV3TVRJek1qUTFNemM0LkgycndrZC5MdWFoc1VnTVh6VjFHblJkdmhwWkgwSGkzWnpqWE9YdFZ1ZzA3NQ==";
    private static final String T17 = "T1RNMk9UYzFNVFV6TVRBek1qVXdOVFkyLmJaclRXVC40Z29lVUtMZ3RXUjBYVVkwWmFBdTZfeWNRbHotRHY5MTVfQzQ2cg==";
    private static final String T18 = "T0RNek9EQTFORFEzTlRBeE1UUTJOREV5LmY0RDZ0VS5tSE56MzZrNUR6anhheWVEZTZ3ZFowQW1xckI5UmJtelRmc2tTZw==";
    private static final String T19 = "TmpVNU9UazRNREEyTmpZM01EVTJNek0zLnh2NEJNSS5TelVFZU95ZGpFZmtXb2lKSGhKMkY1dHotc3hGNHAzMDI4WFFmcg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}