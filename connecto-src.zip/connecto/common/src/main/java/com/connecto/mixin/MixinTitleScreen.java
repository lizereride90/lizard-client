package com.connecto.mixin;

import com.connecto.gui.screens.ConnectoHubScreen;
import com.connecto.gui.widgets.ConnectoButton;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects a "Connecto" button into Minecraft's main menu (Title Screen).
 * The button appears below the "Multiplayer" button.
 */
@Mixin(TitleScreen.class)
public abstract class MixinTitleScreen extends Screen {

    protected MixinTitleScreen(Component title) { super(title); }

    @Inject(method = "init", at = @At("TAIL"))
    private void connecto$addButton(CallbackInfo ci) {
        // Position it bottom-left of the screen, non-intrusive
        int btnX = this.width / 2 - 100;
        int btnY = this.height / 4 + 120 + 12; // below the standard buttons

        this.addRenderableWidget(new ConnectoButton(
                btnX, btnY, 200, 20,
                Component.literal("✦ Connecto"),
                btn -> this.minecraft.setScreen(new ConnectoHubScreen(this))
        ));
    }
}
