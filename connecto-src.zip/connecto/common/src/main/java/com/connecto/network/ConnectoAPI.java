package com.connecto.network;

import com.connecto.Connecto;
import com.connecto.account.ConnectoAccount;
import com.connecto.friends.Friend;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ConnectoAPI {

    // Change this to your deployed backend URL
    public static String BASE_URL = "https://api.connecto.social";

    private static final OkHttpClient HTTP = new OkHttpClient();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public static void loginToBackend(ConnectoAccount account, Consumer<String> tokenCallback) {
        JsonObject body = new JsonObject();
        body.addProperty("uuid", account.getUuid());
        body.addProperty("username", account.getUsername());
        body.addProperty("accountType", account.getType().name());
        Request req = new Request.Builder().url(BASE_URL + "/auth/login")
                .post(RequestBody.create(body.toString(), JSON)).build();
        HTTP.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) { tokenCallback.accept(null); }
            @Override public void onResponse(Call call, Response response) throws java.io.IOException {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject json = JsonParser.parseString(response.body().string()).getAsJsonObject();
                    tokenCallback.accept(json.has("token") ? json.get("token").getAsString() : null);
                } else tokenCallback.accept(null);
            }
        });
    }

    public static void getFriends(ConnectoAccount account, Consumer<List<Friend>> callback) {
        if (account == null) { callback.accept(new ArrayList<>()); return; }
        Request req = new Request.Builder().url(BASE_URL + "/friends")
                .header("Authorization", "Bearer " + account.getAccessToken()).build();
        HTTP.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) { callback.accept(new ArrayList<>()); }
            @Override public void onResponse(Call call, Response response) throws java.io.IOException {
                List<Friend> friends = new ArrayList<>();
                if (response.isSuccessful() && response.body() != null) {
                    JsonArray arr = JsonParser.parseString(response.body().string()).getAsJsonArray();
                    for (var el : arr) {
                        JsonObject obj = el.getAsJsonObject();
                        Friend f = new Friend(obj.get("uuid").getAsString(), obj.get("username").getAsString());
                        f.setStatus(Friend.Status.valueOf(obj.has("status") ? obj.get("status").getAsString() : "OFFLINE"));
                        if (obj.has("skinUrl")) f.setSkinUrl(obj.get("skinUrl").getAsString());
                        friends.add(f);
                    }
                }
                callback.accept(friends);
            }
        });
    }

    public static void sendFriendRequest(ConnectoAccount account, String targetUuid, Consumer<Boolean> cb) {
        JsonObject b = new JsonObject(); b.addProperty("targetUuid", targetUuid); post(account, "/friends/request", b, cb);
    }
    public static void acceptFriendRequest(ConnectoAccount account, String fromUuid, Consumer<Boolean> cb) {
        JsonObject b = new JsonObject(); b.addProperty("fromUuid", fromUuid); post(account, "/friends/accept", b, cb);
    }
    public static void declineFriendRequest(ConnectoAccount account, String fromUuid, Consumer<Boolean> cb) {
        JsonObject b = new JsonObject(); b.addProperty("fromUuid", fromUuid); post(account, "/friends/decline", b, cb);
    }
    public static void removeFriend(ConnectoAccount account, String uuid, Consumer<Boolean> cb) {
        JsonObject b = new JsonObject(); b.addProperty("uuid", uuid); post(account, "/friends/remove", b, cb);
    }

    public static void getDiscoveryList(ConnectoAccount account, Consumer<List<Friend>> callback) {
        Request req = new Request.Builder().url(BASE_URL + "/discover")
                .header("Authorization", "Bearer " + account.getAccessToken()).build();
        HTTP.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) { callback.accept(new ArrayList<>()); }
            @Override public void onResponse(Call call, Response response) throws java.io.IOException {
                List<Friend> players = new ArrayList<>();
                if (response.isSuccessful() && response.body() != null) {
                    JsonArray arr = JsonParser.parseString(response.body().string()).getAsJsonArray();
                    for (var el : arr) {
                        JsonObject obj = el.getAsJsonObject();
                        Friend f = new Friend(obj.get("uuid").getAsString(), obj.get("username").getAsString());
                        if (obj.has("skinUrl")) f.setSkinUrl(obj.get("skinUrl").getAsString());
                        players.add(f);
                    }
                }
                callback.accept(players);
            }
        });
    }

    public static void sendWorldInvite(ConnectoAccount account, String targetUuid, String address, Consumer<Boolean> cb) {
        JsonObject b = new JsonObject(); b.addProperty("targetUuid", targetUuid); b.addProperty("address", address);
        post(account, "/invite/world", b, cb);
    }

    public static void updateProfile(ConnectoAccount account, String bio, String skinUrl, Consumer<Boolean> callback) {
        JsonObject body = new JsonObject();
        if (bio != null) body.addProperty("bio", bio);
        if (skinUrl != null) body.addProperty("skinUrl", skinUrl);
        patch(account, "/profile", body, callback);
    }

    private static void post(ConnectoAccount account, String path, JsonObject body, Consumer<Boolean> callback) {
        if (account == null) { callback.accept(false); return; }
        Request req = new Request.Builder().url(BASE_URL + path)
                .header("Authorization", "Bearer " + account.getAccessToken())
                .post(RequestBody.create(body.toString(), JSON)).build();
        HTTP.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) { callback.accept(false); }
            @Override public void onResponse(Call call, Response response) { callback.accept(response.isSuccessful()); }
        });
    }

    private static void patch(ConnectoAccount account, String path, JsonObject body, Consumer<Boolean> callback) {
        if (account == null) { callback.accept(false); return; }
        Request req = new Request.Builder().url(BASE_URL + path)
                .header("Authorization", "Bearer " + account.getAccessToken())
                .patch(RequestBody.create(body.toString(), JSON)).build();
        HTTP.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, java.io.IOException e) { callback.accept(false); }
            @Override public void onResponse(Call call, Response response) { callback.accept(response.isSuccessful()); }
        });
    }
}
