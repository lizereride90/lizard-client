package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.friends.FriendRequest;
import com.connecto.gui.widgets.ConnectoButton;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class PendingRequestsScreen extends Screen {

    private final Screen parent;

    public PendingRequestsScreen(Screen parent) {
        super(Component.literal("Pending Requests"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(new ConnectoButton(4, this.height - 24, 80, 20,
                Component.literal("◀ Back"), btn -> this.onClose()));

        List<FriendRequest> requests = Connecto.friendManager.getPendingRequests();
        for (int i = 0; i < requests.size(); i++) {
            FriendRequest req = requests.get(i);
            int y = 50 + i * 36;

            this.addRenderableWidget(new ConnectoButton(this.width / 2 + 20, y + 8, 60, 18,
                    Component.literal("§aAccept"),
                    btn -> Connecto.friendManager.acceptFriendRequest(req)));

            this.addRenderableWidget(new ConnectoButton(this.width / 2 + 84, y + 8, 60, 18,
                    Component.literal("§cDecline"),
                    btn -> Connecto.friendManager.declineFriendRequest(req)));
        }
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        this.renderBackground(gfx, mouseX, mouseY, delta);
        gfx.fill(0, 22, this.width, this.height - 28, 0xCC000000);
        gfx.drawCenteredString(this.font, "§b⚡ Pending Friend Requests", this.width / 2, 28, 0xFFFFFF);

        List<FriendRequest> requests = Connecto.friendManager.getPendingRequests();
        if (requests.isEmpty()) {
            gfx.drawCenteredString(this.font, "§7No pending requests.", this.width / 2, this.height / 2, 0x888888);
        } else {
            for (int i = 0; i < requests.size(); i++) {
                FriendRequest req = requests.get(i);
                int y = 50 + i * 36;
                gfx.fill(this.width / 2 - 150, y, this.width / 2 + 150, y + 32, 0xFF1E2030);
                gfx.drawString(this.font, "§f" + req.getFromUsername(), this.width / 2 - 140, y + 4, 0xFFFFFF);
                gfx.drawString(this.font, "§7" + req.getFromUuid(), this.width / 2 - 140, y + 14, 0x888888);
            }
        }
        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
