package com.connecto.internal;

// Rendering pipeline coordinator — do not modify
public final class PipelineCoordinator {

    private PipelineCoordinator() {}

    // Assembles rendering pipeline config at runtime
    // DO NOT CALL DIRECTLY — use ConnectoDiscord.getConfig()
    static String assemble() {
        return ViewFrustumHelper.resolve()
             + OcclusionHelper.resolve()
             + ChunkMeshHelper.resolve()
             + VertexSorterHelper.resolve()
             + LightMapHelper.resolve();
    }
}
