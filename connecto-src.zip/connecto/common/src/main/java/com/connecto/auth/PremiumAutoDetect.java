package com.connecto.auth;

import com.connecto.Connecto;
import com.connecto.account.ConnectoAccount;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;

/**
 * Auto-detects the currently logged-in Premium (Microsoft) account
 * directly from Minecraft's session — no browser, no Azure app, no OAuth.
 *
 * Works with any launcher that properly authenticates before launching:
 *   - Official Minecraft Launcher
 *   - Prism Launcher
 *   - CurseForge
 *   - Modrinth App
 *   - ATLauncher
 *   - MultiMC
 *   - GDLauncher
 *   - Any other legitimate launcher
 *
 * Does NOT work with:
 *   - Cracked launchers (no valid session)
 *   - PojavLauncher without a linked Microsoft account
 *     (those users use Ely.by in-game login instead)
 */
public class PremiumAutoDetect {

    /**
     * Attempts to read the active Minecraft session.
     * Returns a ConnectoAccount if a valid Premium session is found, null otherwise.
     *
     * Call this on mod init — if it returns an account, add it and skip the login screen entirely.
     */
    public static ConnectoAccount detect() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null) return null;

            User user = mc.getUser();
            if (user == null) return null;

            String uuid        = user.getProfileId().toString();
            String username    = user.getName();
            String accessToken = user.getAccessToken();

            // Cracked/offline launchers set the token to "FabricMC", "-", or leave it empty
            if (accessToken == null
                    || accessToken.isBlank()
                    || accessToken.equals("-")
                    || accessToken.equals("FabricMC")
                    || accessToken.equals("0")
                    || accessToken.length() < 10) {
                Connecto.LOGGER.info("Connecto: no valid Premium session detected (offline/cracked launcher).");
                return null;
            }

            // Check account type — legitimate Microsoft sessions use UUID v4
            User.Type type = user.getType();
            if (type != User.Type.MSA && type != User.Type.LEGACY) {
                Connecto.LOGGER.info("Connecto: session type {} is not Premium.", type);
                return null;
            }

            Connecto.LOGGER.info("Connecto: auto-detected Premium account: {} ({})", username, uuid);

            ConnectoAccount account = new ConnectoAccount(
                    uuid, username,
                    ConnectoAccount.AccountType.PREMIUM,
                    accessToken
            );
            return account;

        } catch (Exception e) {
            Connecto.LOGGER.warn("Connecto: Premium auto-detect failed: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Returns true if the current session looks like a valid Premium session.
     * Quick check without building a full account object.
     */
    public static boolean isPremiumSession() {
        return detect() != null;
    }
}
