package com.connecto.gui.hud;

import com.connecto.Connecto;
import com.connecto.util.NotificationQueue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * ConnectoHUD is called every frame to render:
 *  - Toast notifications (top-right corner)
 *  - Online friends count (top-right, below toasts)
 *  - World invite popup (center-top)
 *
 * Call ConnectoHUD.render(gfx, mc) from your loader-specific HUD event.
 */
public class ConnectoHUD {

    private static final int TOAST_W = 180;
    private static final int TOAST_H = 32;
    private static final int TOAST_MARGIN = 4;

    // Toast slide animation
    private static float toastAlpha = 0f;
    private static float toastX = 0f;

    public static void render(GuiGraphics gfx, Minecraft mc, float delta) {
        if (mc.screen != null) return; // Don't render over screens

        int screenW = mc.getWindow().getGuiScaledWidth();

        renderOnlineFriends(gfx, mc, screenW);
        renderToast(gfx, mc, screenW, delta);
    }

    private static void renderOnlineFriends(GuiGraphics gfx, Minecraft mc, int screenW) {
        if (Connecto.friendManager == null) return;

        int onlineCount = Connecto.friendManager.getOnlineFriends().size();
        if (onlineCount == 0) return;

        String text = "§a● §7" + onlineCount + " friend" + (onlineCount == 1 ? "" : "s") + " online";
        int textW = mc.font.width(text);

        gfx.fill(screenW - textW - 10, 2, screenW - 2, 12, 0x88000000);
        gfx.drawString(mc.font, text, screenW - textW - 6, 4, 0xFFFFFF);
    }

    private static void renderToast(GuiGraphics gfx, Minecraft mc, int screenW, float delta) {
        NotificationQueue.Notification notif = NotificationQueue.peek();
        if (notif == null) {
            toastAlpha = Math.max(0f, toastAlpha - delta * 0.1f);
            if (toastAlpha <= 0f) return;
        } else {
            toastAlpha = Math.min(1f, toastAlpha + delta * 0.1f);
        }

        // Slide in from right
        float targetX = screenW - TOAST_W - TOAST_MARGIN;
        toastX = toastX + (targetX - toastX) * 0.2f;

        int tx = (int) toastX;
        int ty = 16;

        int alpha = (int) (toastAlpha * 220);
        int bgColor = (alpha << 24) | 0x23272A;
        int borderColor = (alpha << 24) | 0x5865F2;

        // Background
        gfx.fill(tx, ty, tx + TOAST_W, ty + TOAST_H, bgColor);
        // Left accent bar
        gfx.fill(tx, ty, tx + 3, ty + TOAST_H, borderColor);

        if (notif != null) {
            String icon = switch (notif.type()) {
                case FRIEND_REQUEST -> "§b👥";
                case CHAT_MENTION   -> "§e💬";
                case WORLD_INVITE   -> "§a🌐";
                case FRIEND_ONLINE  -> "§a●";
            };
            gfx.drawString(mc.font, icon + " §f" + notif.title(), tx + 6, ty + 5, 0xFFFFFF);
            gfx.drawString(mc.font, "§7" + notif.body(), tx + 6, ty + 17, 0xAAAAAA);
        }
    }
}
