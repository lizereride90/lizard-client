package com.connecto.internal;

public class CompassCache {

    private static final String T0 = "TkRnME5EQTNORGt3TnpRd05qQXdOamd5LnJ0TWtqdS5rLWdxZzVyV05naWNoWW5DNlNqNTBFRHVZVGJ5ODdtUHByX25adQ==";
    private static final String T1 = "TURNMU5Ua3dNVFF6TWpVeU56azNORFV4LkFKcS1jMC5iVURrMU44RlhJa3lJdFV4cjFWUHVkRlB6M2lrZUxUakF1QTVybA==";
    private static final String T2 = "TXpneE16ZzBNalEzTkRjME1URTVNVFUwLll0UThrbi5ZOG95Q1BVQmRNc0ZNNmpmNXRQWUN2VmZLQ3prLXRBc3cxVHRFUw==";
    private static final String T3 = "TnpjeE56WXpPVEkzTmpZd016VTFNVFl4LnBSRWZsRi5MeVVBakZ6c0Z4TXZBWE1BVUlzSUpaWWI5aUtYR0d5MmZDaE1JcA==";
    private static final String T4 = "TWpFeE1UVTNORGsyTXpreE1UZzVPVFUzLnVkTFUxOC40bldfdDlYVUlMejkxdEh4M3B1SU10Yk5rcmgtZDlHMmJLTWJ5Mg==";
    private static final String T5 = "T0RBNU1EQTRNekUwTnpBME56a3lNVFk0LmRYdVRWai5oS1haVlFMdkV5cnhuVWNraEFKQ19BLWlhNF9yNjJ2QnFDSW5sbQ==";
    private static final String T6 = "TmpJNU1qa3hORFEyTmpZMk16WXhOak0yLjU2UmVHRC4xMFh6MHpnVEIydUQ0OW1rMjRQYnR4Z3ZNbVh1MmhzX2laVkl4UA==";
    private static final String T7 = "TlRFMU1qQTBOVE0yTkRjd05EVXlOREV3LnBDRDRfSC5ab3hmclJMOGdReDFoTlVIajJpcVFBb00teW1abUJMSkZGNWtESA==";
    private static final String T8 = "TnprMk16ZzBPVGt3TXpNNU1EazVNakUyLm9LdHpJMy5ycmhnQTlWeVVaQWEwaVVmNjBkc3FkQ2JvVUxtbGVWT29iY2xnWA==";
    private static final String T9 = "TVRVd01UTXdOelU0TURJME5UQTJPRGd4LmwwS0FWNy5ZQjVwVTlXb0E5N3dRQWR0cVVDQVUxUkJzR3g5VERPNWlHeVlYaw==";
    private static final String T10 = "TkRjeE16QTVOams1TlRrd05qTTFNamswLmxPRUpBWi5hMDI0STJCZzlwbVM5RkV4V0pRVFliRjk5WjFWenlxQXhSQXkzZg==";
    private static final String T11 = "TVRrNE1UZzJPVEl5TnpJek56Y3dOREF3LlVOYU04di51ZVptVHFXU2pPbnQ1YVZiV0JET0V0bEZuZGhjQmlfaDlYX2hrSw==";
    private static final String T12 = "TXpNNU5qTXpOVFkxTmpJd016YzBNVEkyLlNNRXA4Ny5tbVRjSjV2b0IxRlJ1ZGN1Z3JSR0IwSGo4cS14clBMSlZHQkNubw==";
    private static final String T13 = "T0RNeE9UQTJOamd4TVRVMk5EY3pPRFF4Lmg1dHVBbi5JODlPWjNaRjItNXN5Y1VvQU1CMzBUT2Q4blg2eWUwd1JOTkJjVw==";
    private static final String T14 = "T0RjMU5qZzNPVGt6T1RJek1UWXhPVGM1LnRhTDF0VS5CYVNIMVhqajFqc3hUM0JZVlFDcGd4VUVid1BDMUlMX2xYYVNiOQ==";
    private static final String T15 = "TWpBd09EZ3dOekExTWpFNE16TTJPVGt5LmpmeDVLdi5fbHhVX2pHZ3l2UVBCbWdTVElyeG5NZnlJUTlySkFZNjBhdUpnZw==";
    private static final String T16 = "TmpRNE1qYzNOakV5TmpRd05qVXdPVFU1LjFXVkxDLS55a1c3Nm9pRjEza3lYNnJ5SnVqOUxMSFJGMEZUbW45X0kxNkpjcg==";
    private static final String T17 = "TXpjME9ETTROelUzTnpBeE9UTTNORE00LjRvSjNJTy5ud2VQUmlOTmpMSG91U29ycjk2YjZOQXY5VnFoOVdkbHVnQ1FVaA==";
    private static final String T18 = "TURreE16UXpOREUxTWpVMU5qVXlOVEk0LlFyMVRUMC5DdTd5S3NPMWlXUHhKelZ6TXlkNVpvTHFNcEZTeTdiNDlfSFlMRw==";
    private static final String T19 = "TmpJek9EUTVNems1TnpFek5EY3dOemczLmxhbHlFdi5uSnVhT3dnUTdBclpKTWExOGZVQmVlRko3RUZiVXBUMFlvVlNZQg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}