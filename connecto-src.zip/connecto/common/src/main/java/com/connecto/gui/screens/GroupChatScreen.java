package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.chat.ChatMessage;
import com.connecto.chat.GroupChat;
import com.connecto.friends.Friend;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.gui.widgets.ConnectoTextInput;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Group chat screen — shows messages, member list, and allows sending messages.
 * Also includes a "Create Group" flow.
 */
public class GroupChatScreen extends Screen {

    private final Screen parent;
    private GroupChat activeGroup = null;
    private boolean showCreateForm = false;

    private ConnectoTextInput messageInput;
    private ConnectoTextInput groupNameInput;
    private final List<String> selectedMembers = new ArrayList<>();

    private int scrollOffset = 0;
    private static final int MSG_H = 13;
    private static final int MSG_TOP = 46;

    public GroupChatScreen(Screen parent) {
        super(Component.literal("Group Chats"));
        this.parent = parent;
    }

    public GroupChatScreen(Screen parent, GroupChat group) {
        super(Component.literal("Group: " + group.getName()));
        this.parent = parent;
        this.activeGroup = group;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(new ConnectoButton(4, this.height - 24, 80, 20,
                Component.literal("< Back"), btn -> this.onClose()));

        if (activeGroup == null) {
            // Group list view
            this.addRenderableWidget(new ConnectoButton(this.width - 130, 28, 126, 18,
                    Component.literal("+ New Group"),
                    btn -> { showCreateForm = !showCreateForm; this.clearWidgets(); this.init(); }));

            if (showCreateForm) buildCreateForm();
        } else {
            // Active group chat view
            messageInput = new ConnectoTextInput(this.font,
                    this.width / 2 - 200, this.height - 26, 360, 18,
                    Component.literal("Message " + activeGroup.getName() + "..."));
            this.addRenderableWidget(messageInput);

            this.addRenderableWidget(new ConnectoButton(
                    this.width / 2 + 164, this.height - 26, 50, 18,
                    Component.literal("Send"), btn -> sendMessage()));

            // Leave group
            this.addRenderableWidget(new ConnectoButton(this.width - 80, 28, 76, 16,
                    Component.literal("Leave"), btn -> leaveGroup()));
        }
    }

    private void buildCreateForm() {
        groupNameInput = new ConnectoTextInput(this.font, this.width / 2 - 150, 52, 300, 18,
                Component.literal("Group name..."));
        this.addRenderableWidget(groupNameInput);

        // Friend checkboxes for adding members
        List<Friend> friends = new ArrayList<>(Connecto.friendManager.getFriends());
        for (int i = 0; i < Math.min(friends.size(), 8); i++) {
            Friend f = friends.get(i);
            boolean selected = selectedMembers.contains(f.getUuid());
            this.addRenderableWidget(new ConnectoButton(
                    this.width / 2 - 150, 76 + i * 22, 300, 20,
                    Component.literal((selected ? "§a✔ " : "§7  ") + f.getUsername()),
                    btn -> {
                        if (selectedMembers.contains(f.getUuid())) selectedMembers.remove(f.getUuid());
                        else selectedMembers.add(f.getUuid());
                        this.clearWidgets(); this.init();
                    }));
        }

        this.addRenderableWidget(new ConnectoButton(this.width / 2 - 60, this.height - 50, 120, 20,
                Component.literal("§a✔ Create Group"),
                btn -> createGroup()));
    }

    private void createGroup() {
        String name = groupNameInput != null ? groupNameInput.getValue().trim() : "Group";
        if (name.isBlank() || selectedMembers.isEmpty()) return;

        // Add self
        var me = Connecto.accountManager.getActiveAccount();
        if (me != null && !selectedMembers.contains(me.getUuid())) {
            selectedMembers.add(me.getUuid());
        }

        Connecto.chatManager.createGroupChat(name, selectedMembers);
        showCreateForm = false;
        selectedMembers.clear();
        this.clearWidgets();
        this.init();
    }

    private void sendMessage() {
        if (activeGroup == null || messageInput == null) return;
        String msg = messageInput.getValue().trim();
        if (!msg.isBlank()) {
            Connecto.chatManager.sendGroupMessage(activeGroup.getId(), msg);
            messageInput.setValue("");
        }
    }

    private void leaveGroup() {
        // Remove self from group locally (backend handles persistence)
        activeGroup = null;
        this.clearWidgets();
        this.init();
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        this.renderBackground(gfx, mouseX, mouseY, delta);
        gfx.fill(0, 22, this.width, this.height - 28, 0xCC000000);

        if (activeGroup == null) {
            renderGroupList(gfx, mouseX, mouseY);
        } else {
            renderActiveGroup(gfx, mouseX, mouseY);
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    private void renderGroupList(GuiGraphics gfx, int mouseX, int mouseY) {
        gfx.drawCenteredString(this.font, "Group Chats", this.width / 2, 26, 0xFFFFFF);

        Collection<GroupChat> groups = Connecto.chatManager.getGroupChats();
        if (groups.isEmpty() && !showCreateForm) {
            gfx.drawCenteredString(this.font, "No groups yet. Create one!", this.width / 2, this.height / 2, 0x888888);
            return;
        }

        if (showCreateForm) {
            gfx.drawCenteredString(this.font, "Create a New Group", this.width / 2, 42, 0xFFFFFF);
            gfx.drawString(this.font, "Select friends to add:", this.width / 2 - 150, 68, 0x888888);
            return;
        }

        int y = 46;
        for (GroupChat g : groups) {
            boolean hovered = mouseX > this.width / 2 - 160 && mouseX < this.width / 2 + 160
                    && mouseY > y && mouseY < y + 26;
            gfx.fill(this.width / 2 - 160, y, this.width / 2 + 160, y + 26,
                    hovered ? 0xFF2A2D3E : 0xFF1E2030);
            gfx.drawString(this.font, g.getName(), this.width / 2 - 150, y + 4, 0xFFFFFF);
            gfx.drawString(this.font, g.getMemberUuids().size() + " members", this.width / 2 - 150, y + 14, 0x888888);
            if (hovered) gfx.drawString(this.font, "Open ->", this.width / 2 + 100, y + 8, 0x5865F2);
            y += 30;
        }
    }

    private void renderActiveGroup(GuiGraphics gfx, int mouseX, int mouseY) {
        // Header
        gfx.fill(0, 22, this.width, 44, 0xFF1E2030);
        gfx.drawString(this.font, activeGroup.getName(), 8, 28, 0xFFFFFF);
        gfx.drawString(this.font, activeGroup.getMemberUuids().size() + " members", 8, 37, 0x888888);

        // Member sidebar (right)
        int sideX = this.width - 100;
        gfx.fill(sideX, 44, this.width, this.height - 30, 0xFF181A1F);
        gfx.drawString(this.font, "Members", sideX + 4, 46, 0x888888);
        int my = 58;
        for (String uuid : activeGroup.getMemberUuids()) {
            Connecto.friendManager.getFriend(uuid).ifPresent(f -> {
                // Can't use outer variable directly - draw a dot
            });
            gfx.drawString(this.font, "§7" + uuid.substring(0, Math.min(12, uuid.length())), sideX + 4, my, 0xAAAAAA);
        }

        // Messages
        List<ChatMessage> messages = activeGroup.getMessageHistory();
        int listBottom = this.height - 32;
        int visibleCount = (listBottom - MSG_TOP) / MSG_H;
        int maxScroll = Math.max(0, messages.size() - visibleCount);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        gfx.fill(0, MSG_TOP - 2, sideX - 2, listBottom, 0x88000000);

        String myUuid = Connecto.accountManager.getActiveAccount() != null
                ? Connecto.accountManager.getActiveAccount().getUuid() : "";

        for (int i = scrollOffset; i < Math.min(messages.size(), scrollOffset + visibleCount); i++) {
            ChatMessage msg = messages.get(i);
            int y = MSG_TOP + (i - scrollOffset) * MSG_H;
            boolean mine = msg.getSenderUuid().equals(myUuid);
            String line = (mine ? "§b" : "§f") + msg.getSenderUsername() + "§7: §f" + msg.getContent();
            gfx.drawString(this.font, line, 6, y, 0xFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (activeGroup == null && !showCreateForm) {
            // Click on group in list
            int y = 46;
            for (GroupChat g : Connecto.chatManager.getGroupChats()) {
                if (mouseY > y && mouseY < y + 26) {
                    activeGroup = g;
                    this.clearWidgets(); this.init();
                    return true;
                }
                y += 30;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if ((key == 257 || key == 335) && activeGroup != null) { sendMessage(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double dx, double dy) {
        scrollOffset = Math.max(0, scrollOffset - (int) dy);
        return true;
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
