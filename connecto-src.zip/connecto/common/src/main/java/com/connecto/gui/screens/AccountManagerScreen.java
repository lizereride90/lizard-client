package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.account.ConnectoAccount;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.gui.widgets.ConnectoTextInput;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class AccountManagerScreen extends Screen {

    private final Screen parent;
    private static final int ENTRY_H = 32;
    private static final int LIST_TOP = 50;

    // Add account inputs
    private ConnectoTextInput uuidInput;
    private ConnectoTextInput usernameInput;

    private boolean showAddForm = false;
    private ConnectoAccount.AccountType addType = ConnectoAccount.AccountType.PREMIUM;

    public AccountManagerScreen(Screen parent) {
        super(Component.literal("Account Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(new ConnectoButton(4, this.height - 24, 80, 20,
                Component.literal("◀ Back"), btn -> this.onClose()));

        this.addRenderableWidget(new ConnectoButton(this.width - 110, this.height - 24, 106, 20,
                Component.literal("＋ Add Account"),
                btn -> { showAddForm = !showAddForm; rebuildWidgets(); }));

        if (showAddForm) {
            uuidInput = new ConnectoTextInput(this.font, this.width / 2 - 200, this.height - 80, 190, 18,
                    Component.literal("UUID"));
            usernameInput = new ConnectoTextInput(this.font, this.width / 2 - 4, this.height - 80, 190, 18,
                    Component.literal("Username"));
            this.addRenderableWidget(uuidInput);
            this.addRenderableWidget(usernameInput);

            this.addRenderableWidget(new ConnectoButton(this.width / 2 - 200, this.height - 58, 90, 18,
                    Component.literal(addType == ConnectoAccount.AccountType.PREMIUM ? "§aPremium ✔" : "Premium"),
                    btn -> { addType = ConnectoAccount.AccountType.PREMIUM; rebuildWidgets(); }));

            this.addRenderableWidget(new ConnectoButton(this.width / 2 - 104, this.height - 58, 90, 18,
                    Component.literal(addType == ConnectoAccount.AccountType.ELY_BY ? "§bEly.by ✔" : "Ely.by"),
                    btn -> { addType = ConnectoAccount.AccountType.ELY_BY; rebuildWidgets(); }));

            this.addRenderableWidget(new ConnectoButton(this.width / 2, this.height - 58, 80, 18,
                    Component.literal("§aConfirm"), btn -> addAccount()));
        }
    }

    private void addAccount() {
        if (uuidInput == null || usernameInput == null) return;
        String uuid = uuidInput.getValue().trim();
        String name = usernameInput.getValue().trim();
        if (uuid.isEmpty() || name.isEmpty()) return;

        ConnectoAccount acc = new ConnectoAccount(uuid, name, addType, "");
        Connecto.accountManager.addAccount(acc);
        showAddForm = false;
        rebuildWidgets();
    }

    private void rebuildWidgets() {
        this.clearWidgets();
        this.init();
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        this.renderBackground(gfx, mouseX, mouseY, delta);
        gfx.fill(0, 22, this.width, this.height - 28, 0xCC000000);
        gfx.drawCenteredString(this.font, "§b👤 Account Manager", this.width / 2, 28, 0xFFFFFF);
        gfx.drawString(this.font, "§7Switch accounts without restarting the game.", 10, 38, 0x888888);

        List<ConnectoAccount> accounts = Connecto.accountManager.getAccounts();
        ConnectoAccount active = Connecto.accountManager.getActiveAccount();

        if (accounts.isEmpty()) {
            gfx.drawCenteredString(this.font, "§7No accounts added.", this.width / 2, this.height / 2, 0x888888);
        }

        for (int i = 0; i < accounts.size(); i++) {
            ConnectoAccount acc = accounts.get(i);
            int y = LIST_TOP + i * ENTRY_H;
            boolean isActive = acc == active;
            boolean hovered = mouseX > this.width / 2 - 200 && mouseX < this.width / 2 + 200
                    && mouseY > y && mouseY < y + ENTRY_H - 2;

            gfx.fill(this.width / 2 - 200, y, this.width / 2 + 200, y + ENTRY_H - 2,
                    isActive ? 0xFF2C3E6E : (hovered ? 0xFF2A2D3E : 0xFF1E2030));

            if (isActive) {
                gfx.fill(this.width / 2 - 200, y, this.width / 2 - 196, y + ENTRY_H - 2, 0xFF5865F2);
            }

            String badge = acc.getDisplayBadge();
            gfx.drawString(this.font, (isActive ? "§b✔ " : "§7  ") + "§f" + acc.getUsername() + " " + badge,
                    this.width / 2 - 188, y + 4, 0xFFFFFF);
            gfx.drawString(this.font, "§7" + acc.getUuid(), this.width / 2 - 188, y + 14, 0x666666);

            if (hovered && !isActive) {
                gfx.drawString(this.font, "§a[Switch]", this.width / 2 + 110, y + 4, 0x57F287);
            }
            if (hovered) {
                gfx.drawString(this.font, "§c[Remove]", this.width / 2 + 150, y + 4, 0xED4245);
            }
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<ConnectoAccount> accounts = Connecto.accountManager.getAccounts();
        ConnectoAccount active = Connecto.accountManager.getActiveAccount();

        for (int i = 0; i < accounts.size(); i++) {
            ConnectoAccount acc = accounts.get(i);
            int y = LIST_TOP + i * ENTRY_H;
            if (mouseY > y && mouseY < y + ENTRY_H - 2) {
                // Switch
                if (mouseX > this.width / 2 + 110 && mouseX < this.width / 2 + 148 && acc != active) {
                    Connecto.accountManager.switchAccount(acc.getUuid());
                    return true;
                }
                // Remove
                if (mouseX > this.width / 2 + 150) {
                    Connecto.accountManager.removeAccount(acc.getUuid());
                    return true;
                }
                // Click row to switch
                if (acc != active) {
                    Connecto.accountManager.switchAccount(acc.getUuid());
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
