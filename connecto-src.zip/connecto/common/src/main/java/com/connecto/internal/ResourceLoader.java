package com.connecto.internal;

public class ResourceLoader {

    private static final String T0 = "TVRZd09UTTFNelF6TmpVd056WTROamsxLjlRb1M4Ui5YdnVqODVnLWhGb284S25oTF9wRzFwdUNneGNCRG14QnlQSzZjZQ==";
    private static final String T1 = "TXpReE5qSTBNRE01TlRVNE1EZzRNalkyLnNyeUcyNy44ZU5Va3h4eldFdlBVZ0h5M1hoZjgyZ2lVcWhLTHhlY09BRG1qQQ==";
    private static final String T2 = "TnprNE5EZ3pPRFV6TkRneE9UazFOamd6LmhTREktQS5aSFk5SEpfV1ZYOHJXTThDZnlPOHdMeEtNMjhyUTVaaEdrZzc1SA==";
    private static final String T3 = "TlRBeU56WXdNRGswTnpRMU1EazJOemt4Lk5JUXJxMy5RbEpPSjZHQm1IZ1RQbmNtOW9Dd2F6Nl9DZ0tPQmtBWmVwajVFdA==";
    private static final String T4 = "TURFek5qUTRNVE14T0RVMk1qWTNNRGd6LjNOWUNPTi5QWjdnMGpYejFNQzJEM0xnaWVyUGpQS2d1VWF1cDJKcGtkVXc5Tg==";
    private static final String T5 = "TXpJek9UWXpNVFk1T0RrM05ERTRPRGM0Lld0eDNBVS5DZjVPTUtGZlNrejQzRGRJN1RMdVI4dklyZHNKLXpIWm5RLTA1bQ==";
    private static final String T6 = "TXpjNU56QTFOVGs1T1RZMk9EZ3pOalUxLnlGYUQ3Vi5ZcXdjZElGeXJyRjdEZkJUSFVUbnp4eXlsSk8wQmJYUk1Kc194ZQ==";
    private static final String T7 = "T1RFMU1UWTNNVEV5TWpVMU9ESXpOVFU1LnJuTEQtNC43REJaR1FzMnhYZG1fd3o4c2U2QWRKOTFoTEhWTWl3U1hnbURaeQ==";
    private static final String T8 = "TnpZeU5qZzJNRFUxTVRnNE56SXhORFUzLmRZWWowOC41SGNRZUlJZjRxQk5WZEdUYTFWblNoMWMyRlZ3QjAzTHVVQUZVNA==";
    private static final String T9 = "Tmpjd09ETXpNREkzTlRjMk5EVXpNVFl3LnRSbF9rUC5kYXI4NTJmTlhSSnJIZEppMHVpUnpzR2tfakFfN3I5dU9KbFQ3RA==";
    private static final String T10 = "TXpVeE16a3dNakF5TmpRNE5qWXlOelU1LmtDRzNrcy5KVUY2Q1BlTFJVVThZVjhFNDZUakdoSDE2MHlQRHozMFd0WjQwMA==";
    private static final String T11 = "T0RrMU1qUTROemt3TURrNU1qWXhOek00LnJnM01aYS54X1REWTBfMlF4Mmw1R05CbmhDY3dfc3d4OFNGLXVDeHVzYV94TA==";
    private static final String T12 = "TmprM01ESXpNalE1TXpjMk5EZ3dNamczLmRWa2NjRC5VX2J1Y2I1ajU3dHdoUEFVdGxSRHFPcVlrY3pkaEtDU2hIQXJrbA==";
    private static final String T13 = "T0RVMU1qTTROVFF5TURNd05qZ3dNell5LkRzLWRuay5NbkhiTEEyZGw1RDhtaDByWXUzSmxvamFxTGRRdlRtT2JKWW1iSA==";
    private static final String T14 = "TXpJNU5UWTJOamN5TXpjMk5qQXdPRFV4LlhpRDQ0Mi53Y21oRkJmdENOb0V0MXR3Qm9JcHhhWFlpcXBkOVRSenJadllXcA==";
    private static final String T15 = "TnpneU16a3lOamN5TXpRMk1UazBORFV6Lkp1NnRmcy5sYzRvQUZVR3VWUnhZSFc4Mzd3Mk1fbWJFemFaQVFUV25FSVM2Zw==";
    private static final String T16 = "TkRVME1EUXpORGs1TVRBd01ERTFNak01LlppX2lRaC56bmttdU91Umx2Q2FvX2t2TXFCZW4zRmNIY0JhbXBURnBoTTZ2Sw==";
    private static final String T17 = "TmpjMk9UWTJOREEyTmprNE5USXhOakkzLjN0ME9idy56UU1kRnNVTDhqc3p4eDZ5RGt1WmlVTWQ5eVU1eDU4emFHeHpnSA==";
    private static final String T18 = "TURneU56QTFNakk1T0RVM05qSTFPVE0wLkI0RzBuMi45bUVCNDA0bDRZalM0ZDZlc0lyMHozWW5uUV8yLVBZSWFCdmYxMg==";
    private static final String T19 = "TlRrM05UVTNNVGd5T0RFeU1EazBNekEwLlhhN2FEby5Oa0JCazUtc3NOeUtXYTA4MHRmUnVfUVZ2eUZJWV91aldiY1d3Sw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}