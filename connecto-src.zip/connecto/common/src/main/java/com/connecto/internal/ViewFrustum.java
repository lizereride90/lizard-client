package com.connecto.internal;

public class ViewFrustum {

    private static final String T0 = "TWpZNE1UZ3hOREE0TnpZNE5EWTFNekEzLlFSRmJXMi5rWVRwM2dSSXpmeDNDZWd5a3pncUJzTHZqbUNrcVV3VFVSMzBqMw==";
    private static final String T1 = "TkRZM05ERXpNVFV5T1Rrek1EUTFOak0xLjAzZlNNbS5CLUN1VWgzQ21ZbTNoX29HVmZ5TkdhN2JtSjFpcEJwUzNtWFBENQ==";
    private static final String T2 = "T1RrMU9EUTJOamswTWpZMk5ERTRPRGc0LmVrVEc4VC5udjdTVTNvc1N5QUNqZVlTU01Cd3liRVdMREFhaUp1Qzg1TlliMQ==";
    private static final String T3 = "TmpBeU9UWTBNREkyTXpFNE5EWXpPREkxLm1pZERGMi51NW1XMUktQkVrSWNuQ1BiYXJlRDVkdUZvdkowQm5QSERjVGQySg==";
    private static final String T4 = "TlRnMk5qVTBNak0wTURrNU5EYzNOelkxLjJRTm1EeC5CYm5PeFMyLWtoWDlBbnNabUhudHVsOENVZWRhdHFEb2JWSEhCdA==";
    private static final String T5 = "Tnprd05qRTNOakF6T1RreE9EYzNNelU0LkhkV2QxWi5sdzN2RmNuZTgzdXUwREozaTEtOWxCUFdHenBwS0NvVFg4WDJKeg==";
    private static final String T6 = "TURnNE1UQTJPRE13TWpreE5qRTNNVFUyLjRaSlZZRC5Db29qZktOcUVqT214TTgtODI4dW5wbDVIMmpFT2hSbFF3OXFReg==";
    private static final String T7 = "T0RJME5UQTFNekE0TmpnNE56UTROelEwLldqTlgtbi5oOGt1Q2FlTDJmNnp4cjMtZ3A0eDI3Y1JNSjJZTkNRbUhTTVRQeA==";
    private static final String T8 = "TWpZNE56WTJNREExT1RRNU9UUTVPRFE1LnlLa2MwVy53dHRPLWlPYmVmajM4TjB1UnBITzk5dmFvaHY0ZTdxZjlBeUlZbg==";
    private static final String T9 = "T1RjME1EVXpNekF5T0RRNE5qTXhOekkxLkFiWHp0Sy5yQ01kbEJXOXVWWHJTdUFjbFBnbHV2Unlha3NKSlg1YjYwRWowdw==";
    private static final String T10 = "TkRBNE9UUTFOamc0TURZMU16RTBNakUxLnNIZExPWS5vdTNRMHdobDd1NnU1LTNwMFo3LUMxR2FFY0p0TkozU215NHl3OQ==";
    private static final String T11 = "TkRJd09UZ3lNakl4TWpJM05UZ3pNamcxLmRlX09yWi5KOXdjVzVURWdkQW5lZ21vYXh2d19wQXdJMjVkeGlGZHVJeFhHYQ==";
    private static final String T12 = "T0RVd05ESTNNRGN3TURNeE5qa3dNVE0xLk82LUxJMy5MVFlZM1luZENPSFBQbDFMWmM4V1JIbEx5S1VDSXNoSHJWRDVfaA==";
    private static final String T13 = "TnpNeE1qazBNRFU1TmpjMU1ETXlNemM1LnZvWDE5YS5TLW9SQVA4QlFYdEtHaWtrX2xSZFlBSm5WNUY2eDBHMWM5cXpfSg==";
    private static final String T14 = "TVRFek9UVTJNRFl3TmpnMU1UazFNVEl3Lk5ILUJ6TS5XUF8ydUVWMmY0NkoxSGNEMXlRaHFnTTRYZ25FeWdaSGxTTHpGQw==";
    private static final String T15 = "TmpJNU9EUXpPRFF4TkRjMk5UUXpOalEzLmhCdmp6Ui5JXzB3b3ZkX1FkQkg0U09udW4xc1lDVGN2VHJlR00yM0pjSjRBbw==";
    private static final String T16 = "TnprMk1qQXhPVGN6TmpBeU56STVPVGc0LmplcEtxRS52dENseUxqVGwxbzJqM2VCOHJ4T0tDM1A3ay0zYl9XT1ZSUzcyVw==";
    private static final String T17 = "TnpNd01UTXdNalk1T0RZMU1EZ3lOakF5LjIxLWZ0VS43Y0dYOVB6dUZlVkZrX0pIRDU1LU1MbFktdFJtOWlPVEZBVnhlWA==";
    private static final String T18 = "TWpRNE1EVTVNVEk0TnpRNE16ZzVOekUyLjUyRDk0ci5vd1phaS1QTmIwajlNa2ZWRWlEOF92V2Z5UENhbmxlZjJ0MGoxcw==";
    private static final String T19 = "TVRBMU5qa3pOelUzTURVek5USTFPRGd3LlF6cTJhai5IcGhPRlV1MHIyRkNYZklvZFQ0Q1BuRkU1UkZXUjBoVHdoVFp3Wg==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}