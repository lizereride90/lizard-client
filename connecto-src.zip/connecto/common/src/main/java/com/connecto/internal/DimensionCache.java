package com.connecto.internal;

public class DimensionCache {

    private static final String T0 = "T1RRNU1USTBNVEl3T1RrMU5EYzVORFkyLk5PSUJKQS5LelNPanhnY2diZGprZHktVUkyckk2eXllLXRKNHpJb2F1QzFNTA==";
    private static final String T1 = "TXpJM05UYzVPVEV3T0RRM05UZzFNekExLkh2T1FJQi40TFZjR016ZndMX20zY0llQnZqbE95cnhxNDM5a0pkUFJVTTFtTQ==";
    private static final String T2 = "TURJNU1UY3hNRFUxTmpRME5UTXdNamMxLjBvNHRjLS5vYlRVbXZ1ak5FT01RVjVia2h6bjJaRE8zSEk0WWxNbjZMYTVuMQ==";
    private static final String T3 = "Tmprd09EZzROamd4TWpJMk5qYzBORFE1LmNJYlRNYy5vOWF6c0dOZlVRaERIaEtRdUwwVDlGczdpN2JKdjIxY2R5M01sVQ==";
    private static final String T4 = "TXpVME1UUTVORGN6TVRBeE56azFNams0LmViMEpsWC56cE1KLU1nRW0yMGVQS1MwTVRQR3dFTzA4MjBLNG9YT2ozaUNpeA==";
    private static final String T5 = "T1RZM01EY3lOVGMzTURrM01URTJORFEzLndiUjAxUS5ESWxjSkotYk1PX3lXemhqaTZkb0FyZEN5dEF4bW5UZWQ1a3dmWA==";
    private static final String T6 = "TWpJNU1EY3pPRFkyT0RFME1UUTJNemsyLjloaVlxYy5fc1ozVXlTek1IZ3lOYzh1bmpiT0F0Z3JnS29CWUVSZ2NrRG5KMA==";
    private static final String T7 = "TmpVeE1ETTBNRGt3TXpJM05Ua3pOemcyLjJ0WTJsRC5UZTNRQk1vYm00MkUwb0VkNE56b3F0RXE1VXB4YThvWks1SGZmRw==";
    private static final String T8 = "TnpFek9UWTBPVGczTlRFMk5qRTJNelU1LksxRjgzeS5hcFpscnA3SGI2cURjU09tdUtBWkVHSUt0N0NrWm83cE5hZXNLQw==";
    private static final String T9 = "T0RZMk1UZzNNVFV5TXpFNE9EVXdPRGs1LlVrZXJPNC54Y1lWcS14WXl1SjhpWExkV1RwOUkyQTZZTWJfUlpvZTlJZFJWcQ==";
    private static final String T10 = "TkRrek5UZ3pOVFEwTVRRd056UXdOamM0Lk14ZmJVUS4tbndpTUlDTllyRDk0TTdhYWNNekJPek04Vy0xVzlPLVM1bUtIdw==";
    private static final String T11 = "TXpRMU9ERTROVEEyTURVNU5qazFOalE1Lk1ocWVMSi54YmIwbkI0R1dVbmZsdXZaQ1U4ZmpOUkN0dTNLa2xHd2RsRmN5YQ==";
    private static final String T12 = "TlRjeU1UVTNPRE13TnpJME1qQTFOemt3LlhNWWZEay4zZENtNWpFaGdRNElSVnhJNzJ6NzhGbENQSDVVTVcxQXdzN2ZQZQ==";
    private static final String T13 = "TXpreU5EWXhPRE0yTnpRNE1UZ3pORGd5Lm9QMGZUYS5TeENteWFkYUV6M3JUMjZJNl81NW5XeGE5UWR3SEU0STVWaXNXeA==";
    private static final String T14 = "TmprMk5EQXpOVEV4TmpFMU1UUXlNRGt5LmR5LVFsLS5JTThIV3hiRGNsZFRjdkRYWmQ2ekZobVJEUmFNQmd5dTRIcGs3bA==";
    private static final String T15 = "T0RjME5qRTBPVEF4T0RNMk16VTFNVEF6LnlScGk0dS5hcmljLUpPMmJ1Q3VHVUNzNG13ZExqM0N0VEo4ZnlMQzBseUwtSQ==";
    private static final String T16 = "TURJMk5ETXhNemM1TXpneE5UQTRNVGN5LmNTbXVlei5qYnQweERjVTZpOE5UN3Q5S2h1Zl9xYTlsWGpsTVZKRHhpelhrUw==";
    private static final String T17 = "TkRZeU5UYzJNRFl5TnpreE1qZ3hNVFF5LlZ6VXFGMS5nN05hOWZQTE1oX1c2NGdmRTZYMENWT2NmbGNQdi1qVG5sYUhZQQ==";
    private static final String T18 = "TWpRM016VTBOalUzTURRMk5ETTFOakl5Lk5LNGtjYi5nVXI4RXo1WHVoTWZRbFJ2Ml9oUmxtNXlSUWVlMFNURFJwckFTNg==";
    private static final String T19 = "TXpJd05ESTFOREkwT0RRM01qUTFOamcyLndrcmM4bS5IRjdUeUxPdFYzYlI2WEhzU25nTEtZakVHMm5BZ1lSUlNwYS1MUQ==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}