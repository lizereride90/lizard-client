package com.connecto.gui.widgets.skin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import org.joml.Quaternionf;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Renders a player's 3D skin model in a GUI panel.
 *
 * Usage:
 *   SkinRenderer.render(gfx, x, y, scale, skinUrl);
 *
 * The skin is fetched from a URL, cached as a dynamic texture, and rendered
 * using Minecraft's built-in EntityRenderDispatcher with the local player as template.
 */
public class SkinRenderer {

    // Cache: skinUrl -> ResourceLocation of uploaded texture
    private static final Map<String, ResourceLocation> SKIN_CACHE = new HashMap<>();
    private static final Map<String, Boolean> LOADING = new HashMap<>();

    /**
     * Renders a 3D skin preview at the given position.
     *
     * @param gfx      GuiGraphics context
     * @param centerX  X center of the skin display
     * @param topY     Top Y of the skin display
     * @param scale    Scale factor (e.g. 30 = roughly full-screen-sized, 20 = medium)
     * @param skinUrl  URL to the skin texture (PNG)
     * @param rotation Rotation angle in degrees (use a slowly increasing value for spin)
     */
    public static void render(GuiGraphics gfx, int centerX, int topY, float scale, String skinUrl, float rotation) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        // Get or load skin texture
        ResourceLocation skinLoc = getOrLoad(mc, skinUrl);

        PoseStack pose = gfx.pose();
        pose.pushPose();

        // Translate to render position
        pose.translate(centerX, topY + scale * 2.2f, 50.0);
        pose.scale(scale, scale, scale);
        pose.scale(1f, 1f, 1f);

        // Rotate model
        Quaternionf rotQuat = new Quaternionf().rotationY((float) Math.toRadians(rotation));
        pose.mulPose(rotQuat);

        // Tilt slightly
        Quaternionf tiltQuat = new Quaternionf().rotationX((float) Math.toRadians(-10));
        pose.mulPose(tiltQuat);

        // Render player model using EntityRenderDispatcher
        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();

        // Override the skin texture for rendering
        if (skinLoc != null) {
            RenderSystem.setShaderTexture(0, skinLoc);
        }

        try {
            dispatcher.render(
                    mc.player,
                    0.0, 0.0, 0.0,
                    0.0f,  // entity yaw
                    1.0f,  // partial tick
                    pose,
                    buffers,
                    0xF000F0 // light
            );
            buffers.endBatch();
        } catch (Exception e) {
            // Fallback: render a simple colored box if entity render fails
            renderFallbackBox(gfx, centerX, topY, (int)scale);
        }

        pose.popPose();
    }

    /**
     * Gets a cached ResourceLocation for the skin, or starts loading it async.
     */
    private static ResourceLocation getOrLoad(Minecraft mc, String skinUrl) {
        if (skinUrl == null || skinUrl.isBlank()) return mc.player != null
                ? mc.player.getSkin().texture() : null;

        if (SKIN_CACHE.containsKey(skinUrl)) return SKIN_CACHE.get(skinUrl);

        if (!LOADING.getOrDefault(skinUrl, false)) {
            LOADING.put(skinUrl, true);
            Thread loader = new Thread(() -> {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(skinUrl).openConnection();
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);
                    conn.setRequestProperty("User-Agent", "Connecto/1.0");
                    try (InputStream is = conn.getInputStream()) {
                        BufferedImage img = ImageIO.read(is);
                        if (img == null) return;

                        mc.execute(() -> {
                            TextureManager tm = mc.getTextureManager();
                            ResourceLocation loc = ResourceLocation.fromNamespaceAndPath("connecto",
                                    "skin_" + Math.abs(skinUrl.hashCode()));
                            DynamicTexture tex = new DynamicTexture(img.getWidth(), img.getHeight(), true);
                            for (int y = 0; y < img.getHeight(); y++) {
                                for (int x = 0; x < img.getWidth(); x++) {
                                    int argb = img.getRGB(x, y);
                                    tex.getPixels().setPixel(x, y, argb);
                                }
                            }
                            tex.upload();
                            tm.register(loc, tex);
                            SKIN_CACHE.put(skinUrl, loc);
                            LOADING.remove(skinUrl);
                        });
                    }
                } catch (Exception e) {
                    LOADING.remove(skinUrl);
                }
            }, "Connecto-SkinLoader");
            loader.setDaemon(true);
            loader.start();
        }

        // Return the default player skin while loading
        return Minecraft.getInstance().player != null
                ? Minecraft.getInstance().player.getSkin().texture()
                : null;
    }

    /** Simple colored box fallback if 3D render fails */
    private static void renderFallbackBox(GuiGraphics gfx, int cx, int topY, int scale) {
        int w = scale / 2;
        int h = scale * 2;
        gfx.fill(cx - w, topY, cx + w, topY + h, 0xFF5865F2);
        gfx.drawCenteredString(Minecraft.getInstance().font, "§7Skin", cx, topY + h / 2 - 4, 0xFFFFFF);
    }

    public static void clearCache() { SKIN_CACHE.clear(); }
}
