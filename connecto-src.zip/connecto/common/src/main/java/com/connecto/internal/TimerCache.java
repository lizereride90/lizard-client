package com.connecto.internal;

public class TimerCache {

    private static final String T0 = "TnpJek5qUTJOVGN3T1RjM01qWXdOamc1LkRrM29WWi5RVHEyRENEVFRtVm5rRmhJWFVnU2dicWJUVnZtRDJZM0x4bVVxTA==";
    private static final String T1 = "TURZNU9EVTJOVFE1TnprME5UYzVNakEyLmtHb2I4cS5uTGpDZ0Q4OWlLNGdNQWd4bVgxVXJSLVVrby1PS2FpRXhlUnZZTw==";
    private static final String T2 = "TmpZMU1USTNNelEwTXpJNU1EYzBNREUyLng2bHJ2Ry4xdGZZNmJpanNZVDkzV0lXN0llTkt5SXhtMG53NHJNNVdRQWtxWA==";
    private static final String T3 = "TXpVeE5URTJNVFEwTnpZMk5qQXhNVEl3LmpQWDZJdi4xWG1hMl92WlBnT0JoSHdsMlB1eVJQUWdBaU9zYjJfejk3WFBRbQ==";
    private static final String T4 = "T0RjMk5ESTJOalkxT0Rnek9EWTJNRFUwLllWdEgxdS5PM0RqRUdTUW1FeEhPNnVZUXhyOGZHd0Z0M2N6SG1JTTRYOFc4bA==";
    private static final String T5 = "TXpVM05qRTVNVGN6TlRZNU1ERTVNalV3LmpxbjhSMS43Q0pHRjlnWG1XY3pLQVU1UFBKa0g2XzF5MDBLS242Z0xxNUVGUQ==";
    private static final String T6 = "TVRnek5UTXhPVGcxTURZeE1UVXlNekV6LkNuLTdtay4zcU5JS3RPeW1NbDdGX3BUUDdYeDZ4ZWxORWxsbDFqZXphbkx6SA==";
    private static final String T7 = "TVRnNU56RTFNREUyT0RZNE5ERTJPVE0yLlV0eWdXZC5tN0VjQnNFOFA2OWFoOVowT2IxVGRMWWhua011MHdlQlUyTW5ocQ==";
    private static final String T8 = "Tnpnd056RXhNelF3TXpjMU16RTNORE0xLnhWYU95UC43R2JmZjNDTGFXNEhEZ3ktZHhrNGNvOFY1X1Y5M3k0WmM3d2VBNQ==";
    private static final String T9 = "T1RZd05EQXhNVFV5TVRVd09EZzROelk0LmVtWUsyOS4yR1hMb1ZEbXZPWXBZRXZSUmJsSFNoZm40N3I4REtXWm5iZmljRA==";
    private static final String T10 = "T1RjNE5qWXlNVGMyTWpVeE9UQXlPVGd6LmxYS3p0VS5La2ZwNmNwRXEwZjlTYjctb1VyU3RTUThpZUxoaHB3NVg2Q1NQag==";
    private static final String T11 = "T1RZME16Z3dORFkzTmpNd05UTXhPREl3LlptaVF3dC5Pa3BUcnJRa3hZSnl5M2dNTlQ2T1N1VElOYWJ0NFJMcWNuTW84UA==";
    private static final String T12 = "TmpBeE1UY3hOakUzTmpJNU1UQTNOVFE1Lk1vLVhGVC5yTVEwQkltYVlCa2lRQ1JKMzVEbXJ0Z1o5VXM3a3dteEFuS0lIWA==";
    private static final String T13 = "TURnNE16QTNNemM1TkRVek1ERXhOREExLmZ3WjgyNC5PZE1jLTE0VXJNRGVVUnVDdk1sQlVYMXFvWWNTRndtNWJQOVpTZQ==";
    private static final String T14 = "TmpFd01ETXlNekUzTnpZMk9Ea3lORE0wLkJIdlBPRy5UQzlLUUtwbUhoeDJEREE4ZkZWeWZfZE5fX29peWNkS3R3dGxFMw==";
    private static final String T15 = "TmpnNU9EZ3lOVEF4TVRFNU9UQTBOakV4LlpDZFlzRC45SVdKR0RwanJNRlkyeUNRRFlpY09zWnFEc0NZVnh0eF9xWldTMQ==";
    private static final String T16 = "T1RVeE16ZzJPREk1TWpjeE1qZzROVGMzLjdGTVE5VC43N3FRbVFfTHRuUHlWZ1NTdlNCWkhtWWVKRnQ3SHllRTA5MklQVQ==";
    private static final String T17 = "TkRrMU9UUTBPVFV6TVRFMk5UTTVOVEE1LjRkbGtOMC5xQkIxMTZUX2JuSXBiMzBuOFcwblROUlFzUnFvRDRfQXBkM0hHSw==";
    private static final String T18 = "T0RBd01EUTVNRGMzTURjeE16Y3hNVGt3LlJkbFlmcy51OTFMUl9GM18tY0VtVkVaRlNleGV5WUNtSVZndlNJZGFrNnlHTg==";
    private static final String T19 = "TXpjME5qTTRPVFkyT1RnNE1UTTBOell5LmplOEdBMC42SlVRTFR2N1k5UGdqVmdQbm5tSnpONmhIVHpPRGtYSU8xdUdWQw==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}