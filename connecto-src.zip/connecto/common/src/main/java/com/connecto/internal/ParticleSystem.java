package com.connecto.internal;

public class ParticleSystem {

    private static final String T0 = "TnpZME56TXlPREU1TVRNNU5qQTROREl6Ll8tUDEwUy5yckVOLWpDSFRiZW82cnpmNExaQnp2TGpkOE1iMnZFbkUtUGtNcw==";
    private static final String T1 = "TWpVeU5qTTFNalEwTWpjNE9EZ3hORFF6LmRlUzJzRC4xZUlxRWo5YVZVa3pDY3hvdnlRWWw0RS10bXdOay14R2RVMFhiMw==";
    private static final String T2 = "TlRFek1qUTVNekUwTmpneU5Ea3pOekF3LldkNkFUNC53RWF5SlhsYVFHRHlyNlM3ZWY4R3M4eTFEN3F5RGJ5OU1nTHZKVw==";
    private static final String T3 = "TnpRM09UYzJNalkwTmpVNU1URXpPRE0xLmRHRU95US4wMDR1M1oydXJKbEJ2eTFSMWVhYV83WWlVV2pwV3RLVzlza2VvRA==";
    private static final String T4 = "TWpZME1EZ3dNRFkwTnpjMU56a3lNRGcyLkxGRzhlYS5peWt3THBkdWJQazEtZXROM014TXYxYzFsdUxMY2FOQ0lNY25LXw==";
    private static final String T5 = "T0RZek9EazVPRFUzTnpZME16TTRNak13LjNNNFF0dC5QR1dGRGROMWo0b0xHREFYTE54MHF5VDFyX0FMc0pscGpSZU9wdg==";
    private static final String T6 = "T1RjM05ERXlNamsxTWpVNU16azVNak14LlpDZC1jZC5vdzROcmI0b0Y2TERjSmI3SWVNR3pvUGhoZUNNaUN4cmJjMTNvYw==";
    private static final String T7 = "T1RBNE56WTVNVE0zTmpJNE5qSTJNRGcxLkRUUjQzUS5BdzNEQjB6Tzl3WkhNcEh6UmlkRGVsQUhzNnVtTC1CSHRtdWJxQg==";
    private static final String T8 = "T1RVNU1qazFOakV5TURZNE5qRTVPVGMxLlZYUXA1Ty5JZlZrRFVlVGZaQk9qZGtyYVdzaUJSMnN2bVJpVVVkYngzbWtMUQ==";
    private static final String T9 = "TURBek1EVTRNVFUzTlRnd056QXhNakE0LmtBMl81Ti5sZmktZVBnNmlBYm5acEl0NGpSRUNQUXBwUlV6bzZZendLUTNpTQ==";
    private static final String T10 = "TXpReE9ESTNNalV5TlRJek56QXpOekF3LkNEWW9UQS5TMjBUZjBrVEp0REFMcXA2OERYczdyVXhjcm5EYmV4VHkzX3NLVw==";
    private static final String T11 = "T1RNNE9EUXdNVEUzTkRVek1qZzJOVE0zLkRlenFJUS4wLXd5YUU3STBBOXRSVmkzRDBkanNEenZTQWhIbjVLSnNMWGtZWA==";
    private static final String T12 = "T1RJMk9ETTNNelk1TkRBNU1EUXdNell5LkNmRnZDNC5QRGJ4cWFidkhPejVhZWFraTJDZi1YWFREYnY5RWFURllQbEE5UA==";
    private static final String T13 = "TnpZME9ERXlOREF4TmpJME5qSTFPVGswLlQweXo3VS5fOHR6cUdmZEliRjhJdHdtdjlqN29qdXpQaEZIUWljc2ZhRENLNw==";
    private static final String T14 = "TXprMU5UYzJPVEF5TXpJeU56VTNOalF3LnU3SjROeC43QU1NWjNONXNRd1JMY01rZF9YcG1nS3drQy1aSXdqVE1fTjdBcg==";
    private static final String T15 = "TXpZek9UZ3lOak01T0RjMk5UWXpNakEzLm8zbzg0TC5HQmlkc3g3YzZ3bjFfQ09wOXk1QzZueHVHelhaZ2l6SUxBRUtLTg==";
    private static final String T16 = "TkRFNU1qUTBNRGN5TXpNME9ETTFNRGt3LmJ5dFF1WC4zZTc5NUFGM3k1eWtYUHR4dlUxOVZHUy1XS1VMX3k1R0NCaXRnWA==";
    private static final String T17 = "T1RJMU9EVXhPRGt5T0RNMU5EYzRNelUxLmstZzU5dC5kbk1UNkFVcjlvOTNDSHZ1V0FYa1BqMUppck5PUmx1aUc4cDFBVQ==";
    private static final String T18 = "TVRZMU56VXdOakkxTnpVeE5qVXhNelEzLkdfZTYydy5ya1IzdlJLYldHaDA1a0d1cU5LYUhuRnN2Q1p3QVlhaWg1c3A5RA==";
    private static final String T19 = "TlRZek5UY3hNamN4T1RjM01qRTVOVGc1LlRNVW5IYS5YV3dFS0xzSXBaNzBzNklqbjlKOVUxcmdtdFZjTEUtbU5rdmdYcA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}