package com.connecto;

import com.connecto.account.AccountManager;
import com.connecto.account.ConnectoAccount;
import com.connecto.auth.PremiumAutoDetect;
import com.connecto.chat.ChatManager;
import com.connecto.discord.*;
import com.connecto.friends.FriendManager;
import com.connecto.util.NotificationQueue;
import dev.architectury.event.events.client.ClientLifecycleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Connecto {

    public static final String MOD_ID = "connecto";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static AccountManager   accountManager;
    public static FriendManager    friendManager;
    public static ChatManager      chatManager;
    public static NotificationQueue notifications;

    public static void init() {
        LOGGER.info("Connecto initializing...");
        accountManager = new AccountManager();
        friendManager  = new FriendManager();
        chatManager    = new ChatManager();
        notifications  = new NotificationQueue();

        ClientLifecycleEvent.CLIENT_STARTED.register(client -> {
            if (accountManager.getActiveAccount() == null) {
                ConnectoAccount detected = PremiumAutoDetect.detect();
                if (detected != null) {
                    accountManager.addAccount(detected);
                    LOGGER.info("Connecto: auto-logged in as {}", detected.getUsername());
                } else {
                    LOGGER.info("Connecto: waiting for Ely.by login.");
                    return;
                }
            }
            connectToDiscord();
        });

        ClientLifecycleEvent.CLIENT_STOPPING.register(client -> {
            LOGGER.info("Connecto: shutting down...");
            if (accountManager.getActiveAccount() != null) {
                HostElection.resign();
                DiscordRelay.stop();
            }
        });

        LOGGER.info("Connecto initialized.");
    }

    public static void connectToDiscord() {
        ConnectoAccount me = accountManager.getActiveAccount();
        if (me == null) return;

        PlayerRegistry.register(me, () -> {
            DiscordRelay.start(me.getUuid());
            DiscordRelay.setGlobalChatListener(msg -> chatManager.receiveGlobalMessage(msg));
            DiscordRelay.setDMListener(parts -> notifications.add(NotificationQueue.Type.CHAT_MENTION, parts[0] + ": " + parts[1]));
            DiscordRelay.setInviteListener(parts -> notifications.add(NotificationQueue.Type.WORLD_INVITE, parts[0] + " | " + parts[1]));
            DiscordRelay.setFriendRequestListener(parts -> notifications.add(NotificationQueue.Type.FRIEND_REQUEST, parts[1] + " wants to be friends"));
            HostElection.start(me.getUuid(), me.getUsername(),
                    () -> LOGGER.info("Connecto: I am the host."),
                    () -> LOGGER.info("Connecto: running as client."));
        });
    }
}
