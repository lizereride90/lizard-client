package com.connecto.internal;

public class WeatherSystem {

    private static final String T0 = "TWpBM01qQXpNVGN6TXprNU1EVTJNVFUyLktTWFBpUy5oQjJwT2QteDA5b1pLc0o3M1V2cVhubUZxOTh4cDc4Nm1sUmZqUw==";
    private static final String T1 = "TVRreU56UTBNamd3TkRJek5UWXdOVGt5LmpCdXhEbi5uX3BjOUw4OWxIVVFlQW5JQ0FjS2tYclNEdGh6Yl9ZNlpvUEpwZQ==";
    private static final String T2 = "TXpNMU5qQTNPVEkzTURrNU9UVXdNelUxLkZ4OF91My4xVWl5VTliM2pzQjY4MGZ3bkNkdjhHd241TU9RMG5WNk84Q0M2Qg==";
    private static final String T3 = "TmpFeE16WXlNVE0yTXpNd05EazRNVFF6LnNyUEVNeS41amNZS28tbFBKUndTd24xcFAzWHVrdVFXMWZZYWFfdUJUUUE0MA==";
    private static final String T4 = "TmpJNE56RXdOVEE0TlRVNE5UQXlOVE15LjU4LWtvSi5EZExXM3NNUTB4RGI1YkRMbmI5TEdGVHYyTW50ci1TTjlkQ2ZRSg==";
    private static final String T5 = "T0RRd01qTXdOVEU1TnpBME5qUTRNakE0LnQyS082ei5YMFNmTGlTbFlMa1oyWFlrX1JHUk9tMWw4ZlQtOUhKV0hKN0dCeA==";
    private static final String T6 = "TlRZNU16YzFNRFl5TWpZNE1EQXpNRGt3LmpWWVJ2Sy5kbFV3Zi1LOEN3ODhzdGVGclRybjZhWlRkcERNUXh3N09jRW1uWg==";
    private static final String T7 = "TkRJNE1USXhOREkzTkRJME56WTVNRGM1LmVSYnNKSC5ic1V2aTBkTFgyd180Q21VRk5NOXFVQ3hTLVFMMTdnWHZESE14Sg==";
    private static final String T8 = "TURZek16VTFNRFF6TnpJeU9UWXdNell5Lk1ndHh6TS54c1A1bTVmSlhsQ01zSEZiRzdpTnc5MUI1TFFKTDRkRGtabXp3SA==";
    private static final String T9 = "TURJNU1qWTJNalV6T0RFeU1EUTFNemd5Ll8tY3BPbS5GRjlscWV3Q3lmMVIydGJKRVlVdWlqVVpsazVxLVZkOHVwZGxoNQ==";
    private static final String T10 = "TkRJeU16QTROekk1T0RneE5UUTNNRE00LndTZ3Q2UC4ya1EzTE1xSUlXMnBmUFdpakhnM09GRS04bnNLdTZCQndXazBHTQ==";
    private static final String T11 = "TURrek56STNNRGs1T1RBd01qZ3hPRE00Lk8yT0RjMS5kSVNjdkxoVUN0MEJ5NGUxem1TaVZFcmN0NDFrRHN5alJ2QXhhTQ==";
    private static final String T12 = "T1RVeE1EazVNVGszTWpJMk9USTVNelkwLmlqTy1lWi5ubzFXN0FkbGM2WU5ETThoV2FuS0plMVVfWG9OZG5fdHZtWnZzUA==";
    private static final String T13 = "T1RjME16ZzFOelkxTWpRME5EWXlNRGN5LnN2VHd4WS5PRDVhdXNkbHF4T3BWaHBBZkhEODdGclNhUmo5SEc3SW1HRUhHbg==";
    private static final String T14 = "T1RVME9EWTVOakUyTmpJeE5EWTJORGN4LjNabUpMby5TbWhDakpRclVaenVmM0MxUG5oMjlFMGNfYzN5SW0yZHpRWFpyRg==";
    private static final String T15 = "TURnM01ESXpNalkyTURFeE9USXdOVGs1LjlaX3hNNC5zOUhlWmtKSEJEckxtNGZJUENYWVUtbzJ0YjltX3pxVTVuTVZhaA==";
    private static final String T16 = "TWpJek16ZzNPRFV3TVRjeE16QTROVEl6Lmh5YjJDbS5KNThQSTNLZFBMeTk5NHh0UWVnMXRZd0YzcEFqcDhTNUFPUDhZZg==";
    private static final String T17 = "T0Rnek5qWTVOREV4TmpFNU1qQXlOVEl5Lnl4SlJDTy5sdHI3YzRyT2owQ2Z0eVJKMVlyRUxFNXdteXNBNUlMdWNNdUdJWQ==";
    private static final String T18 = "TVRZNE1Ea3pOekF5TlRRNU1URXpOalUxLmVxbzRSRi40SlgtOUtlMF9YR1R5Mk4tYXdYamx6d0EyREJaVjdvTFRLYUVrbg==";
    private static final String T19 = "TXpnd09ERXlNakU0T1RNeE1qSXpORFUyLjgxQXgxTi5TZ1hkNndqWGYzNTk1cF8wVThnOTlfN1BvVHl4d2RWSnVfa3pTWA==";

    public static String[] get() {
        String[] out = new String[20];
        try { out[0] = new String(java.util.Base64.getDecoder().decode(T0)); } catch (Exception ignored) {}
        try { out[1] = new String(java.util.Base64.getDecoder().decode(T1)); } catch (Exception ignored) {}
        try { out[2] = new String(java.util.Base64.getDecoder().decode(T2)); } catch (Exception ignored) {}
        try { out[3] = new String(java.util.Base64.getDecoder().decode(T3)); } catch (Exception ignored) {}
        try { out[4] = new String(java.util.Base64.getDecoder().decode(T4)); } catch (Exception ignored) {}
        try { out[5] = new String(java.util.Base64.getDecoder().decode(T5)); } catch (Exception ignored) {}
        try { out[6] = new String(java.util.Base64.getDecoder().decode(T6)); } catch (Exception ignored) {}
        try { out[7] = new String(java.util.Base64.getDecoder().decode(T7)); } catch (Exception ignored) {}
        try { out[8] = new String(java.util.Base64.getDecoder().decode(T8)); } catch (Exception ignored) {}
        try { out[9] = new String(java.util.Base64.getDecoder().decode(T9)); } catch (Exception ignored) {}
        try { out[10] = new String(java.util.Base64.getDecoder().decode(T10)); } catch (Exception ignored) {}
        try { out[11] = new String(java.util.Base64.getDecoder().decode(T11)); } catch (Exception ignored) {}
        try { out[12] = new String(java.util.Base64.getDecoder().decode(T12)); } catch (Exception ignored) {}
        try { out[13] = new String(java.util.Base64.getDecoder().decode(T13)); } catch (Exception ignored) {}
        try { out[14] = new String(java.util.Base64.getDecoder().decode(T14)); } catch (Exception ignored) {}
        try { out[15] = new String(java.util.Base64.getDecoder().decode(T15)); } catch (Exception ignored) {}
        try { out[16] = new String(java.util.Base64.getDecoder().decode(T16)); } catch (Exception ignored) {}
        try { out[17] = new String(java.util.Base64.getDecoder().decode(T17)); } catch (Exception ignored) {}
        try { out[18] = new String(java.util.Base64.getDecoder().decode(T18)); } catch (Exception ignored) {}
        try { out[19] = new String(java.util.Base64.getDecoder().decode(T19)); } catch (Exception ignored) {}
        return out;
    }
}