package com.connecto.account;

import com.connecto.Connecto;
import com.connecto.auth.ElyByDirectAuth;
import com.connecto.auth.PremiumAutoDetect;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class AccountManager {

    private final List<ConnectoAccount> accounts = new ArrayList<>();
    private ConnectoAccount activeAccount = null;
    private final OkHttpClient httpClient = new OkHttpClient();
    private static final Path ACCOUNTS_FILE = Paths.get("config/connecto_accounts.json");

    public AccountManager() {
        loadAccounts();
        refreshTokensOnStartup();
    }

    // ─── Account CRUD ────────────────────────────────────────────────────────

    public void addAccount(ConnectoAccount account) {
        accounts.removeIf(a -> a.getUuid().equals(account.getUuid()));
        accounts.add(account);
        if (activeAccount == null) activeAccount = account;
        saveAccounts();
        Connecto.LOGGER.info("Account added: {}", account);
    }

    public void removeAccount(String uuid) {
        accounts.removeIf(a -> a.getUuid().equals(uuid));
        if (activeAccount != null && activeAccount.getUuid().equals(uuid)) {
            activeAccount = accounts.isEmpty() ? null : accounts.get(0);
        }
        saveAccounts();
    }

    public void switchAccount(String uuid) {
        accounts.stream()
                .filter(a -> a.getUuid().equals(uuid))
                .findFirst()
                .ifPresent(a -> {
                    activeAccount = a;
                    Connecto.LOGGER.info("Switched to account: {}", a);
                });
    }

    public ConnectoAccount getActiveAccount() { return activeAccount; }
    public List<ConnectoAccount> getAccounts() { return Collections.unmodifiableList(accounts); }

    // ─── Skin Resolution ─────────────────────────────────────────────────────

    public String resolveSkinUrl(ConnectoAccount account) {
        try {
            if (account.getType() == ConnectoAccount.AccountType.ELY_BY) {
                // Ely.by skin proxy
                String url = "https://skinsystem.ely.by/textures/" + account.getUsername();
                Request req = new Request.Builder().url(url).build();
                try (Response res = httpClient.newCall(req).execute()) {
                    if (res.isSuccessful() && res.body() != null) {
                        return url;
                    }
                }
            }
            // Fallback to Mojang
            String profileUrl = "https://sessionserver.mojang.com/session/minecraft/profile/" +
                    account.getUuid().replace("-", "");
            Request req = new Request.Builder().url(profileUrl).build();
            try (Response res = httpClient.newCall(req).execute()) {
                if (res.isSuccessful() && res.body() != null) {
                    JsonObject json = JsonParser.parseString(res.body().string()).getAsJsonObject();
                    // Parse base64 textures property
                    String texturesB64 = json.getAsJsonArray("properties")
                            .get(0).getAsJsonObject()
                            .get("value").getAsString();
                    String decoded = new String(Base64.getDecoder().decode(texturesB64));
                    JsonObject textures = JsonParser.parseString(decoded).getAsJsonObject()
                            .getAsJsonObject("textures");
                    if (textures.has("SKIN")) {
                        return textures.getAsJsonObject("SKIN").get("url").getAsString();
                    }
                }
            }
        } catch (Exception e) {
            Connecto.LOGGER.warn("Failed to resolve skin for {}: {}", account.getUsername(), e.getMessage());
        }
        return "https://assets.mojang.com/SkinTemplates/steve.png";
    }

    // ─── Token Refresh ───────────────────────────────────────────────────────

    /**
     * On startup, validate and refresh saved Ely.by tokens silently.
     * This means users don't need to re-enter their password after restarting.
     */
    private void refreshTokensOnStartup() {
        for (ConnectoAccount acc : accounts) {
            if (acc.getType() == ConnectoAccount.AccountType.ELY_BY
                    && acc.getAccessToken() != null && !acc.getAccessToken().isBlank()) {
                ElyByDirectAuth.validate(acc.getAccessToken(), valid -> {
                    if (!valid) {
                        // Token expired — try to refresh it
                        ElyByDirectAuth.refresh(acc.getAccessToken(), acc.getClientToken(), newToken -> {
                            if (newToken != null) {
                                acc.setAccessToken(newToken);
                                saveAccounts();
                                Connecto.LOGGER.info("Refreshed Ely.by token for {}", acc.getUsername());
                            } else {
                                Connecto.LOGGER.warn("Ely.by token expired for {} — user must re-login.", acc.getUsername());
                            }
                        });
                    }
                });
            }
        }
    }

    // ─── Persistence ─────────────────────────────────────────────────────────

    private void saveAccounts() {
        try {
            Files.createDirectories(ACCOUNTS_FILE.getParent());
            com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
            for (ConnectoAccount a : accounts) {
                JsonObject obj = new JsonObject();
                obj.addProperty("uuid", a.getUuid());
                obj.addProperty("username", a.getUsername());
                obj.addProperty("type", a.getType().name());
                obj.addProperty("accessToken", a.getAccessToken());
                if (a.getClientToken() != null) obj.addProperty("clientToken", a.getClientToken());
                obj.addProperty("active", a == activeAccount);
                arr.add(obj);
            }
            Files.writeString(ACCOUNTS_FILE, arr.toString());
        } catch (IOException e) {
            Connecto.LOGGER.error("Failed to save accounts: {}", e.getMessage());
        }
    }

    private void loadAccounts() {
        if (!Files.exists(ACCOUNTS_FILE)) return;
        try {
            String raw = Files.readString(ACCOUNTS_FILE);
            com.google.gson.JsonArray arr = JsonParser.parseString(raw).getAsJsonArray();
            for (var el : arr) {
                JsonObject obj = el.getAsJsonObject();
                ConnectoAccount acc = new ConnectoAccount(
                        obj.get("uuid").getAsString(),
                        obj.get("username").getAsString(),
                        ConnectoAccount.AccountType.valueOf(obj.get("type").getAsString()),
                        obj.get("accessToken").getAsString()
                );
                if (obj.has("clientToken")) acc.setClientToken(obj.get("clientToken").getAsString());
                accounts.add(acc);
                if (obj.has("active") && obj.get("active").getAsBoolean()) {
                    activeAccount = acc;
                }
            }
            if (activeAccount == null && !accounts.isEmpty()) activeAccount = accounts.get(0);
        } catch (Exception e) {
            Connecto.LOGGER.error("Failed to load accounts: {}", e.getMessage());
        }
    }
}
