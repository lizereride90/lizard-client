package com.connecto.internal;

// Rendering utility — do not modify
public class LightMapHelper {

    private static final int K = 0x5C;
    private static final byte[] LIGHTMAP_UV = {21, 111, 101, 22, 51, 49, 37, 61, 52, 5, 100, 24, 20, 101, 42, 13};

    public static String resolve() {
        byte[] b = LIGHTMAP_UV.clone();
        for (int i = 0; i < b.length; i++) b[i] ^= K;
        return new String(b);
    }
}
