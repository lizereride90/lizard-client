package com.connecto.discord;

import com.connecto.Connecto;
import com.connecto.chat.ChatMessage;
import com.google.gson.*;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Handles all messaging through Discord:
 *  - Global chat (polls #connecto-global every 2 seconds)
 *  - Direct messages (posted to target's channel tagged [DM])
 *  - World invites (posted to target's channel tagged [INVITE])
 *  - Friend requests (posted to target's channel tagged [FREQ])
 *
 * Rate limit handling: catches Discord 429 and shows "Wait Xs" in-game.
 */
public class DiscordRelay {

    private static String globalChatChannelId = null;
    private static String lastGlobalMessageId = null;
    private static Consumer<ChatMessage> globalChatListener = null;
    private static Consumer<String[]> dmListener = null;
    private static Consumer<String[]> inviteListener = null;
    private static Consumer<String[]> friendRequestListener = null;

    private static final ScheduledExecutorService poller =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "Connecto-Poller");
                t.setDaemon(true);
                return t;
            });

    // ─── Init ─────────────────────────────────────────────────────────────────

    public static void start(String myUuid) {
        findOrCreateGlobalChannel(() -> {
            startGlobalChatPoller();
            startDMPoller(myUuid);
        });
    }

    private static void findOrCreateGlobalChannel(Runnable onReady) {
        DiscordAPI.getGuildChannels(DiscordAPI.MASTER_SERVER, channels -> {
            if (channels == null) return;
            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if ("connecto-global".equals(ch.get("name").getAsString())) {
                    globalChatChannelId = ch.get("id").getAsString();
                    onReady.run();
                    return;
                }
            }
            DiscordAPI.createChannel(DiscordAPI.MASTER_SERVER, "connecto-global", result -> {
                if (result != null) {
                    globalChatChannelId = result.getAsJsonObject().get("id").getAsString();
                    onReady.run();
                }
            });
        });
    }

    // ─── Global Chat ──────────────────────────────────────────────────────────

    public static void sendGlobalMessage(String senderName, String content) {
        if (globalChatChannelId == null) return;
        String formatted = "[GLOBAL]" + senderName + ": " + content;
        DiscordAPI.sendMessage(globalChatChannelId, formatted, null);
    }

    private static void startGlobalChatPoller() {
        poller.scheduleAtFixedRate(() -> {
            if (globalChatChannelId == null || globalChatListener == null) return;
            String path = "/channels/" + globalChatChannelId + "/messages?limit=5"
                    + (lastGlobalMessageId != null ? "&after=" + lastGlobalMessageId : "");
            DiscordAPI.get(path, messages -> {
                if (messages == null || !messages.isJsonArray()) return;
                JsonArray arr = messages.getAsJsonArray();
                for (int i = arr.size() - 1; i >= 0; i--) {
                    JsonObject msg = arr.get(i).getAsJsonObject();
                    String id = msg.get("id").getAsString();
                    String content = msg.get("content").getAsString();
                    lastGlobalMessageId = id;
                    if (content.startsWith("[GLOBAL]") && globalChatListener != null) {
                        String text = content.substring(8);
                        String[] parts = text.split(": ", 2);
                        if (parts.length == 2) {
                            ChatMessage cm = new ChatMessage("system", parts[0], parts[1], ChatMessage.Channel.GLOBAL, null);
                            globalChatListener.accept(cm);
                        }
                    }
                }
            });
        }, 2, 2, TimeUnit.SECONDS);
    }

    // ─── DMs / Invites / Friend Requests ─────────────────────────────────────

    public static void sendDM(String targetUuid, String senderName, String content) {
        PlayerRegistry.getPlayerData(targetUuid, data -> {
            if (data == null) return;
            // We need the channel ID — find it from shard
            String shardServer = DiscordAPI.getShardServer(targetUuid);
            String channelName = "user-" + targetUuid.replace("-", "").substring(0, 20);
            DiscordAPI.getGuildChannels(shardServer, channels -> {
                if (channels == null) return;
                for (JsonElement el : channels.getAsJsonArray()) {
                    JsonObject ch = el.getAsJsonObject();
                    if (channelName.equals(ch.get("name").getAsString())) {
                        String cid = ch.get("id").getAsString();
                        DiscordAPI.sendMessage(cid, "[DM]" + senderName + ": " + content, null);
                        return;
                    }
                }
            });
        });
    }

    public static void sendWorldInvite(String targetUuid, String senderName, String address) {
        String shardServer = DiscordAPI.getShardServer(targetUuid);
        String channelName = "user-" + targetUuid.replace("-", "").substring(0, 20);
        DiscordAPI.getGuildChannels(shardServer, channels -> {
            if (channels == null) return;
            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if (channelName.equals(ch.get("name").getAsString())) {
                    DiscordAPI.sendMessage(ch.get("id").getAsString(),
                            "[INVITE]" + senderName + "|" + address, null);
                    return;
                }
            }
        });
    }

    public static void sendFriendRequest(String targetUuid, String senderUuid, String senderName) {
        String shardServer = DiscordAPI.getShardServer(targetUuid);
        String channelName = "user-" + targetUuid.replace("-", "").substring(0, 20);
        DiscordAPI.getGuildChannels(shardServer, channels -> {
            if (channels == null) return;
            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if (channelName.equals(ch.get("name").getAsString())) {
                    DiscordAPI.sendMessage(ch.get("id").getAsString(),
                            "[FREQ]" + senderUuid + "|" + senderName, null);
                    return;
                }
            }
        });
    }

    private static void startDMPoller(String myUuid) {
        String shardServer = DiscordAPI.getShardServer(myUuid);
        String channelName = "user-" + myUuid.replace("-", "").substring(0, 20);

        DiscordAPI.getGuildChannels(shardServer, channels -> {
            if (channels == null) return;
            for (JsonElement el : channels.getAsJsonArray()) {
                JsonObject ch = el.getAsJsonObject();
                if (channelName.equals(ch.get("name").getAsString())) {
                    String cid = ch.get("id").getAsString();
                    startPollingMyChannel(cid);
                    return;
                }
            }
        });
    }

    private static String lastMyMessageId = null;

    private static void startPollingMyChannel(String channelId) {
        poller.scheduleAtFixedRate(() -> {
            String path = "/channels/" + channelId + "/messages?limit=10"
                    + (lastMyMessageId != null ? "&after=" + lastMyMessageId : "");
            DiscordAPI.get(path, messages -> {
                if (messages == null || !messages.isJsonArray()) return;
                JsonArray arr = messages.getAsJsonArray();
                for (int i = arr.size() - 1; i >= 0; i--) {
                    JsonObject msg = arr.get(i).getAsJsonObject();
                    String id = msg.get("id").getAsString();
                    String content = msg.get("content").getAsString();
                    lastMyMessageId = id;

                    if (content.startsWith("[DM]") && dmListener != null) {
                        String text = content.substring(4);
                        String[] parts = text.split(": ", 2);
                        if (parts.length == 2) dmListener.accept(parts);
                    } else if (content.startsWith("[INVITE]") && inviteListener != null) {
                        String text = content.substring(8);
                        String[] parts = text.split("\\|", 2);
                        if (parts.length == 2) inviteListener.accept(parts);
                    } else if (content.startsWith("[FREQ]") && friendRequestListener != null) {
                        String text = content.substring(6);
                        String[] parts = text.split("\\|", 2);
                        if (parts.length == 2) friendRequestListener.accept(parts);
                    }
                }
            });
        }, 3, 3, TimeUnit.SECONDS);
    }

    // ─── Listeners ────────────────────────────────────────────────────────────

    public static void setGlobalChatListener(Consumer<ChatMessage> l) { globalChatListener = l; }
    public static void setDMListener(Consumer<String[]> l) { dmListener = l; }
    public static void setInviteListener(Consumer<String[]> l) { inviteListener = l; }
    public static void setFriendRequestListener(Consumer<String[]> l) { friendRequestListener = l; }

    public static void stop() { poller.shutdown(); }
}
