package com.connecto.gui.screens;

import com.connecto.Connecto;
import com.connecto.account.ConnectoAccount;
import com.connecto.gui.widgets.ConnectoButton;
import com.connecto.gui.widgets.ConnectoTextInput;
import com.connecto.gui.widgets.skin.SkinRenderer;
import com.connecto.network.ConnectoAPI;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ProfileScreen extends Screen {

    private final Screen parent;
    private final String targetUuid;

    private String username = "Loading...";
    private String bio = "";
    private String accountType = "PREMIUM";
    private String skinUrl = null;
    private boolean isOwnProfile = false;

    private boolean editing = false;
    private ConnectoTextInput bioInput;

    // Skin rotation
    private float skinRotation = 180f;
    private static final float ROTATION_SPEED = 0.5f;

    public ProfileScreen(Screen parent, String targetUuid) {
        super(Component.literal("Profile"));
        this.parent = parent;
        this.targetUuid = targetUuid;
    }

    @Override
    protected void init() {
        ConnectoAccount me = Connecto.accountManager.getActiveAccount();
        isOwnProfile = me != null && me.getUuid().equals(targetUuid);

        if (isOwnProfile && me != null) {
            username    = me.getUsername();
            accountType = me.getType().name();
            skinUrl     = me.getSkinUrl();
        }

        this.addRenderableWidget(new ConnectoButton(4, this.height - 24, 80, 20,
                Component.literal("< Back"), btn -> this.onClose()));

        if (isOwnProfile) {
            this.addRenderableWidget(new ConnectoButton(this.width - 104, this.height - 24, 100, 20,
                    Component.literal(editing ? "Save" : "Edit Profile"),
                    btn -> { if (editing) saveBio(); else startEditing(); }));
        } else {
            int cx = this.width / 2;
            this.addRenderableWidget(new ConnectoButton(cx - 120, this.height - 50, 72, 20,
                    Component.literal("Message"), btn -> openDM()));
            this.addRenderableWidget(new ConnectoButton(cx - 42, this.height - 50, 84, 20,
                    Component.literal("Add Friend"),
                    btn -> Connecto.friendManager.sendFriendRequest(targetUuid)));
            this.addRenderableWidget(new ConnectoButton(cx + 48, this.height - 50, 72, 20,
                    Component.literal("Invite"), btn -> sendInvite()));
        }

        if (editing) {
            bioInput = new ConnectoTextInput(this.font,
                    this.width / 2 - 150, this.height / 2 + 30, 300, 18,
                    Component.literal("Write something about yourself..."));
            bioInput.setValue(bio);
            bioInput.setMaxLength(200);
            this.addRenderableWidget(bioInput);
        }
    }

    private void startEditing() { editing = true; this.clearWidgets(); this.init(); }

    private void saveBio() {
        bio = bioInput != null ? bioInput.getValue().trim() : bio;
        editing = false;
        ConnectoAccount me = Connecto.accountManager.getActiveAccount();
        if (me != null) ConnectoAPI.updateProfile(me, bio, skinUrl, ok -> {});
        this.clearWidgets();
        this.init();
    }

    private void openDM() {
        Connecto.friendManager.getFriend(targetUuid)
                .ifPresent(f -> this.minecraft.setScreen(new DirectMessageScreen(this, f)));
    }

    private void sendInvite() {
        ConnectoAccount me = Connecto.accountManager.getActiveAccount();
        if (me == null) return;
        String addr = com.connecto.hosting.P2PHostManager.getHostAddress();
        if (addr == null) addr = "Not hosting";
        ConnectoAPI.sendWorldInvite(me, targetUuid, addr, ok -> {});
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        this.renderBackground(gfx, mouseX, mouseY, delta);
        gfx.fill(0, 0, this.width, this.height, 0xCC000000);

        int cx = this.width / 2;

        // Profile card
        gfx.fill(cx - 160, 30, cx + 160, this.height - 60, 0xFF1E2030);
        gfx.fill(cx - 160, 30, cx + 160, 32, 0xFF5865F2);

        // 3D skin
        skinRotation = (skinRotation + ROTATION_SPEED) % 360f;
        SkinRenderer.render(gfx, cx - 90, 50, 22f, skinUrl, skinRotation);

        // Info
        int infoX = cx - 20;
        int infoY = 55;
        gfx.drawString(this.font, username, infoX, infoY, 0xFFFFFF);
        String badge = accountType.equals("PREMIUM") ? "Premium Account" : "Ely.by Account";
        gfx.drawString(this.font, badge, infoX, infoY + 14, 0xAAAAAA);

        if (targetUuid != null) {
            String shortUuid = targetUuid.length() > 18 ? targetUuid.substring(0, 18) + "..." : targetUuid;
            gfx.drawString(this.font, shortUuid, infoX, infoY + 28, 0x666666);
        }

        gfx.fill(cx - 20, infoY + 44, cx + 155, infoY + 45, 0xFF40444B);
        gfx.drawString(this.font, "Bio", infoX, infoY + 52, 0x888888);
        if (!editing) {
            String displayBio = bio.isBlank() ? "No bio set." : bio;
            gfx.drawString(this.font, displayBio, infoX, infoY + 64, 0xCCCCCC);
        }

        super.render(gfx, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
