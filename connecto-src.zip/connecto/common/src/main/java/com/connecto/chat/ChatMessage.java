package com.connecto.chat;

import java.time.Instant;

public class ChatMessage {

    public enum Channel {
        GLOBAL,
        DIRECT,
        GROUP
    }

    private final String id;
    private final String senderUuid;
    private final String senderUsername;
    private final String content;
    private final Channel channel;
    private final String channelId; // null for GLOBAL, uuid for DM, groupId for GROUP
    private final Instant timestamp;

    public ChatMessage(String id, String senderUuid, String senderUsername,
                       String content, Channel channel, String channelId) {
        this.id = id;
        this.senderUuid = senderUuid;
        this.senderUsername = senderUsername;
        this.content = content;
        this.channel = channel;
        this.channelId = channelId;
        this.timestamp = Instant.now();
    }

    public String getId() { return id; }
    public String getSenderUuid() { return senderUuid; }
    public String getSenderUsername() { return senderUsername; }
    public String getContent() { return content; }
    public Channel getChannel() { return channel; }
    public String getChannelId() { return channelId; }
    public Instant getTimestamp() { return timestamp; }

    public String format() {
        return switch (channel) {
            case GLOBAL -> "§7[§bGlobal§7] §f" + senderUsername + "§7: §f" + content;
            case DIRECT -> "§7[§dDM§7] §f" + senderUsername + "§7: §f" + content;
            case GROUP  -> "§7[§eGroup§7] §f" + senderUsername + "§7: §f" + content;
        };
    }
}
