package com.connecto.forge;

import com.connecto.Connecto;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(Connecto.MOD_ID)
public class ConnectoForge {

    public ConnectoForge() {
        FMLJavaModLoadingContext.get().getModEventBus()
                .addListener(this::clientSetup);
    }

    private void clientSetup(FMLClientSetupEvent event) {
        Connecto.init();
    }
}
