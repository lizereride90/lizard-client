package com.connecto.quilt;

import com.connecto.Connecto;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;

public class ConnectoQuilt implements ClientModInitializer {

    @Override
    public void onInitializeClient(ModContainer mod) {
        Connecto.init();
    }
}
